#include "rm_msgs/Armor.h"
#include "rm_msgs/ArmorArray.h"
#include "UTools.hpp"
#include "Variable.h"

enum class TrackerState{
    Starting    = 0x00, // 启动中
    Detecting   = 0x01, // 识别
    Tracking    = 0x02, // 跟踪
    Lost        = 0x04  // 丢失
}
typedef struct Robot{
    int id = -1;
    Fiter::EKF* ekf = NULL;
    Eigen::Vector3d center;
    double radius[2] = {0,0}; // 0 long 1 short
    Armor armors[4]; 
    uchar longR[2] = {0,0};
    uchar shortR[2] = {0,0};
    bool equalRadius = false;
    double angle = 0;
    AverageCounter<20> rav; 
}Robot;
template<TimeSpan trackTime>
class Tracker{
    private:
        bool Initialized;                   //是否已经初始化
        char TrackingID;                    //跟踪中的装甲板ID
        Timestamp ComputeTime;              //处理时间(上一帧处理时间戳)
        Timestamp LastErrorTime;            //上一次错误时间戳
        Timestamp LastDetectTime;           //上一次识别时间戳
        Robot* Robots;                      //存储机器人各种信息
        TrackerState State;
    public:
        static int RobotCount = 7;
        Tracker();                          //构造函数 初始化数据
        ~Tracker();                         //析构函数 释放数据
        void Init();                        //初始化函数
        void Track(rm_msgs::ArmorArray);    //回调函数 处理识别节点发来的话题
        TimeSpan GetTrackTime();            //获取跟踪器 跟踪时长
};
#ifndef RMTRACKER
#define RMTRACKER
Tracker::Tracker(){
    Timestamp ctime = GetTimestamp();
    Initialized = false;
    TrackingID = '-1';
    ComputeTime = ctime;
    LastErrorTime = 0;
    LastDetectTime = 0;
    Robots = new Robot[RobotCount];
    State = TrackerState::Starting;
    Init();
}
Tracker::~Tracker(){
    if(Robots)
        delete[] Robots;
}
void Tracker::Track(rm_msgs::ArmorArray armors){
    //初始变量声明
    rm_msgs::Armor* detect = NULL;                   //识别的装甲板
    ComputeTime = GetTimestamp;
    //根据信息维护跟踪器
    //如果装甲板id为-1则没有识别
    //反之就是有识别
    switch (State)
    {
    case TrackerState::Starting:
        if(Debug)
            Log::Info("------------- Start [" + std::to_string(fcr.COUNT()) + "] -------------");
        //启动中 初始化参数
        Init();
        LastDetectTime = GetTimestamp();
        State = TrackerState::Lost;
        break;
    case TrackerState::Detecting:
        if(Debug)
            Log::Info("------------- Detect[" + std::to_string(fcr.COUNT()) + "] -------------");
        //有识别 优先跟踪上一次跟踪的目标
        //没有则跟踪距离光心最近的
        double minDisToCenter = DOUBLE_MAX;
        for(auto& armor:armors.armors){
            if(armor.number == TrackingID){
                detect = &armor;
                break;
            }
            else if(armor.armorToCenterDis < minDisToCenter){
                minDisToCenter = armor.armorToCenterDis;
                detect = &armor;
            }
        }
    case TrackerState::Tracking:
        if(State == TrackerState::Tracking){
            if(Debug)
                Log::Info("------------- Track [" + std::to_string(fcr.COUNT()) + "] -------------");
        }
    case -1:
        //有无识别的共有部分
        break;
    case TrackerState::Lost:
        if(Debug)
            Log::Info("------------- Lost  [" + std::to_string(fcr.COUNT()) + "] -------------");
        //重置参数
        break;
    }
    ComputeTime = GetTimestamp;
}
#endif