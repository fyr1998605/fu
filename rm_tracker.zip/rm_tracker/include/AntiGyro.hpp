#pragma once
#include"test_compensation.hpp"
#include<math.h>
#include<iostream>
#include<opencv2/opencv.hpp>
#include<vector>
#include<Eigen/Dense>
#include<ros/ros.h>
#include<fstream>
#include<thread>
#include<chrono>
#include"Pid.hpp"

using namespace ros;
using namespace cv;
namespace Tools {
	//#define A_PI 3.141592653
#define Half_Height 27.75 //55.5
#define Half_Width 66.685 //133.37
#define ErrorZ 100
#define BasicPrecisionZ 0.03
#define ToRadian 0.017453292519943
	const double Pitch = 90;

	const double A_PI = 3.141592653589793;

	struct Line2d;
	typedef struct Vector2
	{
		friend std::ostream& operator<<(std::ostream& o, Vector2 a);
		double x;
		double y;
		Vector2 operator +(Vector2 b)const {
			Vector2 result = { 0,0 };
			result.x = this->x + b.x;
			result.y = this->y + b.y;
			return result;
		};
		double operator *(Vector2 b)const {
			double result = 0;
			result += this->x * b.x;
			result += this->y * b.y;
			return result;
		};
		Vector2 operator *(double b)const {
			Vector2 result = { 0,0 };
			result.x += this->x * b;
			result.y += this->y * b;
			return result;
		};
		Vector2 operator /(double b)const {
			Vector2 result = { 0,0 };
			result.x += this->x / b;
			result.y += this->y / b;
			return result;
		};
		Vector2 operator +=(Vector2 b) {
			this->x += b.x;
			this->y += b.y;
			return *this;
		};
		operator cv::Point2d()const {
			return cv::Point2d(x, y);
		}
		//(Ax+By+C)/sqrt(A^2+B^2);
		double Distance(Line2d line);
	}Vector2;
	typedef struct Vector3
	{
		friend std::ostream& operator<<(std::ostream& o, Vector3 a);
		double x;
		double y;
		double z;
		Vector3 operator +(Vector3 b)const {
			Vector3 result = { 0,0,0 };
			result.x = this->x + b.x;
			result.y = this->y + b.y;
			result.z = this->z + b.z;
			return result;
		};
		double operator *(Vector3 b)const {
			double result = 0;
			result += this->x * b.x;
			result += this->y * b.y;
			result += this->z * b.z;
			return result;
		};
		Vector3 operator *(double b)const {
			Vector3 result = { 0,0,0 };
			result.x += this->x * b;
			result.y += this->y * b;
			result.z += this->z * b;
			return result;
		};
		Vector3 operator /(double b)const {
			Vector3 result = { 0,0,0 };
			result.x += this->x / b;
			result.y += this->y / b;
			result.z += this->z / b;
			return result;
		};
		Vector3 operator +=(Vector3 b) {
			this->x += b.x;
			this->y += b.y;
			this->z += b.z;
			return *this;
		};
		operator cv::Point3d()const {
			return cv::Point3d(x, y, z);
		}
		Vector3 CrossProduct(Vector3 a) {
			return { this->y * a.z - this->z * a.y,this->z * a.x - this->x * a.z,this->x * a.y - this->y * a.x };
		}
		double Module() {
			return std::pow(std::pow(x, 2) + std::pow(y, 2) + std::pow(z, 2), 0.5);
		}
		Vector3 Normalize() {
			auto mod = Module();
			x /= mod;
			y /= mod;
			z /= mod;
			return *this;
		}
	}Vector3;
	//点法式
	typedef struct Plane {
		Vector3 anchor, vector;
	}Plane;
	//参数方程
	typedef struct Line {
		Vector3 anchor, vector;
		Vector3 operator&(Plane p) {
			double t0 = 0;
			t0 = this->vector.x * (p.anchor.x - this->anchor.x) + this->vector.y * (p.anchor.y - this->anchor.y) + this->vector.z * (p.anchor.z - this->anchor.z);
			return { anchor.x + t0 * vector.x,anchor.y + t0 * vector.y,anchor.z + t0 * vector.z };
		}
	}Line;
	//y = kx + b; -> kx - y + b = 0
	typedef struct Line2d {
		double k, b;
		Line2d Get(Vector2 a, Vector2 b) {
			if (b.x - a.x == 0)
				throw "tan90不存在捏";
			k = (b.y - a.y) / (b.x - a.x);
			this->b = a.y - k * a.x;
			return *this;
		}
	}Line2d;
	double Vector2::Distance(Line2d line) {
		return std::abs(line.k * x - y + line.b) / std::sqrt(line.k * line.k + 1);
	}
	class Calculater {
	public:
		static double Angle_Calc(Vector3 a, Vector3 b) {
			return std::acos((a * b) / (Module(a) * Module(b))) * (180 / A_PI);
		}
		static double Module(Vector3 a) {
			return std::pow(std::pow(a.x, 2) + std::pow(a.y, 2) + std::pow(a.z, 2), 0.5);
		}
		static Vector3 Normalize(Vector3 a) {
			Vector3 result(a);
			auto mod = Module(a);
			result = result / mod;
			return result;
		}
		//3 *----* 2
		//	|   /|
		//	|  / |
		//	| /  |
		//	|/   |
		//0 *----* 1 输入必须顺时针或逆时针
		static double AreaCalc(std::vector<cv::Point2f> pts) {
			Line2d axis = { 0,0 };
			axis.Get(_Vector(pts[0]), _Vector(pts[2]));//对角线
			double halfUnder = _Distance(_Vector(pts[0]), _Vector(pts[2])) / 2;
			return _Vector(pts[3]).Distance(axis) * halfUnder + _Vector(pts[1]).Distance(axis) * halfUnder;
		}
		static double AreaCalc(cv::Point2f* pts) {
			Line2d axis = { 0,0 };
			axis.Get(_Vector(pts[0]), _Vector(pts[2]));//对角线
			double halfUnder = _Distance(_Vector(pts[0]), _Vector(pts[2])) / 2;
			return _Vector(pts[3]).Distance(axis) * halfUnder + _Vector(pts[1]).Distance(axis) * halfUnder;
		}
		static double AreaCalc(std::vector<Vector2> pts) {
			Line2d axis = { 0,0 };
			axis.Get(pts[0], pts[2]);//对角线
			double halfUnder = _Distance(pts[0], pts[2]) / 2;
			return pts[3].Distance(axis) * halfUnder + pts[1].Distance(axis) * halfUnder;
		}
		static double AreaCalc(Vector2* pts) {
			Line2d axis = { 0,0 };
			axis.Get(pts[0], pts[2]);//对角线
			double halfUnder = _Distance(pts[0], pts[2]) / 2;
			return pts[3].Distance(axis) * halfUnder + pts[1].Distance(axis) * halfUnder;
		}
		//b-a
		static Vector3 Vector(Vector3 a, Vector3 b) {
			return { b.x - a.x,b.y - a.y,b.z - a.z };
		}
		static Vector3 Vector(cv::Mat a) {
			return { a.at<double>(0,0),a.at<double>(1,0),a.at<double>(2,0) };
		}
		static Vector3 Vector(cv::Point3f a) {
			return { a.x,a.y,a.z };
		}
		static double Distance(Vector3 a, Vector3 b) {
			return std::sqrt(std::pow(a.x - b.x, 2) + std::pow(a.y - b.y, 2) + std::pow(a.z - b.z, 2));
		}
		static Vector3 xOy(Vector3 a) {
			return { a.x,a.y,0 };
		}
		static Vector3 xOz(Vector3 a) {
			return { a.x,0,a.z };
		}
		static Vector3 yOz(Vector3 a) {
			return { 0,a.y,a.z };
		}
		static Vector3 Middle(Vector3 a, Vector3 b) {
			return { (a.x + b.x) / 2,(a.y + b.y) / 2,(a.z + b.z) / 2 };
		}
		static Vector3 Rotate(Vector3 original, Vector3 anchor, Vector3 direction, double angle) {
			Line axis_Rotary = { anchor, direction };//旋转轴
			Plane plane_Rotary = { original,direction };//旋转平面
			Vector3 node = axis_Rotary & plane_Rotary;//旋转平面和旋转轴交点
			double radius = std::sqrt(std::pow(original.x - node.x, 2) + std::pow(original.y - node.y, 2) + std::pow(original.z - node.z, 2));//旋转半径
			Vector3 OP = Vector(node, original).Normalize(),
				_y = direction.CrossProduct(OP);
			Eigen::Matrix<double, 4, 4> transfer;
			transfer << OP.x, _y.x, direction.x, node.x,
				OP.y, _y.y, direction.y, node.y,
				OP.z, _y.z, direction.z, node.z,
				0, 0, 0, 1;
			Eigen::Matrix<double, 4, 1>_xyz_p;
			_xyz_p << radius * std::cos(angle * (A_PI / 180)),
				radius* std::sin(angle * (A_PI / 180)),
				0,
				1;
			Vector3 result = { 0,0,0 };
			{
				auto _result = transfer * _xyz_p;
				result.x = _result(0);
				result.y = _result(1);
				result.z = _result(2);
			}
			return result;
		}
		static double _Angle_Calc(Vector2 a, Vector2 b) {
			return std::acos((a * b) / (_Module(a) * _Module(b))) * (180 / A_PI);
		}
		static double _Module(Vector2 a) {
			return std::sqrt(std::pow(a.x, 2) + std::pow(a.y, 2));
		}
		static Vector2 _Normalize(Vector2 a) {
			Vector2 result(a);
			auto mod = _Module(a);
			result = result / mod;
			return result;
		}
		static Vector2 _Vector(Vector2 a, Vector2 b) {
			return { b.x - a.x,b.y - a.y };
		}
		static Vector2 _Vector(cv::Point2f a) {
			return { a.x,a.y };
		}
		static double _Distance(Vector2 a, Vector2 b) {
			return std::sqrt(std::pow(a.x - b.x, 2) + std::pow(a.y - b.y, 2));
		}
		static Vector3 _Middle(Vector2 a, Vector2 b) {
			return { (a.x + b.x) / 2,(a.y + b.y) / 2 };
		}


		static cv::Point2f ThreeToTwo(cv::Mat inp, cv::Mat PointInCam)
		{
			cv::Mat Temp_PointInCam = inp * PointInCam;
			return cv::Point2f(Temp_PointInCam.at<double>(0, 0) / Temp_PointInCam.at<double>(2, 0), Temp_PointInCam.at<double>(1, 0) / Temp_PointInCam.at<double>(2, 0));
		}
		static cv::Point2f ThreeToTwo(cv::Mat inp, Vector3 posision)
		{
			cv::Mat temp = (cv::Mat_<double>(3, 1) << posision.x, posision.y, posision.z);
			return ThreeToTwo(inp, temp);
		}
		static double DistanceInImage(cv::Mat inp, Vector3 a, Vector3 b) {
			return _Distance(_Vector(ThreeToTwo(inp, a)), _Vector(ThreeToTwo(inp, b)));
		}
	};
	
	inline std::ostream& operator<<(std::ostream& o, Vector3 a) {
		o << '(' << a.x << ',' << a.y << ',' << a.z << ')';
		return o;
	}
	inline std::ostream& operator<<(std::ostream& o, Vector2 a) {
		o << '(' << a.x << ',' << a.y << ')';
		return o;
	}

	typedef struct Armor {
		friend std::ostream& operator<<(std::ostream& o, Armor a);
		int class_int;
		cv::Point3d center;
		double yaw;
	}Armor;
	std::ostream& operator<<(std::ostream& o, Armor a) {
		o << '[' << a.class_int << ']' << a.center << "\t" << a.yaw;
		return o;
	}

	typedef struct Unit {
		int class_int;
		double l;
		double s;
	}Unit;
	//�?
	//从相机到装甲板中心的向量(模长distance)与装甲板的一边中点到装甲板中心的向量夹角 的余角即为yaw方向上的偏角

	// double x, y, z;
	// 	double pitch, yaw;
	// 	vector<cv::Point3f>space_points;

	// 	int fu_point_width_up = 300;
	// 	int fu_point_width_down= 363;
	// 	int fu_point_hight = 324;

	// 	cv::Point3f p1(fu_point_width_up / 2, fu_point_hight / 2, 0.0);
	// 	cv::Point3f p2(-fu_point_width_up / 2, fu_point_hight / 2, 0.0);
	// 	cv::Point3f p3(-fu_point_width_down / 2, -fu_point_hight / 2, 0.0);
	// 	cv::Point3f p4(fu_point_width_down / 2, -fu_point_hight / 2, 0.0);
	// 	space_points.push_back(p1);
	// 	space_points.push_back(p2);
	// 	space_points.push_back(p3);
	// 	space_points.push_back(p4);
	// 	cv::solvePnP(space_points, fu_points, this->cameraMatrix, this->distCoeffs, this->rvec, this->tvec);

	//Vector3D Camcerter2;
	//Camcenter2.x=image.armoour_center.x+rol.x;
	//Camcenter2.y=image.armoour_center.x+rol.y;
	//camcenter2.z=distance;

	//print3f Ledgecenter;
	//Ledgecenter.x=image.Leftshang.x;
	//Ledgecenter.y=(image.Leftshang.y+image.Leftxia.y)/2;
	//Ledgecenter.z=(image.Leftshang.z+image.Leftxia.z)/2;

	//Vector3D edge_to_center;
	//edge_to_center.x=-Ledgecenter.x+Camcenter2.x;
	//edge_to_center.y=-Ledgecenter.y+Camcenter2.y;
	//edge_to_center.z=-Ledgecenter.z+Camcenter2.z;

	//double A;
	//A=(Camcenter2.x*edge_to_center.x+Camcenter2.y*edge_to_center.y+camcenter2.z*edge_to_center.z)/(sqrt(Camcenter2.x*Camcenter2.y*Camcenter2.z))*(sqrt(edge_to_center.x*edge_to_center.y*edge_to_center.z));
	//double YAW_angle=90-std::acos(A)*(180.0 / A_PI);

	//std::cout<<"YAW_angle"<<YAW_angle<<std::endl;
	// PID AntiGyro::pid(0,0,0);
	class AntiGyro
	{
	public:
		static PID pid;
		static PID _pid;
		static void Init(ros::NodeHandle& node){
			double kp,ki,kd,dt;
			node.param("kp", kp, 0.6);
			node.param("ki", ki, 0.03);
			node.param("kd", kd, 0.03);
			node.param("dt", dt, 1.0);
			pid = PID(kp,ki,kd,dt);
			_pid = PID(kp,ki,kd,dt);
		}
		// //ab上下横边 cd交叉 ef左右竖边 
		// static Vector3 Rotation_Calc(Vector2 a,Vector2 b,Vector2 c,Vector2 d,Vector2 e,Vector2 f){
		//     Vector3 result = {0,15,0};
		//     result.z = Calculater::_Angle_Calc(a+b,{1,0});
		//     result.x = Calculater::_Angle_Calc(c,d);
		//     std::ofstream o;
		//     o.open("/home/rm/ws_yolov8/outTest.txt",std::ios::app);
		//     o<<result.x<<std::endl;
		//     return result;
		// }
		//r-p-y
		//ab上下横边 cd左右竖边 efgh交叉 
		static Vector3 Rotation_Calc(Vector2 a, Vector2 b, Vector2 c, Vector2 d, Vector2 e, Vector2 f, Vector2 g, Vector2 h) {
			Vector3 result = { 0,15,0 };
			auto temp = a + b;
			auto _temp = e + f + g + h;
			int sign = 0;
			if (temp.x < 0)
				sign = 1;
			result.x = Calculater::_Angle_Calc(temp, { 1,0 });
			result.z = (10 / 21.39) * Calculater::_Module(_temp);
			auto angle = Calculater::_Angle_Calc(temp, _temp);
			if (sign)
				result.x = -result.x;
			if (angle > 90)
				result.z = -result.z;
			result.z = (10 / 21.39) * result.z - 2.057;
			// std::ofstream o;
			// o.open("/home/rm/ws_yolov8/outTest.txt",std::ios::app);
			// o<<result.z<<std::endl;
			std::cout << "ROTATION:" << result << std::endl;

			return result;
		}
		//roll - pitch - yaw
		static Vector3 _Rotation_Calc(const cv::Mat& tvec, const cv::Mat& _tvec) {
			Vector3 result = { 0,15,0 };
			Vector3 temp = { tvec.at<double>(0,0),tvec.at<double>(1,0),tvec.at<double>(2,0) },
				_temp = { _tvec.at<double>(0,0),_tvec.at<double>(1,0),_tvec.at<double>(2,0) };
			Vector3 vec = Calculater::Vector(temp, _temp);
			Vector3 a = { vec.x,0,vec.z }, b = { vec.x,vec.y,0 };
			result.x = Calculater::Angle_Calc(b, { 1,0,0 });
			// result.z = Calculater::Angle_Calc(a,{0,0,1}) - 90;
			double dis = Calculater::Distance(Calculater::xOy(temp), Calculater::xOy(_temp)),
				rdis = Calculater::Distance(temp, _temp),
				ratio = (dis / rdis) * 100;
			double ac = std::acos(ratio / 100) * (180 / A_PI);
			if (vec.y > 0)
				result.x = -result.x;
			// std::cout << "TEST:" << Calculater::Angle_Calc({0,1,0},{1,0,0}) << std::endl;
			std::cout << "VEC:" << vec << std::endl;
			// std::cout << "TVEC:" << tvec << std::endl;
			// std::cout << "_TVEC:" << _tvec << std::endl;
			std::cout << "TEMP:" << temp << std::endl;
			std::cout << "_TEMP:" << _temp << std::endl;
			std::cout << "ROTATION:" << result << std::endl;
			std::cout << "DISTANCE:" << dis << std::endl;
			std::cout << "REAL_DISTANCE:" << rdis << std::endl;
			std::cout << "RATIO:" << ratio << std::endl;
			//  HUCHAO(temp,_temp);
			// std::ofstream o;
			// o.open("/home/rm/ws_yolov8/outTest.txt",std::ios::app);
			// o<<ratio<<std::endl;
			// o.close();
			return result;
		}

		static Vector3 __Rotation_Calc(std::vector<cv::Point2f> pts) {
			Vector3 result = { 0,15,0 };
			Vector2 a = Calculater::_Vector(pts[0]),
				b = Calculater::_Vector(pts[1]),
				c = Calculater::_Vector(pts[2]),
				d = Calculater::_Vector(pts[3]);
			Vector2 roll = Calculater::_Vector(a, b) + Calculater::_Vector(c, d);
			double left = Calculater::_Distance(a, d), right = Calculater::_Distance(b, c);
			result.x = Calculater::_Angle_Calc(roll, { 1,0 });
			result.z = 0;
			if (left < right)
				result.z = left / right * 100;
			else
				result.z = right / left * 100;
			result.z = -45 / 26.1 * result.z + 172.41;
			std::cout << "ROTATION:" << result << std::endl;
			std::ofstream o;
			o.open("/home/rm/ws_yolov8/outTest.txt", std::ios::app);
			o << result.z << std::endl;
			o.close();
			return result;
		}
		static Vector3 ___Rotation_Calc(cv::Mat inp, std::vector<cv::Point2f> pts, cv::Mat upper, cv::Mat lower) {
			static long maxicost = -1;
			auto start = std::chrono::high_resolution_clock::now();
			Vector3 result = { 0,15,0 };
			Vector3 ub = { upper.at<double>(0,0),upper.at<double>(1,0),upper.at<double>(2,0) },
				db = { lower.at<double>(0,0),lower.at<double>(1,0),lower.at<double>(2,0) }, _ub(ub), _db(db);
			Vector2 a = Calculater::_Vector(pts[0]),
				b = Calculater::_Vector(pts[1]),
				c = Calculater::_Vector(pts[2]),
				d = Calculater::_Vector(pts[3]);
			Vector2 roll = Calculater::_Vector(a, b) + Calculater::_Vector(d, c);
			double left = Calculater::_Distance(a, d), right = Calculater::_Distance(b, c);
			result.x = Calculater::_Angle_Calc(roll, { 1,0 });
			double dis = Calculater::DistanceInImage(inp, ub, db);
			double totalZ = 0;
			int loop = 0;
			pid.Clear();
			if (left == right)
				result.z = 0;
			else {
				double error = right - dis;
				double precision = 0;
				// ros::Rate testRate(2);
				//z减小 至 distance 等于 right
				while (std::abs(error) >= ErrorZ) {
					// testRate.sleep();
					precision = -pid.Update(right - dis) * BasicPrecisionZ;
					ub.z += precision;
					db.z += precision;
					dis = Calculater::DistanceInImage(inp, ub, db);
					totalZ += precision;
					error = right - dis;
					// std::cout << "PID_O:" << precision << " ERROR:" << error << " TOTALZ:" << totalZ;
					// std::cout << " UB_Z:" << ub.z <<" DB_Z:"<<db.z<<std::endl;
					loop += 1;
				}
				// std::cout << "ERROR:" << error << std::endl;
				// std::cout << "UB:" << ub << std::endl;
				// std::cout << "DB:" << db << std::endl;
				std::cout << "LOOP:" << loop << std::endl;
			}
			result.z = std::asin(totalZ / (2 * Half_Width)) * 180 / A_PI;
			auto end = std::chrono::high_resolution_clock::now();
			auto duration = std::chrono::duration_cast<std::chrono::milliseconds>(end - start);
			// std::cout << "LEFT:" << left << std::endl; 
			// std::cout << "RIGHT:" << right << std::endl; 
			// std::cout << "DISTANCE:" << dis << std::endl;
			// std::cout << "TOTALZ:" << totalZ << std::endl;
			// std::cout<<"SIN:"<<totalZ/(2 * Half_Width)<<std::endl;
			// std::cout<<"ASIN:"<<std::asin(totalZ/(2 * Half_Width))<<std::endl;
			// std::cout << "ROTATION:" << result << std::endl;
			// std::cout<<"PRE(UP):"<<_ub<<" AFT:"<<ub<<" Right:"<<Calculater::ThreeToTwo(inp,ub)<<" LEFT:"<<pts[2]<<std::endl;
			// std::cout<<"PRE(DOWN):"<<_db<<" AFT:"<<db<<" Right:"<<Calculater::ThreeToTwo(inp,db)<<" LEFT:"<<pts[1]<<std::endl;
			// std::cout<<"PRE(VEC):"<<Calculater::Vector(_ub,_db)<<" AFT:"<<Calculater::Vector(ub,db)<<std::endl;
			if (std::abs(totalZ / (2 * Half_Width)) > 1)
			{
				std::cout << "Param out of range!" << std::endl;
				result.z = 90;
			}
			if (duration.count() > maxicost)
				maxicost = duration.count();
			// std::cout << "PID:" << pid << std::endl;
			std::cout << "COST:" << duration.count() << "ms(Max:" << maxicost << "ms)" << std::endl;
			// std::ofstream o;
			// o.open("/home/rm/ws_yolov8/outTest.txt",std::ios::app);
			// o<<result.z<<std::endl;
			// o.close();
			return result;
		}

		static void Test(cv::Mat inp, cv::Mat upper, cv::Mat lower, std::vector<cv::Point2f>& pts) {
			Vector3 ub = { upper.at<double>(0,0),upper.at<double>(1,0),upper.at<double>(2,0) },
				db = { lower.at<double>(0,0),lower.at<double>(1,0),lower.at<double>(2,0) };
			// double _distance = std::sqrt((std::pow(Half_Width,2)+std::  pow(Half_Height,2)));
			std::cout << "TEST_DISTANCE: " << Calculater::Distance(ub, db) << " | " << Half_Height * 2 << std::endl;
			std::cout << "TEST_DISTANCE_2D: " << Calculater::DistanceInImage(inp, ub, db) << " | (L)" << Calculater::_Distance(Calculater::_Vector(pts[0]), Calculater::_Vector(pts[3])) << " | (R)" << Calculater::_Distance(Calculater::_Vector(pts[1]), Calculater::_Vector(pts[2])) << std::endl;
		}

		//重构装甲板并模拟旋转
		// 
		//正对重构装甲板yOz平面投影如下
		// /\Y
		// |
		// ----> Z
		//       iu --> *--* <-- u
		//	            | / B
		//              |/
		//	            * <-- center
		//             /|  A
		//            / | <-- angle(sita)
		//     l --> *--* <-- il
		// u -- center -- l 为一个装甲板yOz上投影(斜的那条)
		//分段如下
		// A:l to center => 长为半灯条高
		// B:u to upper => 长为半灯条高
		// 在yOz平面下 
		// 有 l - center = -(u - center)
		// 即 l = center - offset u = center + offset
		// offset = u - center || center - l
		// 又有 u = (center.y + Half_Height * sin(sita),center.z + Half_Height - * cos(sita))
		// 所以 offset = (Half_Height * sin(sita),Half_Height * cos(sita))
		// 将 sita 代入 pitch 角度即可求解 yOz上的偏移
		// 
		// 角点如下
		// /\Y
		// |
		// ----> X
		//d *-----* c
		//	|  | /|
		//	|  |/ |
		//	|  *  |
		//	| /|  |
		//	|/ |<--- axis(旋转轴)
		//a *----* b
		//pitch默认15度
		//虚构装甲板不断旋转逼近 至 投影面积与识别面积误差小于阈值(ErrorZ)
		//使用PID进行快速动态逼近 可以将误差调小(不用太小 精度够用就行)
		//尽量保持最大时延小于 3ms (大约6000-7500次迭代)
		//高精度姿态解算(Yaw) 减少维度以解决跳变
		static double Yaw(cv::Mat frame,cv::Mat inp, cv::Mat center, std::vector<cv::Point2f> pts) {
			// namedWindow("abc");
    		auto start = std::chrono::high_resolution_clock::now();
			const double Ratio = 10e3;
			//角度转弧度
			double pitch = Pitch * ToRadian;
			//装甲板重构(正对)旋转角全部置零 并设pitch为15度
			//yOz上偏移
			Vector2 offset = { Half_Height * std::sin(pitch), Half_Height * std::cos(pitch) };
			//中心转换并计算4角点
			//根据上图 ab属于l(-offset) cd属于u(+offset) 
			//x方向上偏移为Half_Width ad负 bc正
			//得出如下转换关系
			Vector3 _center = Calculater::Vector(center),
				a = { _center.x + Half_Width,_center.y - offset.x,_center.z - offset.y },
				b = { _center.x - Half_Width,_center.y - offset.x,_center.z - offset.y },
				c = { _center.x - Half_Width,_center.y + offset.x,_center.z + offset.y },
				d = { _center.x + Half_Width,_center.y + offset.x,_center.z + offset.y };
			//解算装甲板中轴(旋转轴)
			//此处使用点向式
			//先输入轴上一点 再输入轴的方向向量	
			// cv::putText(test,std::to_string(loop),*(_pts+3),cv::FONT_HERSHEY_SIMPLEX,1.0,Scalar(0,0,255));
			// cv::putText(test,std::to_string(angle),*(_pts),cv::FONT_HERSHEY_SIMPLEX,1.0,Scalar(0,255,0));
			// cv::imshow("abc",test)
			//旋转轴显然过中心 所以锚点选择_center
			//pitch 固定 可以求l或u中点以此求方向向量
			//由于偏移量固定为offset且offsetX为0
			//所以方向向量恒为(0,offset.x,offset.y)
			Line axis = { _center,{0,1,0 }};
			// Line axis = { Calculater::Middle(a,b),{0,1,0 }};
			// Line _axis = { Calculater::Middle(c,d),{0,1,0 }};
			//四角点和旋转轴解算完成
			//看看当前投影面积与识别面积的差值是否在误差内

			//计算识别面积
			double area = Calculater::AreaCalc(pts);
			//为了后续高频率运算 使用指针来实现内存复用 减少资源浪费
			// cv::Point2f* _pts = new cv::Point2f(4);
			cv::Point2f _pts[4];
			*_pts = Calculater::ThreeToTwo(inp, a);
			*(_pts + 1) = Calculater::ThreeToTwo(inp, b);
			*(_pts + 2) = Calculater::ThreeToTwo(inp, c);
			*(_pts + 3) = Calculater::ThreeToTwo(inp, d);
			double _area = Calculater::AreaCalc(_pts),lastArea = _area;
			double diffrence = lastArea - area, angle = 0;
			int loop = 0;//迭代次数
			//首次比对 如果小于一定阈值则认为正对
			//返回0
			if (std::abs(diffrence) < ErrorZ){
				std::cout<<"LOOP:"<<loop<<std::endl;
				std::cout<<"ANGLE:"<<angle<<std::endl;
				std::cout<<"AREA:"<<Calculater::AreaCalc(_pts)<<" TARGET:"<<area<<" DIF:"<<diffrence<<std::endl;
				// delete _pts;
				return angle;
			}
			//不满足则迭代至符合后返回
			//迭代需要:
			// diffrence > 0 增大旋转角
			// diffrence < 0 减小旋转角
			//所以pid的误差可以直接选用diffrence
			//p可以设置低一点 pid的灵敏度直接影响运行速度
			//调教比较好的pid可以大幅缩短运行时间
			cv::Mat test;
			int blue = 50;
			pid.Clear();//先清除积分部分 否则影响pid运行效果
			do {
				// test = frame.clone();
				//diffrence已经有初值 初次循环也可以直接使用
				auto change = pid.Update(diffrence/(Ratio));
				angle += change;
				//根据角度值进行旋转
				//TODO:修改Rotate:使用类 减小每次计算变换的资源消耗
				*_pts = Calculater::ThreeToTwo(inp, Calculater::Rotate(a, axis.anchor, axis.vector, angle));
				*(_pts + 1) = Calculater::ThreeToTwo(inp, Calculater::Rotate(b, axis.anchor, axis.vector, angle));
				*(_pts + 2) = Calculater::ThreeToTwo(inp, Calculater::Rotate(c, axis.anchor, axis.vector, angle));
				*(_pts + 3) = Calculater::ThreeToTwo(inp, Calculater::Rotate(d, axis.anchor, axis.vector, angle));
				//再次计算diffrence
				_area = Calculater::AreaCalc(_pts);
				diffrence = _area - area;
				//由于yaw偏角最大是90度 最终角度大于等于90度 且 面积差小于100倍阈值时 认为识别失败
				//返回360度 用以标识计算失败
				if ((std::abs(angle) >= 90 && loop >=2000)||loop >= 3000 || std::abs(angle) >= 360){
					auto end = std::chrono::high_resolution_clock::now();
					auto duration = std::chrono::duration_cast<std::chrono::milliseconds>(end - start);
					return 360;
				}
				loop += 1;
				// // std::this_thread::sleep_for(std::chrono::milliseconds(1));
				// std::cout<<"LOOP:"<<loop<<std::endl;
				// std::cout<<"A:"<<*_pts<<" B:"<<*(_pts+1)<<" C:"<<*(_pts+2)<<" D:"<<*(_pts+3)<<std::endl;
				// std::cout<<"ANGLE:"<<angle<<" CHANGE:"<<change<<std::endl;
				// std::cout<<"ACHANGE:"<<_area - lastArea<<std::endl;
				// std::cout<<"AREA:"<<Calculater::AreaCalc(_pts)<<" TARGET:"<<area<<" DIF:"<<diffrence<<std::endl;

				// for(int i = 0;i<4;i++){
				// 	for(int f = 0;f<4;f++){
				// 		if(f == i)
				// 			continue;
				// 		else
				// 			cv::line(test,pts[i],pts[f],cv::Scalar(255,255,255),3,8);
				// 	}
				// }
				// for(int i = 0;i<4;i++){
				// 	for(int f = 0;f<4;f++){
				// 		if(f == i)
				// 			continue;
				// 		else
				// 			cv::line(test,_pts[i],_pts[f],cv::Scalar(blue,0,0),3,8);
				// 	}
				// }
				// if(blue>=255)
				// 	blue = 50;
				// else
				// 	blue += 1;
				// cv::putText(test,std::to_string(loop),*(_pts+3),cv::FONT_HERSHEY_SIMPLEX,1.0,Scalar(0,0,255));
				// cv::putText(test,std::to_string(angle),*(_pts),cv::FONT_HERSHEY_SIMPLEX,1.0,Scalar(0,255,0));
				// cv::imshow("abc",test);
				// waitKey(50);
				lastArea = _area;
			} while (std::abs(diffrence) >= ErrorZ);
			std::cout<<"LOOP:"<<loop<<std::endl;
			std::cout<<"ANGLE:"<<angle<<std::endl;
			std::cout<<"AREA:"<<Calculater::AreaCalc(_pts)<<" TARGET:"<<area<<" DIF:"<<diffrence<<std::endl;
			//此时投影面积与识别面积差值已经低于阈值
			//直接总共返回旋转的角度 angle
			// delete _pts;
			auto end = std::chrono::high_resolution_clock::now();
			auto duration = std::chrono::duration_cast<std::chrono::milliseconds>(end - start);
			std::cout<<"COST:"<<duration.count()<<"ms"<<std::endl;
			if(angle>90)
				return 360;
			else
				return angle;
		}
		static double _Yaw(cv::Mat frame,cv::Mat inv,std::vector<cv::Point2f> pts) {
			// namedWindow("abc");
    		auto start = std::chrono::high_resolution_clock::now();
			constexpr double RATIO = 10e4;
			Vector2 roll_vec = Calculater::_Vector(Calculater::_Vector(pts[0]), Calculater::_Vector(pts[1])) + Calculater::_Vector(Calculater::_Vector(pts[3]), Calculater::_Vector(pts[2]));
			double roll = Calculater::_Angle_Calc(roll_vec,Calculater::_Vector(cv::Point2f(1,0))) * (A_PI / 180);
			if(roll_vec.x >= 0 && roll_vec.y <= 0)
				roll = -roll;
			double area = Calculater::AreaCalc(pts);
			double angle = 0;
			int loop = 0;
			double diff = 0;
			double area_radio = 0;

			cv::Mat test;
			pid.Clear();//先清除积分部分 否则影响pid运行效果
			do {
				if(loop >= 2000)
					return ~(1 << (sizeof(double)*8 - 1));
				loop += 1;
				
				vector<cv::Point2f> _pts;
				angle += pid.Update(diff/RATIO);
				{
					auto temp_pts = fourPointInOdomToCam(roll,15,angle);
					for(auto&i:temp_pts)
						_pts.push_back(Calculater::ThreeToTwo(inv,Calculater::Vector(cv::Point3f((float)i.x(),(float)i.y(),(float)i.z()))));
				}
				diff = Calculater::AreaCalc(_pts) - area;
				// _pts.clear();

			// 	// std::cout<<"LOOP:"<<loop<<std::endl;
			// 	// std::cout<<"ANGLE:"<<angle<<std::endl;
			// 	// std::cout<<"AREA:"<<Calculater::AreaCalc(_pts)<<" TARGET:"<<area<<" DIF:"<<std::abs(diff)<<std::endl;
			// 	// test = frame.clone();
			// 	// for(int i = 0;i<4;i++){
			// 	// 	for(int f = 0;f<4;f++){
			// 	// 		if(f == i)
			// 	// 			continue;
			// 	// 		else
			// 	// 			cv::line(test,_pts[i],_pts[f],cv::Scalar(255,255,255),3,8);
			// 	// 	}
			// 	// }
			// 	// cv::putText(test,std::to_string(loop),_pts[3],cv::FONT_HERSHEY_SIMPLEX,1.0,Scalar(0,0,255));
			// 	// cv::putText(test,std::to_string(angle),_pts[0],cv::FONT_HERSHEY_SIMPLEX,1.0,Scalar(0,255,0));
			// 	// cv::putText(test,std::to_string(Calculater::AreaCalc(_pts)),_pts[1],cv::FONT_HERSHEY_SIMPLEX,1.0,Scalar(255,255,0));
			// 	// cv::putText(test,std::to_string(area),_pts[2],cv::FONT_HERSHEY_SIMPLEX,1.0,Scalar(255,0,255));
			// 	// cv::imshow("abc",test);
			// 	// waitKey(10);
			} while (std::abs(diff) >= ErrorZ);
			vector<cv::Point2f> _pts;
			auto temp_pts = fourPointInOdomToCam(0,0,0);
			// for(auto&i:temp_pts)
			// 	_pts.push_back(Calculater::ThreeToTwo(inv,Calculater::Vector(cv::Point3f((float)i.x(),(float)i.y(),(float)i.z()))));
			// for(auto i = _pts.begin();i!=_pts.end();i++)
			// 	for(auto f = _pts.begin();f!=_pts.end();f++)
			// 		cv::line(frame,*i,*f,cv::Scalar(255,255,255),3,8);
			angle = std::acos(area / Calculater::AreaCalc(_pts));
			// cout << "area:" << area << "	" << "area_" << Calculater::AreaCalc(_pts) << endl;
			// std::cout<<"LOOP:"<<loop<<std::endl;
			// std::cout<<"ANGLE:"<<angle<<std::endl;
			auto end = std::chrono::high_resolution_clock::now();
			auto duration = std::chrono::duration_cast<std::chrono::milliseconds>(end - start);
			std::cout<<"COST:"<<duration.count()<<"ms"<<std::endl;
			return (angle * (180 / A_PI)) - (int)((angle * (180 / A_PI))/360)*360;
		}
		static double __Yaw(cv::Mat frame,cv::Mat inv,std::vector<cv::Point2f> pts) {
			// namedWindow("abc");
    		auto start = std::chrono::high_resolution_clock::now();
			constexpr double RATIO = 10e4;
			Vector2 roll_vec = Calculater::_Vector(Calculater::_Vector(pts[0]), Calculater::_Vector(pts[1])) + Calculater::_Vector(Calculater::_Vector(pts[3]), Calculater::_Vector(pts[2]));
			double roll = Calculater::_Angle_Calc(roll_vec,Calculater::_Vector(cv::Point2f(1,0))) * (A_PI / 180);
			if(roll_vec.x >= 0 && roll_vec.y <= 0)
				roll = -roll;
			Vector2 uborder = Calculater::_Vector(Calculater::_Vector(pts[0]),Calculater::_Vector(pts[1]));
			double area = Calculater::AreaCalc(pts),dis = (Calculater::_Distance(Calculater::_Vector(pts[2]),uborder) + Calculater::_Distance(Calculater::_Vector(pts[3]),uborder))/2;
			double angle = 0;
			int loop = 0;
			double diff = 0;
			double pitch = 0;
			//先算pitch
			_pid.Clear();
			cv::Mat test;
			do
			{
				if(loop >= 1000 || std::abs(pitch) > 2*A_PI){
					pitch = 0;
					break;
				}
				loop += 1;

				vector<cv::Point2f> _pts;
				pitch += _pid.Update(diff/RATIO * 100);
				{
					auto temp_pts = fourPointInOdomToCam(roll,pitch,0);
					for(auto&i:temp_pts)
						_pts.push_back(Calculater::ThreeToTwo(inv,Calculater::Vector(cv::Point3f((float)i.x(),(float)i.y(),(float)i.z()))));
				}
				uborder = Calculater::_Vector(Calculater::_Vector(_pts[0]),Calculater::_Vector(_pts[1]));
				double current = (Calculater::_Distance(Calculater::_Vector(_pts[2]),uborder) + Calculater::_Distance(Calculater::_Vector(_pts[3]),uborder))/2;
				diff = current - dis;
				
				std::cout<<"LOOP:"<<loop<<std::endl;
				std::cout<<"PITCH:"<<pitch<<std::endl;
				std::cout<<"CUR:"<<current<<"TARGET:"<<dis<<" DIF:"<<(diff)<<std::endl;
				test = frame.clone();
				for(int i = 0;i<4;i++){
					for(int f = 0;f<4;f++){
						if(f == i)
							continue;
						else
							cv::line(test,_pts[i],_pts[f],cv::Scalar(255,255,255),3,8);
					}
				}
				cv::putText(test,std::to_string(loop),_pts[3],cv::FONT_HERSHEY_SIMPLEX,1.0,Scalar(0,0,255));
				cv::putText(test,std::to_string(pitch),_pts[0],cv::FONT_HERSHEY_SIMPLEX,1.0,Scalar(0,255,0));
				cv::imshow("abc",test);
				waitKey(10);
			} while (std::abs(diff) >= ErrorZ * 10);
			pitch = (angle * (180 / A_PI)) - (int)((angle * (180 / A_PI))/360)*360;
			std::cout<<"Calculated pitch:"<<pitch<<std::endl;
			waitKey(1500);
			loop = 0;
			diff = 0;
			pid.Clear();//先清除积分部分 否则影响pid运行效果
			do {
				if(loop >= 2000 || std::abs(angle) > 2*A_PI)
					return 1 << (sizeof(double) * 8 - 1);
				loop += 1;
				
				vector<cv::Point2f> _pts;
				angle += pid.Update(diff/RATIO);
				{
					auto temp_pts = fourPointInOdomToCam(roll,pitch,angle);
					for(auto&i:temp_pts)
						_pts.push_back(Calculater::ThreeToTwo(inv,Calculater::Vector(cv::Point3f((float)i.x(),(float)i.y(),(float)i.z()))));
				}
				diff = Calculater::AreaCalc(_pts) - area;
				// _pts.clear();

				std::cout<<"LOOP:"<<loop<<std::endl;
				std::cout<<"PITCH:"<<pitch<<std::endl;
				std::cout<<"ANGLE:"<<angle<<std::endl;
				std::cout<<"AREA:"<<Calculater::AreaCalc(_pts)<<" TARGET:"<<area<<" DIF:"<<std::abs(diff)<<std::endl;
				// cv::putText(frame,("Yaw:" +std::to_string(yaw_angle)) ,image.armour_points[0],cv::FONT_HERSHEY_SIMPLEX,1.0,cv::Scalar(0,255,0));
				test = frame.clone();
				for(int i = 0;i<4;i++){
					for(int f = 0;f<4;f++){
						if(f == i)
							continue;
						else
							cv::line(test,_pts[i],_pts[f],cv::Scalar(255,255,255),3,8);
					}
				}
				cv::putText(test,std::to_string(loop),_pts[3],cv::FONT_HERSHEY_SIMPLEX,1.0,Scalar(0,0,255));
				cv::putText(test,std::to_string(pitch),_pts[1],cv::FONT_HERSHEY_SIMPLEX,1.0,Scalar(255,0,0));
				cv::putText(test,std::to_string(angle),_pts[0],cv::FONT_HERSHEY_SIMPLEX,1.0,Scalar(0,255,0));
				cv::imshow("abc",test);
				waitKey(10);
			} while (std::abs(diff) >= ErrorZ);
			std::cout<<"LOOP:"<<loop<<std::endl;
			std::cout<<"PITCH:"<<pitch<<std::endl;
			std::cout<<"ANGLE:"<<angle<<std::endl;
			//此时投影面积与识别面积差值已经低于阈值
			//直接总共返回旋转的角度 angle
			// delete _pts;
			auto end = std::chrono::high_resolution_clock::now();
			auto duration = std::chrono::duration_cast<std::chrono::milliseconds>(end - start);
			std::cout<<"COST:"<<duration.count()<<"ms"<<std::endl;
			return (angle * (180 / A_PI)) - (int)((angle * (180 / A_PI))/360)*360;
		}
		//两个装甲板的yaw偏角啊a,b,
		//装甲板中心center1 center2w

		static Vector2 L_S(cv::Point3d center1, cv::Point3d center2, double a, double b)
		{
			double d = sqrt(center1.x * center2.x + center1.z * center2.z + center1.y + center2.y);
			double c = sqrt(center1.x * center2.x + center1.z * center2.z) / d;
			double e = 0;//中间变量
			double L = d * sin(abs(a));;//长轴
			double S = d * sin(abs(b));;//短轴
			if (c != 1)
			{
				if (L < S)
				{
					e = S;
					S = L;
					L = e;
				}
				else
				{
					throw std::exception();
				}
			}
			else {
				throw std::exception();
			};
			std::cout << "LOOG" << L << std::endl;
			std::cout << "SHOOT" << S << std::endl;
			return { L,S };
		};

		static void Test() {
			Vector3 a1 = { 1,0,0 }, anchor = { 0,0,0 }, diration = { 0,0,1 };
			std::cout << "旋转:" << Calculater::Rotate(a1, anchor, diration, 180) << std::endl;
		}

		static void HC(Vector3 tvec, Vector3 _tvec) {

			Vector3 vec = { 1,1,1 };
			vec.x = (tvec.x + _tvec.x) / 2;
			vec.y = (tvec.y + _tvec.y) / 2;
			vec.z = (tvec.z + _tvec.z) / 2000;

			Vector3 edge_to_center = { 0,0,0 };
			edge_to_center.x = (vec.x - _tvec.x) / 1000;
			edge_to_center.y = 0;
			edge_to_center.z = tvec.z / 1000;

			double A, B, C;
			A = vec.x * edge_to_center.x + vec.y * edge_to_center.y + vec.z * edge_to_center.z;
			B = (Calculater::Module(edge_to_center) * Calculater::Module(vec));
			C = A / B;
			double YAW_angle = std::acos(C) * (180.0 / A_PI);
			// std::cout<<"YAW_angle:"<<YAW_angle<<std::endl;
			// std::cout << "vec:" << vec << std::endl;
			// std::cout << "A:" << A << std::endl;
			// std::cout << "B:" << B << std::endl;
			// std::cout << "C:" << C << std::endl;
		}
	};
	PID AntiGyro::pid(0.6, 0.03, 0.03, 1.0);
	PID AntiGyro::_pid(0.6, 0.03, 0.03, 1.0);
}