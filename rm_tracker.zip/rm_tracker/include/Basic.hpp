#ifndef BASIC
#define BASIC
#include <iostream>
#include "rmrm/RmSerial.h"
#include "ThreadPool.hpp"
#include "Locked.hpp"
#include "ros/ros.h"
#include "FrameCounter.hpp"
#include "opencv2/core.hpp"
#include <cv_bridge/cv_bridge.h>
#include "Yolov8.h"
#include "Yolov8_fu.h"
#include "Image.h"
#include "Light.h"
#include "Tracker.hpp"
#include "Calculater.hpp"
#include "test_compensation.hpp"
#include "ImuData.hpp"
#include "visual.hpp"

using namespace cv;
using namespace Tools;
using namespace std;

// const std::string input_Amodel_path = "/home/rm/桌面/test_model/best.xml";
const std::string input_Amodel_path = "/home/rm/桌面/QX_model_v1_openvino/QX_model_v1.onnx";
const std::string input_Fmodel_path = "/home/rm/桌面/fu_model2/best.xml";
AverageCounter<20> acTemp;
const long Start = GetTimestramp();
ThreadPool pool(Tools::PoolType::CPUDense,2);
Image image;
Light light(0, 45, 0, 86, 255, 255, 0);
Locked<Mat> frame;
Locked<rmrm::RmSerial> serial;
Locked<ImuData> imu;
Locked<char> camp('r');
FrameCounter<10> fcr;
AverageCounter<20> ftcr;
AverageCounter<20> sftcr;
Config ConfigArmor = { 0.2,0.4,0.4,640,640, input_Amodel_path};
Fu::Config ConfigFu = { 0.2,0.4,0.4,640,640, input_Fmodel_path};
Locked<YOLOV8*> ModelArmor(NULL);
Locked<Fu::YOLOV8FU*> ModelFu(NULL);
CAL::Calculater* cal = NULL;
Tracer<TRACE_FRAME>* tracer = NULL;
ros::Subscriber Camera,Serial;
ros::Publisher PubAngle;
long lastTime = 0;
double syncFrameTime = 0.0;
bool isFrameComfirm = true;
void AnglePub(double x,double y,double z,bool detect = false,bool shoot = false){
    // cout << "PUB : " << x << ' ' << y << endl;
    geometry_msgs::Vector3 angle;
    //角度限制
    if(abs(x) > X_LIMIT){
        if(x < 0)
            angle.x = -X_LIMIT;
        else
            angle.x = X_LIMIT;
    }
    else
        angle.x = x;
    if(abs(y) > P_LIMIT){
        if(y < 0)
            angle.y = -P_LIMIT;
        else
            angle.y = P_LIMIT;
    }
    else
        angle.y = y;
    uint signal = 0;
    if(detect)
        signal |= 0x01;
    if(shoot)
        signal |= 0x02;
    angle.z = signal;
    PubAngle.publish(angle);
}
double YawCalc(const Armor& target,double& res,double minimum,double maximum,double step = 0.01){
    double yawCount = minimum;
    double minDisErr = 9999999;
    double err = 0;
    auto targetInOdom = target.odomCenter;
    while(yawCount <= maximum){
        auto targetsInCam = cal->RebuildArmorInOdom({-15.0 * D2R,yawCount,0},targetInOdom);
        std::vector<Point2f> pixelPoint;
        for(int i = 0; i < targetsInCam.size(); i++)
            pixelPoint.push_back(cal->ThreeToTwo(targetsInCam[i]));
        // err = abs(Tools::Calculater::AreaCalc(pixelPoint) - Tools::Calculater::AreaCalc(target.points));
        err = cal->CalPointsDis(pixelPoint, target.points);
        if(err <= minDisErr) {
            minDisErr = err;
            res = yawCount;
        }
        yawCount += step;
    }
    return minDisErr;
}
void SetFrame(const sensor_msgs::ImageConstPtr img){
    cv_bridge::CvImagePtr cv_ptr; // 声明一个CvImage指针的实例
    try
    {
        cv_ptr =  cv_bridge::toCvCopy(img, sensor_msgs::image_encodings::BGR8); //将ROS消息中的图象信息提取，生成新cv类型的图象，复制给CvImage指针
    }
    catch(cv_bridge::Exception& e)  //异常处理
    {
        ROS_ERROR("cv_bridge exception: %s", e.what());
        return;
    }
    frame.Change(cv_ptr->image.clone());
    isFrameComfirm = false;
    // cout << "NEW_FRAME:" << isFrameComfirm << endl;
}
void ShowFrame(cv::Mat _frame,const char* winname = "frame",bool withFPS = true,bool withFT = true){
    if(_frame.empty() || (!Debug && !SHOW_IMG))
        return;
    frame.Release();
    if(DRAW_CAMERA_CENTER)
        cv::circle(_frame, image.camera_center, 3, cv::Scalar(0, 255, 0), -1);
    if(DRAW_CAMERA_CENTER_COMPENSATED)
        cv::circle(_frame, image.camera_center_compensate, 3, cv::Scalar(255, 255, 0), -1);
    if(withFT)
        cv::putText(_frame,(std::to_string(ftcr.GetAverageValue())) ,Point2f(0,50),cv::FONT_HERSHEY_SIMPLEX,1.0,cv::Scalar(0,255,0));
    if(withFPS)
        cv::putText(_frame,(std::to_string(1000/ftcr.GetAverageValue())) ,Point2f(0,120),cv::FONT_HERSHEY_SIMPLEX,1.0,cv::Scalar(0,255,0));
    imshow(winname,_frame);
    cv::waitKey(DELAY);
}
void ShowFrame(const char* winname = "frame",bool withFPS = true,bool withFT = true){
    cv::Mat _frame = frame.Get()->clone();
    if(_frame.empty() || (!Debug && !SHOW_IMG))
        return;
    frame.Release();
    if(DRAW_CAMERA_CENTER)
        cv::circle(_frame, image.camera_center, 3, cv::Scalar(0, 255, 0), -1);
    if(DRAW_CAMERA_CENTER_COMPENSATED)
        cv::circle(_frame, image.camera_center_compensate, 3, cv::Scalar(255, 255, 0), -1);
    if(withFT)
        cv::putText(_frame,(std::to_string(ftcr.GetAverageValue())) ,Point2f(0,50),cv::FONT_HERSHEY_SIMPLEX,1.0,cv::Scalar(0,255,0));
    if(withFPS)
        cv::putText(_frame,(std::to_string(1000/ftcr.GetAverageValue())) ,Point2f(0,120),cv::FONT_HERSHEY_SIMPLEX,1.0,cv::Scalar(0,255,0));
    imshow(winname,_frame);
    cv::waitKey(DELAY);
}
void SetSerial(const rmrm::RmSerialConstPtr _serial){
    if(!Debug && RECORD_SYNC_FT){
        static long lastSyncTime = GetTimestramp();
        static long lastPT = GetTimestramp();
        long ctime = GetTimestramp(), delay = ctime - lastSyncTime;
        if(ctime - lastPT >= NO_DEBUG_SYNC_TS){
            syncFrameTime = sftcr.GetAverageValue();
        }
        lastSyncTime = GetTimestramp();
        sftcr.Updata(delay);
    }
    syncFrameTime = sftcr.GetAverageValue();
    serial.Change(*_serial);
    camp.Change((char)_serial->Camp);
    auto _imu = imu.Get();
    _imu->Qtn[0] = _serial->Qw;
    _imu->Qtn[1] = _serial->Qx;
    _imu->Qtn[2] = _serial->Qy;
    _imu->Qtn[3] = _serial->Qz;
    _imu->Pose[0] = _serial->Roll;
    _imu->Pose[1] = _serial->Pitch;
    _imu->Pose[2] = _serial->Yaw;
    cal->SetImuPose(_serial->Roll,_serial->Pitch,_serial->Yaw);
    imu.Release();
}
double GetCompensateAngle(Eigen::Vector3d posInOdom,double bulletMass,double bulletVec = 30.0){
    double result = 0.0,error = DOUBLE_MAX,deep = fabs(posInOdom. x()),height = posInOdom.z();
    long loopTime = 0;
    // cout << "d:" << deep << ' ' << "h:" << height << endl;
    for(double xita = (COMPENSATE_BEGIN_ANGLE + COMPENSATE_END_ANGLE) / 2;xita <= COMPENSATE_END_ANGLE && xita >= COMPENSATE_BEGIN_ANGLE;){
        loopTime += 1;
        double  t0 = deep / (bulletVec * cos(xita)),
                vy0 = bulletVec * sin(xita),
                arh = vy0 * t0 - ((LOCAL_G * t0 * t0) / 2),
                cerror = arh - height;
        if(abs(cerror) <= ENUM_ERROR){
            result = xita;
            break;
        }
        else if(abs(cerror) < error){
            error = abs(cerror);
            result = xita;
        }
        else if(loopTime >= 15000)
            break;
        if(cerror > 0)
            xita -= ENUM_STEP;
        else
            xita += ENUM_STEP;
        if(Debug || 1){
            double  th = vy0 / LOCAL_G,
                    maxArh = vy0 * t0 - ((LOCAL_G * t0 * t0) / 2),
                    upTimeRatio = th / t0;
            cout << "--------------------------- COMPENSATE ---------------------------" << endl <<
            "Loop time: " << loopTime << endl << 
            "T0       : " << t0 << endl <<
            "Cur-Xita : " << xita << endl <<
            "Cur-XitaD: " << xita * R2D << endl <<
            "V-Y      : " << vy0 << endl <<
            "T0-th    : " << t0 - th << endl <<
            "th/T0(%) : " << upTimeRatio * 100 << endl <<
            "Ar-Height: " << arh << endl <<
            "ArMHeight: " << maxArh << endl <<
            "Height-D : " << cerror << endl << 
            "result   : " << result << endl;
        }
        Sleep(10);
    }
    if(Debug)
        cout << "Final    : " << result <<'(' << result * R2D << "D)" << endl;
    return result;
}
void Init(ros::NodeHandle& nh){
    namedWindow("frame");
    nh.param("DebugMode",Debug,DEBUG_FLAG);
    PubAngle = nh.advertise<geometry_msgs::Vector3>("/auto_angle",1000);
    Camera = nh.subscribe("/hikrobot_camera/rgb", 1000, SetFrame);
    Serial = nh.subscribe("/RmSerialData", 1000, SetSerial);
    cal = new CAL::Calculater(image.cameraMatrix,nh);
    tracer = new Tracer<TRACE_FRAME>(nh,pool,cal,&image);
    Locked<int> signal(0);
    pool.AddTask([&signal](void*){
        auto temp = new YOLOV8(ConfigArmor);
        ModelArmor.Change(temp);
        *signal.Get() += 1;
        signal.Release();
    },NULL);
    pool.AddTask([&signal](void*){
        // auto temp = new Fu::YOLOV8FU(ConfigFu);
        // ModelFu.Change(temp);
        *signal.Get() += 1;
        signal.Release();
    },NULL);
    while(1){
        Sleep(500);
        if(signal.GetWithoutLock() != 2)
            continue;
        else
            break;
    }
    std::cout << "Initialized Cost " << GetTimestramp() - Start << " ms" << endl;
}
void Release(ros::NodeHandle& nh){
    auto mArmor = ModelArmor.Get();
    delete mArmor;
    mArmor = NULL;
    ModelArmor.Release();

    auto mFu = ModelFu.Get();
    delete mFu;
    mFu = NULL;
    ModelFu.Release();

    delete cal;
    cal = NULL;

    delete tracer;
    tracer = NULL;
}
#endif