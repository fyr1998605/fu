#ifndef _YOLOV8_FU_H
#define _YOLOV8_FU_H


#include <openvino/openvino.hpp>
#include <iostream>
#include<string>
#include<time.h>
#include <fstream>
#include <vector>
#include <random>
#include <opencv2/dnn.hpp>
#include <opencv2/imgproc.hpp>
#include <opencv2/highgui.hpp>
#include <opencv2/opencv.hpp>
#include <Eigen/Dense>
#include <fstream>
#include "KalmanFilter.h"


#include "ros/ros.h"
#include "sensor_msgs/Image.h"
#include <cv_bridge/cv_bridge.h>
#include <image_transport/image_transport.h>
#include <camera_info_manager/camera_info_manager.h>


using namespace cv;
using namespace std;
using namespace dnn;
using namespace cv::dnn;


//用于设置参数（调用时传参就行了 格式：置信度阈值、nms阈值、评分阈值、模型输入宽度W、模型输入高度H、模型路径）
namespace Fu{

struct Config {
	float confThreshold;	//置信度阈值
	float nmsThreshold;		//nms阈值，一般情况下根据场景和数据集来定，0.3-0.5比较常见
	float scoreThreshold;	//评分阈值
	int inpWidth;			//模型输入宽度
	int inpHeight;			//模型输入高度
	std::string onnx_path;	//模型路径
};

struct Resize
{
	cv::Mat resized_image;	//用于接收resized后的图片
	int dw;					//用于接收W方向padding值
	int dh;					//用于接收H方向padding值
};

//用于接收推理数据
struct Detection 
{
	int class_id;		//用于接收推理时的class_id
	float confidence;	//用于接收推理时的的confidence用于进行nms操作
	cv::Rect box;		//用于临时接收推理得出的box进行绘制
    std::vector<cv::Point2f> points; //四个关键点的xy
};

double calculate_iou(const cv::Rect& rect1, const cv::Rect& rect2)
{
    // 计算交集
    cv::Rect intersection = rect1 & rect2;

    // 计算并集
    cv::Rect union_rect = rect1 | rect2;

    // 计算 IOU
    double iou = static_cast<double>(intersection.area()) / union_rect.area();

    return iou;
}

class YOLOV8FU {
public:
    cv::Ptr<cv::ml::SVM> svm;
    //构造函数
    //利用自定义的Config结构体接口对模型参数以及输入参数进行初始化
	YOLOV8FU(Config config);

	
    //析构函数
	~YOLOV8FU();
	vector<Detection> detect(cv::Mat& frame,bool is_show);//推理函数，调用即可实现推理
    bool Initialized();

private:
    bool initialized = false;
	//设置置信度阈值，nms阈值，评分阈值
	float confThreshold;
	float nmsThreshold;
	float scoreThreshold;

	//输入图像的大小受inpWidth和inpHeight参数的控制，需要自己在Config中设置
	int inpWidth;
	int inpHeight;
	
	float rx;							//原始图像和调整大小后的图像的 宽度x 比例
	float ry;							//原始图像和调整大小后的图像的 高度y 比例
	std::string onnx_path;				//输入模型路径
	Resize resize;						//用于对输入图像进行Resize
	ov::Tensor input_tensor;			//获取输入
	ov::InferRequest infer_request;		//执行预测
	ov::CompiledModel compiled_model;	//模型加载

	//推理三部曲：初始化、前处理、后处理
	void initialmodel();
	void preprocess_img(cv::Mat& frame);
	vector<Detection> postprocess_img(cv::Mat& frame, float* detections, ov::Shape & output_shape, bool is_show=false);
};


//在这里设置自己的模型的类别信息
const vector<string> classname = 
{       
    "blue_R",
    "blue_target",
    //"blue_Actvatived",
    "red_R",
    "red_target",
    //"red_Actvatived"
};


bool YOLOV8FU::Initialized(){return this->initialized;}
//自定义的构造函数，用于初始化参数的配置
YOLOV8FU::YOLOV8FU(Config config) 
{
	this->confThreshold = config.confThreshold;//置信度阈值
	this->nmsThreshold = config.nmsThreshold;//非极大值抑制阈值
    this->scoreThreshold = config.scoreThreshold;//评分阈值，用于mAP
	this->inpWidth = config.inpWidth;//输入宽度
	this->inpHeight = config.inpHeight;//输入高度
	this->onnx_path = config.onnx_path;//onnx路径
    this->svm = cv::Algorithm::load<cv::ml::SVM>("/home/rm/桌面/fu_model2/svm.xml");
    // 检查 SVM 是否为空
    // if (svm.empty()) 
    // {
    //     std::cout << "SVM加载失败!" << std::endl;
    // }
    // else
    // {
    //     std::cout << "SVM加载完毕!" << std::endl;
    // }
    this->initialmodel();
}
//析构函数
YOLOV8FU::~YOLOV8FU(){}


//目标检测
vector<Detection> YOLOV8FU::detect(Mat & frame, bool is_show=false) 
{
    //调用预处理
    preprocess_img(frame);
    //执行预测
    infer_request.infer();
    //获取输出数据
    const ov::Tensor& output_tensor = infer_request.get_output_tensor();
   
    //将图片变回原大小后调用后处理
    ov::Shape output_shape = output_tensor.get_shape();
    float* detections = output_tensor.data<float>();
    return this->postprocess_img(frame, detections, output_shape, is_show);
}


//模型初始化
void YOLOV8FU::initialmodel() 
{
    clock_t start_model_init,end_model_init;
    start_model_init = clock();

    ov::Core core;
    //std::cout<<"core已创建"<<endl;
    std::shared_ptr<ov::Model> model = core.read_model(this->onnx_path);
    //std::cout<<"yolov8的onnx/xml模型已经被成功读入"<<endl;
    ov::preprocess::PrePostProcessor ppp = ov::preprocess::PrePostProcessor(model);
    //std::cout<<"用于对模型进行预处理与后处理的类对象“ppp”已被创建，并由读入的模型初始化"<<endl;

    ppp.input().tensor().set_element_type(ov::element::u8).set_layout("NHWC").set_color_format(ov::preprocess::ColorFormat::RGB);
    //std::cout<<"已成功设置输入 tensor 的元素类型为无符号 8 位整数（u8），排列方式（布局）为 NHWC，颜色格式为 RGB。"<<endl;

    ppp.input().preprocess().convert_element_type(ov::element::f32).convert_color(ov::preprocess::ColorFormat::BGR).scale({ 255, 255, 255 });// .scale({ 112, 112, 112 });
    //std::cout<<"已成功对输入进行预处理，将输入 tensor 的元素类型从 u8 转换为 IEEE 浮点数 32 位（f32），颜色格式从 RGB 转换为 RGB，然后将像素值缩放至 [0, 1] 的范围。"<<endl;
    ppp.input().model().set_layout("NCHW");
    ppp.output().tensor().set_element_type(ov::element::f32);
    model = ppp.build();
    //std::cout<<"已将根据之前的设置，构建一个新的 ov::Model 对象并返回。"<<endl;
    this->compiled_model = core.compile_model(model, "GPU");//如果GPU效果不理想，这里可能要改为CPU，如果没装核显驱动，就改成CPU
    //std::cout<<"已成功设置调用硬件为CPU"<<endl;
    this->infer_request = compiled_model.create_infer_request();
    //std::cout<<"已成功创建推理请求"<<endl;

    end_model_init = clock();
    std::cout << "模型推理请求创建耗时 = " << double(end_model_init - start_model_init) / CLOCKS_PER_SEC << "s" << std::endl;
    initialized = true;
}


//图片预处理（前处理）
void YOLOV8FU::preprocess_img(Mat& frame) 
{
    try {
        //将图片长宽resize成输入大小
        float width = frame.cols;
        float height = frame.rows;
        cv::Size new_shape = cv::Size(inpWidth, inpHeight);
        float r = float(new_shape.width / max(width, height));
        int new_unpadW = int(round(width * r));
        int new_unpadH = int(round(height * r));

        //cout<<"check_section1"<<endl;
        //std::cout <<"等比例缩放后："<< new_unpadW << " " << new_unpadH << endl;


        clock_t start_resize, end_resize;//设置计时标志，用于显示推理时间
        start_resize = clock();

        cv::resize(frame, resize.resized_image, cv::Size(new_unpadW,new_unpadH), 1, 1, cv::INTER_AREA);
        //resizeByAreaInterpolation(frame,resize.resized_image,new_unpadW,new_unpadH);
        //std::cout<<"成功调用我的的resize"<<endl;
        end_resize = clock();
        //std::cout << "my resize running time = " << double(end_resize - start_resize) / CLOCKS_PER_SEC << "s" << std::endl;
        //std::cout<<"成功对图片进行进行resize操作"<<endl;

        resize.resized_image = resize.resized_image;
        resize.dw = new_shape.width - new_unpadW;   //W方向padding值
        resize.dh = new_shape.height - new_unpadH;  //H方向padding值
        cv::Scalar color = cv::Scalar(100, 100, 100);

        cv::copyMakeBorder(resize.resized_image, resize.resized_image, 0, resize.dh, 0, resize.dw, cv::BORDER_CONSTANT, color);

        //imshow("padding",resiz0.102186se.resized_image);
        //std::cout<<"成功执行padding操作"<<endl;


        this->rx = (float)frame.cols / (float)(resize.resized_image.cols - resize.dw);
        this->ry = (float)frame.rows / (float)(resize.resized_image.rows - resize.dh);


        float* input_data = (float*)resize.resized_image.data;
        //std::cout<<"已成功将resize后的图片数据转换为浮点型"<<endl;
        input_tensor = ov::Tensor(compiled_model.input().get_element_type(), compiled_model.input().get_shape(), input_data);
        //std::cout<<"已成功将数据转换为设置好的Tensor类型"<<endl;
        infer_request.set_input_tensor(input_tensor);
        //std::cout<<"已成功将Tensor数据传给模型进行推理"<<endl;
    }catch (const std::exception& e) {
        std::cerr << "异常: " << e.what() << std::endl;
    }
    catch (...) {
        std::cerr << "未知的异常" << std::endl;
    }

}
//图片后处理（后处理）
vector<Detection> YOLOV8FU::postprocess_img(Mat& frame, float* detections, ov::Shape & output_shape, bool is_show) //原为void类型，但因为任务需要，改为了Detection
{
    vector<int> class_ids;
    std::vector<cv::Rect> boxes;
    vector<float> confidences;
    int out_rows = output_shape[1];
    int out_cols = output_shape[2];

    //cout<<out_rows<<" and "<<out_cols<<endl;

    const cv::Mat det_output(out_rows, out_cols, CV_32F, (float*)detections);
    //std::cout<<"开始执行框筛选，特征列数："<<det_output.cols<<endl;
    
    clock_t start_det, end_det;//设置计时标志，用于显示推理时间
    start_det = clock();
    std::vector<std::vector<cv::Point2f>> PointList;
    int temp = 0;
    for (int i = 0; i < det_output.cols; ++i) 
    {
        //rowRange(4, 84)用于矩阵第5行到第85行的输出值，这个84与coco数据集的类别数（80）有关，所以我将他改为12+4=16
        const cv::Mat classes_scores = det_output.col(i).rowRange(4, 8);
        cv::Point class_id_point;
        
        double max_class_score;
        cv::minMaxLoc(classes_scores, nullptr, &max_class_score, nullptr, &class_id_point);
        //std:: cout << "max_class_score:" << max_class_score << endl;


        if (max_class_score > 0.3) 
        {
            temp++;

            const float cx = det_output.at<float>(0, i)*this->rx;
            const float cy = det_output.at<float>(1, i)*this->ry;
            const float ow = det_output.at<float>(2, i)*this->rx;
            const float oh = det_output.at<float>(3, i)*this->ry;

            //关键点检测
            float conf1 = det_output.at<float>(10, i);
            float conf2 = det_output.at<float>(13, i);
            float conf3 = det_output.at<float>(16, i);
            float conf4 = det_output.at<float>(19, i);
            cv::Point kp1(det_output.at<float>(8, i)*this->rx, det_output.at<float>(9, i)*this->ry);
            cv::Point kp2(det_output.at<float>(11, i)*this->rx, det_output.at<float>(12, i)*this->ry);
            cv::Point kp3(det_output.at<float>(14, i)*this->rx, det_output.at<float>(15, i)*this->ry);
            cv::Point kp4(det_output.at<float>(17, i)*this->rx, det_output.at<float>(18, i)*this->ry);

            //关键点检测
            // cv::Point kp1(det_output.at<float>(10, i)*this->rx, det_output.at<float>(11, i)*this->ry);
            // float conf1 = det_output.at<float>(12, i);
            // cv::Point kp2(det_output.at<float>(13, i)*this->rx, det_output.at<float>(14, i)*this->ry);
            // float conf2 = det_output.at<float>(15, i);
            // cv::Point kp3(det_output.at<float>(16, i)*this->rx, det_output.at<float>(17, i)*this->ry);
            // float conf3 = det_output.at<float>(18, i);
            // cv::Point kp4(det_output.at<float>(19, i)*this->rx, det_output.at<float>(20, i)*this->ry);
            // float conf4 = det_output.at<float>(21, i);
            //cout<<kp1<<endl;
 
            
            //设置一个临时box来存点
            cv::Rect box;
            box.x = static_cast<int>((cx - 0.5 * ow) );
            box.y = static_cast<int>((cy - 0.5 * oh));
            if(box.x < 0 || box.y < 0)
                continue;
            box.width = static_cast<int>(ow);
            box.height = static_cast<int>(oh);
            if((box.x + box.width) > 1280 || (box.y + box.height) > 1024)
                continue;
            //cout<<"x值："<<box.x<<"  y值： "<<box.y<<"  宽：  "<<box.width<<"  高： "<<box.height<<"类别id："<<class_id_point.y<<endl;

            //保存相关信息
            boxes.push_back(box);//保存当前矩形框
            std::vector<cv::Point2f> Points;
            //保存关键点
            Points.push_back(kp1);
            Points.push_back(kp2);
            Points.push_back(kp3);
            Points.push_back(kp4);
            

            PointList.push_back(Points);
            //cout<<"box放入成功"<<endl;
            class_ids.push_back(class_id_point.y);//保存当前类别id
            //cout<<class_id_point.y<<endl;
            //cout<<"id放入成功"<<endl;
            confidences.push_back(max_class_score);//保存当前置信度
        }
    }
    
    //std::cout<<"筛选到"<<temp<<"个目标"<<endl;
    end_det = clock();
    //std::cout << "对模型输出数据进行置信度/评分处理的耗时 = " << double(end_det - start_det) / CLOCKS_PER_SEC << "s" << std::endl;

    std::vector<int> nms_result;

    clock_t start_nms,end_nms;
    start_nms = clock();

    //NMS_YU(boxes, confidences, this->scoreThreshold, this->nmsThreshold, nms_result);//用俞某手措的的nms方法来筛选框

    //NMS_L(boxes, confidences, this->scoreThreshold, this->nmsThreshold, nms_result);
    cv::dnn::NMSBoxes(boxes, confidences, this->scoreThreshold, this->nmsThreshold, nms_result);//用nms方法来筛选框

    end_nms = clock();
    //std::cout << "openCV的NMS耗时 = " << double(end_nms - start_nms) / CLOCKS_PER_SEC << "s" << std::endl;

    //获取输出结果保存
    std::vector<Detection> output;
    for (int i = 0; i <nms_result.size(); i++)
    {
        Detection result;
        int idx = nms_result[i];
        //if (class_ids[idx] <= 5)//编号小于等于5的是红方，这个if判断是我加的，用于辨识敌我
        result.class_id = class_ids[idx];
        //std::cout<<"id值 = "<<result.class_id<<endl;
        result.confidence = confidences[idx];
        result.box = boxes[idx];
        result.points = PointList[idx];
        output.push_back(result);

    }
    
    //绘制推理框
    if (is_show==true)
    {
        for (int i = 0; i < output.size(); i++)
        {
            //std::cout<<"开始绘制第"<<i+1<<"个目标框"<<endl;
            auto detection = output[i];
            //std::cout<<"已将推理结果复制给临时变量detection"<<endl;
            auto classId = detection.class_id;
            //std::cout<<"已将目标id复制给临时变量ClassId"<<endl;
            // if (classId != 0) continue;//这是原来项目的语句，我也不知道类非空时continue干什么用，可能开发者开发项目时测试用的。
            auto confidence = detection.confidence;
            //std::cout<<"已将目标置信度复制给临时变量confidence"<<endl;
            auto box = detection.box;
            //std::cout<<"已将结果的box成员复制给临时变量box"<<endl;

            box.x = this->rx * box.x;//左顶点x坐标
            box.y = this->ry * box.y;//左顶点y坐标
            //std::cout<<"已成功将目标位置左上顶点转换为在原图像中的坐标"<<endl;
            if(box.x < 0 || box.y < 0)
                continue;
            box.width = this->rx * box.width;
            box.height = this->ry * box.height;
            if((box.x + box.width) > frame.cols || (box.y + box.height) > frame.rows)
                continue;

            float xmax = box.x + box.width;//右下端点x坐标
            float ymax = box.y + box.height;//右下端点y坐标
            //std::cout<<"已成功将目标位置右下顶点转换为在原图像中的坐标"<<endl;
            //绘制推理框，也就是框出目标
            std::random_device rd;
            std::mt19937 gen(rd());
            std::uniform_int_distribution<int> dis(100, 255);
            cv::Scalar color = cv::Scalar(dis(gen),
                dis(gen),
                dis(gen));
            //std::cout<<"尝试执行绘制"<<"左上点xy: "<<box.x<<" "<<box.y<<"右下点xy: "<<xmax<<" "<<ymax<<endl;
            

            //std::cout<<"矩形目标框绘制完成"<<endl;
            //绘制推理框信息的文本，也就是显示类信息与概率
            // std::string classString = classname[classId] + ' ' + std::to_string(confidence).substr(0, 4);   //设置文本的内容
            // //std::cout<<"文本内容生成完成"<<endl;
            // cv::Size textSize = cv::getTextSize(classString, cv::FONT_HERSHEY_DUPLEX, 1, 2, 0);             //设置文本字体及大小
            // //std::cout<<"文本字体以及大小设置完成"<<endl;
            // cv::Rect textBox(box.x, box.y - 40, textSize.width + 10, textSize.height + 20);                 //设置类别文本框的放置位置，默认box的左上角
            // //std::cout<<"文本放置位置设置完成"<<endl;
            // cv::rectangle(frame, textBox, color, cv::FILLED);                                               //绘制放置类别信息文本的一个小框
            // //std::cout<<"矩形文本框绘制完成"<<endl;
            // cv::putText(frame, classString, cv::Point(box.x + 5, box.y - 10), cv::FONT_HERSHEY_DUPLEX, 1, cv::Scalar(0, 0, 0), 2, 0);//绘制文本
            //std::cout<<"文本信息绘制完成"<<endl;
        }
    }

    return output;
}
};

#endif