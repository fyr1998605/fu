#pragma once
#include<chrono>

using namespace std;
typedef long long Timestamp;
typedef long long TimeSpan;
namespace Tools {
#define Sleep(x) (std::this_thread::sleep_for(chrono::milliseconds(long(x))))
	Timestamp GetTimestamp() {
		return chrono::time_point_cast<chrono::milliseconds>(chrono::system_clock::now()).time_since_epoch().count();
	}
}