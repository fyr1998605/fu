#ifndef CALCULATE
#define CALCULATE
#include "ros/ros.h"
#include "geometry_msgs/PoseStamped.h"
#include <Eigen/Dense>
#include <opencv2/opencv.hpp>
#include <math.h>
#include <chrono>
#include <Image.h>
#include "Pid.hpp"
#include <tf2/LinearMath/Quaternion.h>
#include <tf2/LinearMath/Matrix3x3.h>
#include "Variable.h"
#include "visual.hpp"

namespace CAL{
    const std::string TempTF = "tempPos";
    //使用前别忘记setpose
    class Calculater{
    private:
        cv::Mat CameraMatrix;
        // //相机到odom的旋转关系
        // Eigen::Matrix3d R_cap2odom;
        // //odom到相机的旋转关系
        // Eigen::Matrix3d R_odom2cap;
        // //相机在odom下的三维信息
        // Eigen::Vector3d T_Odom_Gun;
        // Eigen::Vector3d T_Camera_Gun;
        // //odom的旋转关系
        // Eigen::Matrix3d R_odom;
    public:
        Visual::VisualTF vtf;
        Calculater(cv::Mat cameraMatrix,ros::NodeHandle& nh);
        cv::Point2f ThreeToTwo(cv::Mat tvec);
        cv::Point2f ThreeToTwo(Eigen::Vector3d pos);
        Eigen::Vector3d MatrixPosToVector(cv::Mat tvec);
        cv::Mat VectorToMatrixPos(Eigen::Vector3d src);
        void SetImuPose(Eigen::Vector3d imuPose);
        void SetImuPose(double roll,double pitch,double yaw);
        Eigen::Matrix3d CalMatrix(double roll,double pitch,double yaw);
        cv::Point3d VectorToPoint(Eigen::Vector3d src);
        Eigen::Vector3d CameraToGun(Eigen::Vector3d cpos);
        Eigen::Vector3d CameraToOdom(Eigen::Vector3d cpos);
        Eigen::Vector3d OdomToGun(Eigen::Vector3d opos);
        Eigen::Vector3d OdomToCam(Eigen::Vector3d opos);
        void TargetUpdate(Eigen::Vector3d pos,Eigen::Vector3d pose);
        Eigen::Vector3d GetCompensatedPoint(double compesation,Eigen::Vector3d tvec);
        double GetCompensation(Eigen::Vector3d pos,double vec);
        vector<Eigen::Vector3d> RebuildArmorInOdom(Eigen::Vector3d pose,Eigen::Vector3d center);
        Eigen::Vector4d Euler2QUaternion(double roll, double pitch, double yaw);
        Eigen::Vector3d CalCenter(geometry_msgs::Pose p1, geometry_msgs::Pose p2);
        double CalPointsDis(std::vector<cv::Point2f> targetPoint, std::vector<cv::Point2f> point);
        cv::Rect Points2Rect(std::vector<cv::Point2f> pts);
        Eigen::Vector3d GetAbsolutePosition(const std::string& name);
        Eigen::Vector3d GetTargetPos(const std::string&frame);
        void TFUpdata(const std::string&frame,const std::string&name,Eigen::Vector3d pos,Eigen::Vector3d pose,int index);
        Eigen::Vector3d GetPos(const std::string&frame,const std::string&name);
        Eigen::Vector3d Rvec2Euler(cv::Mat rvec);
    };

    Calculater::Calculater(cv::Mat cameraMatrix,ros::NodeHandle& nh):vtf(nh){
        CameraMatrix = cameraMatrix;
        // //相机到odom的旋转关系
        // R_odom2cap <<  0.03322661, -0.99928456, 0.01806541, 
        //     -0.01641615, -0.01861862, -0.99969188, 
        //     0.99931302, 0.03291981, -0.01702304;
        // //odom到相机的旋转关系
        // R_cap2odom << 0.03322661, -0.01641615, 0.99931302,
        //     -0.99928456, -0.01861862, 0.03291981, 
        //     0.01806541, -0.99969188, -0.01702304;
        // // Eigen::Matrix3d rotation_matrix_yaw;
        // // rotation_matrix_yaw << std::cos((-90)*D2R), -std::sin((-90)*D2R), 0,
        // //             std::sin((-90)*D2R), std::cos((-90)*D2R), 0,
        // //             0, 0, 1;
        // // R_odom2cap = R_odom2cap * rotation_matrix_yaw;
        // // R_cap2odom = R_odom2cap.inverse(); 

        // // R_cap2odom = this->CalMatrix(M_PI/2, 0, M_PI/2);
        // // R_odom2cap = R_cap2odom.inverse();

        // //枪口在odom下的三维信息
        // // T_Odom_Gun << 0.243346,0,-0.03434;
        // T_Odom_Gun << 0,0,-0;
        // //枪口在相机下的三维信息
        // // T_Camera_Gun << 0, -0.06225, 0.02586;
        // T_Camera_Gun << 0, -0, 0;
        // // T_Odom_Gun << 0.14524,0,-0.07084;
        // // T_Camera_Gun << 0, -0.03472, 0.0927924;



        // //使用毫米单位
        // // T_Odom_Gun *= 1000;
        // // T_Camera_Gun *= 1000;

        // //odom的旋转关系
        // R_odom << 1, 0, 0,
        //         0, 1, 0,
        //         0, 0, 1;

        
    }
    void Calculater::SetImuPose(Eigen::Vector3d imuPose){
        // Eigen::Matrix3d rotation_matrix_pitch;
        // Eigen::Matrix3d rotation_matrix_yaw;
        // Eigen::Matrix3d rotation_matrix_roll;
        // rotation_matrix_pitch << std::cos(imuPose.y()), 0 ,std::sin(imuPose.y()),
        //                                     0,1,0,
        //                                     -std::sin(imuPose.y()),0,std::cos(imuPose.y());
        // rotation_matrix_yaw << std::cos(imuPose.z()), -std::sin(imuPose.z()), 0,
        //                         std::sin(imuPose.z()), std::cos(imuPose.z()), 0,
        //                         0, 0, 1;

        // rotation_matrix_roll << 1, 0, 0,
        //                     0, std::cos(imuPose.x()), -std::sin(imuPose.x()),
        //                     0, std::sin(imuPose.x()), std::cos(imuPose.x());
        // this->R_odom = rotation_matrix_yaw * rotation_matrix_pitch * rotation_matrix_roll;
        vtf.TfUpdate({imuPose.x(),imuPose.y(),imuPose.z()});
    }

    
    void Calculater::SetImuPose(double roll,double pitch,double yaw){
        Eigen::Vector3d temp;
        temp << roll,pitch,yaw;
        this->SetImuPose(temp);
    }

    Eigen::Matrix3d Calculater::CalMatrix(double roll,double pitch,double yaw){
        Eigen::Matrix3d rotation_matrix_pitch;
        Eigen::Matrix3d rotation_matrix_yaw;
        Eigen::Matrix3d rotation_matrix_roll;
        rotation_matrix_pitch << std::cos(pitch), 0 ,std::sin(pitch),
                                            0,1,0,
                                            -std::sin(pitch),0,std::cos(pitch);
        rotation_matrix_yaw << std::cos(yaw), -std::sin(yaw), 0,
                                std::sin(yaw), std::cos(yaw), 0,
                                0, 0, 1;

        rotation_matrix_roll << 1, 0, 0,
                            0, std::cos(roll), -std::sin(roll),
                            0, std::sin(roll), std::cos(roll);
        return rotation_matrix_yaw * rotation_matrix_pitch * rotation_matrix_roll;
    }
    
    cv::Point3d Calculater::VectorToPoint(Eigen::Vector3d src){
        cv::Point3d result;
        result.x = src.x();
        result.y = src.y();
        result.z = src.z();
        return std::move(result);
    }
    cv::Mat Calculater::VectorToMatrixPos(Eigen::Vector3d src){
        //3*1矩阵，存储CV_64F
        cv::Mat result(3,1,6);
        result.at<double>(0,0) = src.x();
        result.at<double>(1,0) = src.y();
        result.at<double>(2,0) = src.z();
        return std::move(result);
    }
    Eigen::Vector3d Calculater::MatrixPosToVector(cv::Mat tvec){
        Eigen::Vector3d result;
        result << tvec.at<double>(0,0),tvec.at<double>(1,0),tvec.at<double>(2,0);
        return std::move(result);
    }
    //in:mm out:mm
    cv::Point2f Calculater::ThreeToTwo(Eigen::Vector3d pos){
        return std::move(ThreeToTwo(VectorToMatrixPos(pos)));
    }
    //in:mm out:mm
    cv::Point2f Calculater::ThreeToTwo(cv::Mat tvec){
        cv::Mat _pixel = this->CameraMatrix * tvec;
        cv::Point2f targetInPixel;
        targetInPixel.x = _pixel.at<double>(0,0) / _pixel.at<double>(2,0);
        targetInPixel.y = _pixel.at<double>(1,0) / _pixel.at<double>(2,0);
        return std::move(targetInPixel);
    }
    //c -> g
    //in:mm out:mm
    Eigen::Vector3d Calculater::CameraToGun(Eigen::Vector3d cpos){
        return {0,0,0};
        // return cpos - T_Camera_Gun;
        // vtf.TargetUpdate(cpos);
        vtf._Update("cam",cpos,TempTF);
        return vtf.GetChildInFrameData("gun",TempTF);
    }
    //c -> g -> o
    //in:mm out:mm
    Eigen::Vector3d Calculater::CameraToOdom(Eigen::Vector3d cpos){
        return {0,0,0};
        // Eigen::Vector3d result;
        // result = this->R_odom * (this->R_cap2odom * CameraToGun(cpos) + this->T_Odom_Gun);
        // // cout << "guanxi:" << endl << (this->R_cap2odom * CameraToGun(cpos) + this->T_Odom_Gun) << endl;
        // // cout << "guanxi2:" << endl << result << endl;
        // // cout << "R:" << endl << R_odom << endl;
        // return std::move(result);
        vtf._Update("cam",cpos,TempTF);
        return vtf.GetChildInFrameData("imu",TempTF);
    }
    //o -> g
    //in:mm out:mm
    Eigen::Vector3d Calculater::OdomToGun(Eigen::Vector3d opos){
        return {0,0,0};
        // return this->R_odom2cap * (this->R_odom.inverse() * opos - this->T_Odom_Gun);
        vtf._Update("imu",opos,TempTF);
        return vtf.GetChildInFrameData("gun",TempTF);
    }
    //o -> g -> c
    //in:mm out:mm
    Eigen::Vector3d Calculater::OdomToCam(Eigen::Vector3d opos){
        return {0,0,0};
        // return T_Camera_Gun + OdomToGun(opos);
        vtf._Update("imu",opos,TempTF);
        return vtf.GetChildInFrameData("cam",TempTF);
    }
    Eigen::Vector3d Calculater::GetCompensatedPoint(double compesation,Eigen::Vector3d tvec){
        // 先构造补偿点在陀螺仪系下的点
        Eigen::Vector3d opos = this->CameraToOdom(tvec),result;
        //odom
        result << opos[0],opos[1],opos[0] * tan(compesation);
        result = this->OdomToCam(result);
        return std::move(result);
    }
    vector<Eigen::Vector3d> Calculater::RebuildArmorInOdom(Eigen::Vector3d pose,Eigen::Vector3d center){
        throw NULL;
        // //四点陀螺仪系下坐标
        // Eigen::Vector3d P1, P2, P3, P4;
        // //四点相机系下坐标
        // Eigen::Vector3d P11, P22, P33, P44;
        // //陀螺仪旋转矩阵的逆
        // Eigen::Matrix3d R_odom_inverse;
        // //roll轴的旋转矩阵
        // Eigen::Matrix3d rotation_matrix_roll;
        // //pitch轴的旋转矩阵
        // Eigen::Matrix3d rotation_matrix_pitch;
        // //yaw轴的旋转矩阵
        // Eigen::Matrix3d rotation_matrix_yaw;

        // rotation_matrix_roll << 1, 0, 0,
        //                         0, std::cos(pose.x()), -std::sin(pose.x()),
        //                         0, std::sin(pose.x()), std::cos(pose.x());

        // rotation_matrix_pitch << std::cos(pose.y()), 0 ,std::sin(pose.y()),
        //                         0, 1, 0,
        //                         -std::sin(pose.y()), 0, std::cos(pose.y());

        // rotation_matrix_yaw << std::cos(pose.z()), -std::sin(pose.z()), 0,
        //                     std::sin(pose.z()), std::cos(pose.z()), 0,
        //                     0, 0, 1;


        // R_odom_inverse = R_odom.inverse();

        // P1 =  center + rotation_matrix_yaw * rotation_matrix_pitch * rotation_matrix_roll * Eigen::Vector3d(0, -Half_Width / 1000, Half_Height / 1000);
        // P2 =  center + rotation_matrix_yaw * rotation_matrix_pitch * rotation_matrix_roll * Eigen::Vector3d(0, Half_Width / 1000, Half_Height / 1000);
        // P3 =  center + rotation_matrix_yaw * rotation_matrix_pitch * rotation_matrix_roll * Eigen::Vector3d(0, Half_Width / 1000, -Half_Height / 1000);
        // P4 =  center + rotation_matrix_yaw * rotation_matrix_pitch * rotation_matrix_roll * Eigen::Vector3d(0, -Half_Width / 1000, -Half_Height / 1000);

        // P11 = this->R_odom2cap * (R_odom_inverse * P1 + T_Camera_Gun);
        // P22 = this->R_odom2cap * (R_odom_inverse * P2 + T_Camera_Gun);
        // P33 = this->R_odom2cap * (R_odom_inverse * P3 + T_Camera_Gun);
        // P44 = this->R_odom2cap * (R_odom_inverse * P4 + T_Camera_Gun);

        // vector<Eigen::Vector3d> pionts;
        // pionts.push_back(P11);
        // pionts.push_back(P22);
        // pionts.push_back(P33);
        // pionts.push_back(P44);

        // return pionts;
    }
    Eigen::Vector4d Calculater::Euler2QUaternion(double roll, double pitch, double yaw)
    {
        tf2::Quaternion qtn;
        qtn.setRPY(roll, pitch, yaw);
        return Eigen::Vector4d(qtn.w(), qtn.x(), qtn.y(), qtn.z()); 
    } 
    double Calculater::GetCompensation(Eigen::Vector3d opos,double vec = 30.0){
        // opos /= 1000;
        // opos = OdomToGun(opos);
        // double _height = 0.0,height = -0.08,depth = fabs(opos.x());
        double _height = 0.0,height = opos.z(),depth = Eigen::Vector2d(opos.x(),opos.y()).norm();
        double xita = -PI / 4,minError = DOUBLE_MAX,error = 0.0,result = 0.0;
        // cout << "h:" << height << ' ' << "d:" << opos.x() << "p" << opos.y() << endl;
        while(xita < PI / 3)
        {
            _height = depth * std::tan(xita) - (LOCAL_G * FA * depth * depth) / (2 * (vec * FA * std::cos(xita)) * (vec * FA * std::cos(xita)));
            error = std::fabs(height - _height);
            if(error < 0.005) //误差已经很低了 不用更高精度了
            {
                // cout << "xita:" << xita << endl;
                return xita;
            }
            else if(error < minError){
                result = xita;
                minError = error;
            }
            xita += 0.005;//目前输出的值为相对于相机现在的姿态所要转的角度，即相机坐标系下的仰角
        }
        return result;
    }
    Eigen::Vector3d Calculater::CalCenter(geometry_msgs::Pose p1, geometry_msgs::Pose p2)
    {
        tf2::Quaternion qtn1(p1.orientation.x, p1.orientation.y, p1.orientation.z, p1.orientation.w);
        tf2::Quaternion qtn2(p2.orientation.x, p2.orientation.y, p2.orientation.z, p2.orientation.w);
        double roll1, pitch1, yaw1;
        double roll2, pitch2, yaw2;
        tf2::Matrix3x3(qtn1).getRPY(roll1, pitch1, yaw1);
        tf2::Matrix3x3(qtn2).getRPY(roll2, pitch2, yaw2);

        double line1_k = tan(yaw1);
        double line2_k = tan(yaw2);

        double b1 = p1.position.y -line1_k * p1.position.x;
        double b2 = p2.position.y -line2_k * p2.position.x;

        double x = (b2 - b1) / (line1_k - line2_k);
        double y = line1_k * x + b1;

        Eigen::Vector3d tp_c(x, y ,(p1.position.z + p2.position.z) / 2);
        Eigen::Vector3d tp_p(p1.position.x, p1.position.y , p1.position.z);
        Eigen::Vector3d r = tp_c - tp_p;
        double rr = sqrt((tp_c[0] - tp_p[0]) * (tp_c[0] - tp_p[0]) + (tp_c[1] - tp_p[1]) * (tp_c[1] - tp_p[1]));
        
        x = p1.position.x + rr * cos(yaw1 + M_PI);
        y = p1.position.y + rr * sin(yaw1 + M_PI);
        return Eigen::Vector3d(x, y, (p1.position.z + p2.position.z) / 2);
    }
    // 算四点距离
    double Calculater::CalPointsDis(std::vector<cv::Point2f> targetPoint, std::vector<cv::Point2f> point)
    {
        double dis;
        for(int i = 0; i < targetPoint.size(); i++){
            dis += sqrt(pow((targetPoint[i].x - point[i].x), 2) + pow((targetPoint[i].y - point[i].y), 2));
        }
        return dis / 4;
    }
    cv::Rect Calculater::Points2Rect(std::vector<cv::Point2f> pts){
        double  min_x = DOUBLE_MAX,min_y = DOUBLE_MAX,
                max_x = -1,max_y = -1;
        for(cv::Point2f& pt:pts){
            if(pt.x < min_x)
                min_x = pt.x;
            if(pt.x > max_x)
                max_x = pt.x;
            if(pt.y < min_y)
                min_y = pt.y;
            if(pt.y > max_y)
                max_y = pt.y;
        }
        double height = fabs(max_y - min_y);
        double width = fabs(max_x - min_x);
        height = (width - height)/2;
        width *= 0.1;
        // cout << "HRate:" << h_rate << endl;
        // cout << "h    :" << height << endl;
        min_x -= width;
        min_y -= height;
        max_x += width;
        max_y += height;
        if(min_x < 0)
            min_x = 0;
        if(min_y < 0)
            min_y = 0;
        // cout << min_x << ' '<< min_y << ' '<< max_x << ' '<< max_y << endl;
        return cv::Rect((int)min_x,(int)min_y,(int)(max_x-min_x),(int)(max_y-min_y));
    }
    void Calculater::TargetUpdate(Eigen::Vector3d pos,Eigen::Vector3d pose = {0,0,0}){
        vtf.TargetUpdate(pos,pose);
        return;
    }
    Eigen::Vector3d Calculater::GetAbsolutePosition(const std::string& name){
        return vtf.GetChildInFrameData("map",name);
    }
    Eigen::Vector3d Calculater::GetTargetPos(const std::string&frame){
        return vtf.GetChildInFrameData(frame,"target");
    }
    void Calculater::TFUpdata(const std::string&frame,const std::string&name,Eigen::Vector3d pos,Eigen::Vector3d pose = {0,0,0},int index = 0){
        vtf._Update(frame,pos,name,pose,index);
        return;
    }
    Eigen::Vector3d Calculater::GetPos(const std::string&frame,const std::string&name = TempTF){
        return vtf.GetChildInFrameData(frame,name);
    }
    Eigen::Vector3d Calculater::Rvec2Euler(cv::Mat rvec){
        cv::Mat R;
        cv::Rodrigues(rvec, R);
        // 从旋转矩阵 R 中提取欧拉角
        double theta_x = atan2(R.at<double>(2, 1), R.at<double>(2, 2));
        double theta_y = atan2(-R.at<double>(2, 0), sqrt(pow(R.at<double>(2, 1), 2) + pow(R.at<double>(2, 2), 2)));
        double theta_z = atan2(R.at<double>(1, 0), R.at<double>(0, 0)); 
        return {theta_x,theta_y,theta_z};
    }
}
#endif