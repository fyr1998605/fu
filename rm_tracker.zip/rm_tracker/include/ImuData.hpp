#ifndef IMUDATA
#define IMUDATA
class ImuData{
public:
    //WXYZ
    double Qtn[4];
    //RPY
    double Pose[3];
    double GetRoll(){
        return Pose[0];
    }
    double GetPitch(){
        return Pose[1];
    }
    double GetYaw(){
        return Pose[2];
    }
};
#endif