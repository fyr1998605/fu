//1.获取装甲板四个点并具视化在rviz上
//2.目标装甲板的坐标系显式出来
//3.知道长短轴的情况下，坐标关系转换

#include "ros/ros.h"
#include <tf2_ros/transform_broadcaster.h>
#include <geometry_msgs/TransformStamped.h>
#include <tf2/LinearMath/Quaternion.h>
#include <Eigen/Dense>
#include <geometry_msgs/PointStamped.h>
#include <geometry_msgs/PoseArray.h>
#include <geometry_msgs/Pose.h>
#include <vector>
#include <opencv2/core.hpp>

class Target_Amor
{
    public: 
	//需要知道消息类型
    void CarToWorld_TFinit();
    void Target_armorToCar(double L_Z, double S_Z);
    void TargetToCar_TFinit(Mat tvec, double yaw);
    //void dopose(const hh::Pose::ConstPtr& pose);
    ~Target_Amor();
private:
    tf2_ros::TransformBroadcaster broadcasterOP;
    geometry_msgs::TransformStamped ts_Target_Armor;
    geometry_msgs::TransformStamped ts_Target_car;
    geometry_msgs::TransformStamped ts_camera;
    geometry_msgs::TransformStamped ts_target;
    geometry_msgs::TransformStamped ts_car;
    tf2::Quaternion qtn;
    cv::Mat tvec;
    double L_Z, S_Z;
};
Target_Amor::~Target_Amor()
{

}

void Target_Amor::Target_armorToCar(double L_Z, double S_Z)
{
    tf2::Quaternion qtn;
    qtn.setRPY(0, 0, 0);
    ts_Target_Armor.header.frame_id = "Target_car";//目标车
    ts_Target_Armor.header.stamp = ros::Time::now();
    ts_Target_Armor.child_frame_id = "Target_Armor";//目标车上的装甲板
    ts_Target_Armor.transform.translation.x = L_Z;
    ts_Target_Armor.transform.translation.y = S_Z;
    ts_Target_Armor.transform.translation.z = 0;
    ts_Target_Armor.transform.rotation.w = qtn.getW();
    ts_Target_Armor.transform.rotation.x = qtn.getX();
    ts_Target_Armor.transform.rotation.y = qtn.getY();
    ts_Target_Armor.transform.rotation.z = qtn.getZ();
}

void Target_Amor::TargetToCar_TFinit(cv::Mat tvec, double yaw)//目标对于车
{
    tf2::Quaternion qtn;
    qtn.setRPY(0, yaw / 180 * M_PI, 0);
    ts_target.header.frame_id = "camera";
    ts_target.header.stamp = ros::Time::now();
    ts_target.child_frame_id = "target";
    ts_target.transform.translation.x = tvec.at<double>(0, 0) / 1000;
    ts_target.transform.translation.y = tvec.at<double>(1, 0) / 1000;
    ts_target.transform.translation.z = tvec.at<double>(2, 0) / 1000;
    ts_target.transform.rotation.w = qtn.getW();
    ts_target.transform.rotation.x = qtn.getX();
    ts_target.transform.rotation.y = qtn.getY();
    ts_target.transform.rotation.z = qtn.getZ();
}
void Target_Amor::CarToWorld_TFinit()
{
    tf2::Quaternion qtn;
    qtn.setRPY(0, 0, 0);
    ts_car.header.frame_id = "map";
    ts_car.header.stamp = ros::Time::now();
    ts_car.child_frame_id = "car";
    ts_car.transform.translation.x = 1;
    ts_car.transform.translation.y = 0;
    ts_car.transform.translation.z = 0;
    ts_car.transform.rotation.w = qtn.getW();
    ts_car.transform.rotation.x = qtn.getX();
    ts_car.transform.rotation.y = qtn.getY();
    ts_car.transform.rotation.z = qtn.getZ();
 }
// ros::Subscriber sub = nh.subscribe<String::Pose>("", 1000, doPose);
// void Target_Amor::dopose(const string::Pose::ConstPtr& pose)
// {
//         static tf2_ros::TransformBroadcaster broadcaster;
//         geometry_msgs::TransformStamped tfs;
//         tfs.header.frame_id = "Target_center";//被参考的
//         tfs.header.stamp = ros::Time::now();
//         tfs.child_frame_id = "Target_Amor";

//         //  |----坐标系相对信息设置
//         tfs.transform.translation.x = pose->x;
//         tfs.transform.translation.y = pose->y;
//         tfs.transform.translation.z = pose->z;
//         //  |--------- 四元数设置
//         tf2::Quaternion qtn;
//         qtn.setRPY(0, 0, pose->theta);
//         tfs.transform.rotation.x = qtn.getX();
//         tfs.transform.rotation.y = qtn.getY();
//         tfs.transform.rotation.z = qtn.getZ();
//         tfs.transform.rotation.w = qtn.getW();


//         //  5-3.广播器发布数据
//         broadcasterOP.sendTransform(tfs);
    
// }
//回调函数的消息有问题！！！！！！！还没改
