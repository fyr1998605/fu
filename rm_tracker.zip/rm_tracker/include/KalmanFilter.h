#pragma once
#include<Eigen/Dense>
#include<iostream>
#include <cmath>
#include<vector>
#include <opencv2/core.hpp>


using namespace Eigen;
using namespace std;

#define MEASURE 1
#define STATE 2

//?????????????????
#define _1DCV_MEASURE 1
#define _2DCV_MEASURE 2
#define _3DCV_MEASURE 3
#define _1DCA_MEASURE 2
#define _2DCA_MEASURE 4
#define _3DCA_MEASURE 6
#define _1DCV_STATE 2
#define _2DCV_STATE 4
#define _3DCV_STATE 6
#define _1DCA_STATE 3
#define _2DCA_STATE 6
#define _3DCA_STATE 9
#define _1DCV 1
#define _2DCV 2
#define _3DCV 3
#define _1DCA 4
#define _2DCA 5
#define _3DCA 6

#define K_PI 3.1415926535897932384626

//const double K_PI = 3.14159265358979323846;

template <typename T , int state, int measure>

class KalmanFilter_
{
public:
    /*------------------------------------ϵͳ�еĲ���--------------------------------------*/
	float delta_t;//ȡ��ʱ��
	float shootRadio = 1;//??????(????????????????)
	float LastX = 0, LastY = 0, LastZ = 0;
	int flag = 0;//?????????(1, 2, 3)?????????(?????????????????)
	int _state = STATE;
	int _measure = MEASURE;


	bool isRightType = false;//???????????????????????
	bool isRightScale = false;//?????????????????????????

	bool isUseKF = false;//?????????????????????????????????????
	bool isFistIni = true;//????????????????????
	int count = 0;//?????KF???????
	/*------------------------------------???????????????????--------------------------------------*/
	//state ?????  measure ?????
	/*	transitionMatrix = overshoottransitionMatrix = state * state
	*	controlMatrix = state * measure
	*	measurementMatrix = measure * state
	*	processNoiseMatrix = state * state
	*	measurementNoiseMatrix = measure * measure
	*	I = state * state
	*	statePreMatrix = statePostMatrix = state * 1
	*	errorCovPre = errorCovPost = state * state
	*	KalmanGain = state * measure
	*/

	/*------------------------------------定量矩阵--------------------------------------*/
	Matrix<T, state, state> transitionMatrix;//A定义一个泛型矩阵，T为类型，state为大小
	Matrix<T, state, measure> controlMatrix;//控制矩阵 B
	Matrix<T, measure, state> measurementMatrix;//观测矩阵 H
	Matrix<T, state, state> processNoiseMatrix;//状态噪声协方差矩阵 Q
	Matrix<T, measure, measure> measurementNoiseMatrix;//观测噪声协方差矩阵 R
	Matrix<T, state, state> I;//单位矩阵
	Matrix<T, state, state> overshootMatrix;//超射的状态转移矩阵

	/*------------------------------------变量矩阵--------------------------------------*/
	Matrix<T, state, 1> statePreMatrix;// X'(k) = A * X(k-1) + B * U(k-1) + (Q) 先验估计
	Matrix<T, state, state> errorCovPre;// P'(k) = A * P(k-1) * At 先验估计的误差协方差矩阵
	Matrix<T, state, measure> KalmanGain;// K(k) = P'(k) * Ht * inverse(H * P'(k) * Ht + R) 卡尔曼增益
	Matrix<T, state, 1> statePostMatrix;// X(k) = X'(k) + K(k) * (Z - H * X'(k)) 最优估计
	Matrix<T, state, state> errorCovPost;// P(k) = (I - K(k) * H)P'(k) 最优估计的误差协方差矩阵

	/*------------------------------------初始化--------------------------------------*/
	void Initialize()
	{
		// 建立正常情况下的状态转移矩阵            主要用来滤波
		BuildTransitionMatrix(this->transitionMatrix, delta_t);
		// 建立超射情况下的状态转移矩阵            主要用来预测
		BuildTransitionMatrix(this->overshootMatrix, shootRadio * delta_t);

		//初始化 先验估计
		this->statePreMatrix.setZero();
		//初始化 最优估计
		this->statePostMatrix.setZero();
		//初始化 状态噪声协方差矩阵 Q
		this->processNoiseMatrix.setIdentity();
		//初始化 控制矩阵 B
		this->controlMatrix.setZero();
		//初始化 观测矩阵 H
		this->measurementMatrix.setIdentity();
		//初始化 观测噪声协方差矩阵 R
		this->measurementNoiseMatrix.setIdentity();
		//初始化 先验估计的误差协方差矩阵
		this->errorCovPre.setIdentity();
		//初始化 最优估计的误差协方差矩阵
		this->errorCovPost.setIdentity();
		//初始化 卡尔曼增益
		this->KalmanGain.setIdentity();
		//初始化单位矩阵
		this->I.setIdentity();
		//是否使用卡尔曼
		bool isUseKF = false;
		bool isFistIni = true;
		int count = 0;
	}
	// 建立状态转移矩阵 
	void BuildTransitionMatrix(Matrix<T, state, state> & transitionMatrix, float delta_t)
	{
		switch (flag)
		{
			//X, Vx
		case _1DCV:
			transitionMatrix <<
				1, delta_t,
				0, 1;
			cout << "KalmanFiter is _1DCV" << endl;
			break;

		case _2DCV:
			//X, Y, Vx, Vy
			transitionMatrix <<
				1, 0, delta_t, 0,
				0, 1, 0, delta_t,
				0, 0, 1, 0,
				0, 0, 0, 1;
			cout << "KalmanFiter is _2DCV" << endl;
			break;

			//X, Y, Z, Vx, Vy, Vz
		case _3DCV:
			transitionMatrix <<
				1, 0, 0, delta_t, 0, 0,
				0, 1, 0, 0, delta_t, 0,
				0, 0, 1, 0, 0, delta_t,
				0, 0, 0, 1, 0, 0,
				0, 0, 0, 0, 1, 0,
				0, 0, 0, 0, 0, 1;
			cout << "KalmanFiter is _3DCV" << endl;
			break;

			//X, Vx, Ax
		case _1DCA:
			transitionMatrix <<
				1, delta_t, 0.5 * delta_t * delta_t,
				0, 1, delta_t,
				0, 0, 1;
			cout << "KalmanFiter is _1DCA" << endl;
			break;

			//X, Y, Vx, Vy, Ax, Ay
		case _2DCA:
			transitionMatrix <<
				1, 0, delta_t, 0, 0.5 * delta_t * delta_t, 0,
				0, 1, 0, delta_t, 0, 0.5 * delta_t * delta_t,
				0, 0, 1, 0, delta_t, 0,
				0, 0, 0, 1, 0, delta_t,
				0, 0, 0, 0, 1, 0,
				0, 0, 0, 0, 0, 1;
			cout << "KalmanFiter is _2DCA" << endl;

			//X, Y, Z, Vx, Vy, Vz, Ax, Ay. Az
		case _3DCA:
			transitionMatrix <<
				1, 0, 0, delta_t, 0, 0, 0.5 * delta_t * delta_t, 0, 0,
				0, 1, 0, 0, delta_t, 0, 0, 0.5 * delta_t * delta_t, 0,
				0, 0, 1, 0, 0, delta_t, 0, 0, 0.5 * delta_t * delta_t,
				0, 0, 0, 1, 0, 0, delta_t, 0, 0,
				0, 0, 0, 0, 1, 0, 0, delta_t, 0,
				0, 0, 0, 0, 0, 1, 0, 0, delta_t,
				0, 0, 0, 0, 0, 0, 1, 0, 0,
				0, 0, 0, 0, 0, 0, 0, 1, 0,
				0, 0, 0, 0, 0, 0, 0, 0, 1;
			cout << "KalmanFiter is _3DCA" << endl;
			break;

		}
	}

	//预测
	Matrix<T, state, 1> Predict()
	{
		//先验估计
		statePreMatrix = (transitionMatrix * statePostMatrix);
		//先验估计的状态协方差矩阵
		errorCovPre = (transitionMatrix * errorCovPost * transitionMatrix.transpose()) + processNoiseMatrix;
		//最优估计
		statePostMatrix = statePreMatrix;
		//最优估计的状态协方差矩阵
		errorCovPost = errorCovPre;

		return statePreMatrix;
	}
	//预测
	Matrix<T, state, 1> Predict(Matrix<T, measure, 1> U)
	{
		//先验估计
		statePreMatrix = (transitionMatrix * statePostMatrix) + (controlMatrix * U);
		//先验估计的状态协方差矩阵
		errorCovPre = (transitionMatrix * errorCovPost * transitionMatrix.transpose()) + processNoiseMatrix;
		//最优估计
		statePostMatrix = statePreMatrix;
		//最优估计的状态协方差矩阵
		errorCovPost = errorCovPre;

		return statePostMatrix;
	}

	//修正
	Matrix<T, state, 1> Correct(Matrix<T, measure, 1> Z)
	{
		//卡尔曼增益
		KalmanGain = (errorCovPre * measurementMatrix.transpose()) * (measurementMatrix * errorCovPre * measurementMatrix.transpose() + measurementNoiseMatrix).inverse();
		//最优估计
		statePostMatrix = statePreMatrix + KalmanGain * (Z - measurementMatrix * statePreMatrix);
		//最优估计的状态协方差矩阵
		errorCovPost = (I - KalmanGain * measurementMatrix) * errorCovPre;

		return statePostMatrix;
	}

	//选择卡尔曼类型
	bool chooseKalmanType()
	{
		switch (flag)
		{
			//匀速模型
		case _1DCV:
			_state = 2, _measure = 1;
			break;
		case _2DCV:
			_state = 4, _measure = 2;
			break;
		case _3DCV:
			_state = 6, _measure = 3;
			break;
			//匀加速模型
		case _1DCA:
			_state = 3, _measure = 2;
			break;
		case _2DCA:
			_state = 6, _measure = 4;
			break;
		case _3DCA:
			_state = 9, _measure = 6;
			break;
		default :
			return false;
		}
		return true;
	}


	/*------------------------------------构造函数--------------------------------------*/
	KalmanFilter_(T delta_t, int flag, float shootRadio)
	//KalmanFilter_()
	{
		this->flag = flag;
		this->delta_t = delta_t;
		this->shootRadio = shootRadio;
		isRightType |= is_same<T, float>::value;//is_same ?????????????????????????????
		isRightType |= is_same<T, double>::value;
		isRightType |= is_same<T, long double>::value;
		//选择模型
		isRightScale = chooseKalmanType();
		if (!isRightScale)
		{
			cout << "state Error and measure Error" << endl;
			exit(-1);
		}
		if (!isRightType)
		{
			cout << "Type Error" << endl;
			exit(-1);
		}
		if (measure > state)
		{
			cout << "measure <= state" << endl;
			exit(-1);
		}
		Initialize();
	}


	//匀速模型
	void setMatrix(
	Matrix<T, state, state> transitionMatrix,//?????? A
	Matrix<T, measure, state> measurementMatrix,//?????? H
	Matrix<T, state, state> processNoiseMatrix,//???????? Q
	Matrix<T, measure, measure> measurementNoiseMatrix//???????? R
	)
	{
		this->transitionMatrix = transitionMatrix;
		this->measurementMatrix = measurementMatrix;
		this->processNoiseMatrix = processNoiseMatrix;
		this->measurementNoiseMatrix = measurementNoiseMatrix;
		this->I = I.Identity(state, state);
	}
	//匀加速模型
	void setMatrix
	(
		Matrix<T, state, state> transitionMatrix,//?????? A
		Matrix<T, state, measure> controlMatrix,//??????? B
		Matrix<T, measure, state> measurementMatrix,//?????? H
		Matrix<T, state, state> processNoiseMatrix,//???????? Q
		Matrix<T, measure, measure> measurementNoiseMatrix//???????? R
	)
	{
		this->transitionMatrix = transitionMatrix;
		this->controlMatrix = controlMatrix;
		this->measurementMatrix = measurementMatrix;
		this->processNoiseMatrix = processNoiseMatrix;
		this->measurementNoiseMatrix = measurementNoiseMatrix;
		this->I = I.Identity(state, state);
	}
	// 放反馈值
	void setstatePost(Matrix<T, state, 1> statePost)//?????????????KF???????
	{
		this->statePostMatrix = statePost;
		this->isFistIni = false;
	}
	// 更新
	void Update(Matrix<T, measure, 1> MeasureVector, Matrix<T, state, 1> & correct, Matrix<T, state, 1> & predict, Matrix<T, state, 1> & overshoot)//??????????????????
	{
		// 返回的是最优估计
		correct = Correct(MeasureVector);
		// 返回先验估计
		predict = Predict();
		// 超射的先验估计
		overshoot = overshootMatrix * predict;
	}
	// 匀加速模型的更新
	void Update3DCA( Matrix<T, 3, 1>& xyz, vector<Matrix<T, state, 1>> & Correct_Predict_Overshoot)
	{
		// 判断是否满足可以使用卡尔曼
		if (!isUseKF) count++;
		// 测量值的数据temp
		Eigen::Matrix<T, 3, 1> temp_xyz;
		// 测量矩阵
		Eigen::Matrix<T, measure, 1> measureVector;

		// 滤波后的值
		Eigen::Matrix<T, state, 1> correct;
		// 预测后的值
		Eigen::Matrix<T, state, 1> predict;
		// 超射后的值
		Eigen::Matrix<T, state, 1> overshoot;

		temp_xyz << xyz;
		float x = temp_xyz(0), y = temp_xyz(1), z = temp_xyz(2);

		if (isFistIni)
		{
			LastX = x;
			LastY = y;
			LastZ = z;
			Matrix<T, state, 1>ini;
			ini << temp_xyz, 0, 0, 0, 0, 0, 0;
			setstatePost(ini);
		}
		measureVector << x, y, z,
			(x - LastX) / delta_t,
			(y - LastY) / delta_t,
			(z - LastZ) / delta_t;
		Update(measureVector, correct, predict, overshoot);
		Correct_Predict_Overshoot.push_back(correct);
		Correct_Predict_Overshoot.push_back(predict);
		Correct_Predict_Overshoot.push_back(overshoot);
		LastX = x;
		LastY = y;
		LastZ = z;
		if (count >= 3) isUseKF = true;
	}

	void Update3DCA(cv::Mat & xyz, vector<Matrix<T, state, 1>> & Correct_Predict_Overshoot)
	{
		if (!isUseKF) count++;
		Eigen::Matrix<T, 3, 1> temp_xyz;
		Eigen::Matrix<T, measure, 1> measureVector;
		Eigen::Matrix<T, state, 1> correct;
		Eigen::Matrix<T, state, 1> predict;
		Eigen::Matrix<T, state, 1> overshoot;

		/*if (is_same<Input, cv::Mat>::value) cv::cv2eigen(xyz, temp_xyz);
		else if (is_same<Input, Matrix<T, 3, 1>>::value) temp_xyz << xyz;*/
		temp_xyz << xyz.at<double>(0, 0), xyz.at<double>(1, 0), xyz.at<double>(2, 0);
		float x = temp_xyz(0), y = temp_xyz(1), z = temp_xyz(2);

		if (isFistIni)
		{
			LastX = x;
			LastY = y;
			LastZ = z;
			Matrix<T, state, 1>ini;
			ini << temp_xyz, 0, 0, 0, 0, 0, 0;
			setstatePost(ini);
		}
		
		measureVector << x, y, z,
			(x - LastX) / delta_t,
			(y - LastY) / delta_t,
			(z - LastZ) / delta_t;
		Update(measureVector, correct, predict, overshoot);
		Correct_Predict_Overshoot.push_back(correct);
		Correct_Predict_Overshoot.push_back(predict);
		Correct_Predict_Overshoot.push_back(overshoot);
		LastX = x;
		LastY = y;
		LastZ = z;
		if (count >= 3) isUseKF = true;
	}

	// 匀速模型
	void Update3DCV(Matrix<T, 3, 1>& xyz, vector<Matrix<T, state, 1>> & Correct_Predict_Overshoot)
	{
		if (!isUseKF) count++;
		Eigen::Matrix<T, measure, 1> measureVector;
		Eigen::Matrix<T, state, 1> correct;
		Eigen::Matrix<T, state, 1> predict;
		Eigen::Matrix<T, state, 1> overshoot;

	/*	if (is_same<Input, cv::Mat>::value) cv::cv2eigen(xyz, measureVector);
		else if (is_same<Input, Matrix<T, 3, 1>>::value) measureVector << xyz;*/

		measureVector << xyz;
		float x = measureVector(0), y = measureVector(1), z = measureVector(2);

		if (isFistIni)
		{
			LastX = x;
			LastY = y;
			LastZ = z;
			Matrix<T, state, 1>ini;
			ini << measureVector, 0, 0, 0;
			setstatePost(ini);
		}
		Update(measureVector, correct, predict, overshoot);
		Correct_Predict_Overshoot.push_back(correct);
		Correct_Predict_Overshoot.push_back(predict);
		Correct_Predict_Overshoot.push_back(overshoot);
		LastX = x;
		LastY = y;
		LastZ = z;
		if (count >= 3) isUseKF = true;
	}

	void Update3DCV(cv::Mat & xyz, vector<Matrix<T, state, 1>> & Correct_Predict_Overshoot)
	{
		if (!isUseKF) count++;
		Eigen::Matrix<T, measure, 1> measureVector;
		Eigen::Matrix<T, state, 1> correct;
		Eigen::Matrix<T, state, 1> predict;
		Eigen::Matrix<T, state, 1> overshoot;

		/*	if (is_same<Input, cv::Mat>::value) cv::cv2eigen(xyz, measureVector);
			else if (is_same<Input, Matrix<T, 3, 1>>::value) measureVector << xyz;*/

		measureVector << xyz.at<double>(0, 0), xyz.at<double>(1, 0), xyz.at<double>(2, 0);
		float x = measureVector(0), y = measureVector(1), z = measureVector(2);

		if (isFistIni)
		{
			LastX = x;
			LastY = y;
			LastZ = z;
			Matrix<T, state, 1>ini;
			ini << measureVector, 0, 0, 0;
			setstatePost(ini);
		}
		Update(measureVector, correct, predict, overshoot);
		Correct_Predict_Overshoot.push_back(correct);
		Correct_Predict_Overshoot.push_back(predict);
		Correct_Predict_Overshoot.push_back(overshoot);
		LastX = x;
		LastY = y;
		LastZ = z;
		if (count >= 3) isUseKF = true;
	}
	//匀加速模型
	void Update1DCA(Matrix<T, 1, 1>& xyz, vector<Matrix<T, state, 1>> & Correct_Predict_Overshoot)
	{
		if (!isUseKF) count++;
		Eigen::Matrix<T, 1, 1> temp_xyz;
		Eigen::Matrix<T, measure, 1> measureVector;
		Eigen::Matrix<T, state, 1> correct;
		Eigen::Matrix<T, state, 1> predict;
		Eigen::Matrix<T, state, 1> overshoot;

		temp_xyz << xyz;
		float x = temp_xyz(0);
		if (isFistIni)
		{
			LastX = x;
			Matrix<T, state, 1>ini;
			ini << temp_xyz, 0, 0;
			setstatePost(ini);
		}
		measureVector <<
			 x,
			(x - LastX) / delta_t;
		Update(measureVector, correct, predict, overshoot);
		Correct_Predict_Overshoot.push_back(correct);
		Correct_Predict_Overshoot.push_back(predict);
		Correct_Predict_Overshoot.push_back(overshoot);
		LastX = x;
		if (count >= 3) isUseKF = true;
	}
};




class PolarCoordinate
{
public:
	//注：角度是指极坐标系下当前射线与x轴正方向夹角，夹角是指当前射线与后一射线的角度差值
	int loop_count = 0;//当前转动第几圈
	float calpre_angle = 0;//预测前后角相减
	float angle_back = 0;//前一角度
	float angle_now = 0;//后一角度
	float angle_include = 0;//夹角
	float angle_polar_back = 0;//极坐标前一角度
	float angle_polar_now = 0;//极坐标当前角度
	float radius_buff = 0;//能量机关的半径
	float angle_pre = 0;//预测出来的角度
	float angle_hop = 0;//装甲版切换时需要追加的角度
	float angle_pre_temp = 0;//保留上一次预测角度
	float result_pre[2];//预测和超射角
	bool anticlockwise = true; //默认逆时针为正方向
	bool anticlockwise_flag = false;//方向是否判断成功
	bool loop_add_flag = false;//判断是否可以增加圈数
	bool first_angle = true;//传入第一个角度
	bool abondon_success = false;
	cv::Point2f point_pre;//预测出来的二维点
	cv::Point2f point_center_back;//保留预测前的二维点
	cv::Point2f point_armor_back;
	vector<float> trun_count;//角度数组
	Eigen::Matrix<double, 1, 1> xyz;//卡尔曼输入矩阵



	//const int state = _3DCA_STATE, measure = _3DCA_MEASURE;
	//KalmanFilter_<double, _3DCA_STATE, _3DCA_MEASURE> Fiter;
	PolarCoordinate(double delta, int type, float shootRadio)
	{
		const int state = _1DCA_STATE, measure = _1DCA_MEASURE;
		Fiter = new KalmanFilter_<double, _1DCA_STATE, _1DCA_MEASURE>(delta, type, shootRadio);
		this->xyz <<
			0;
	}
	~PolarCoordinate()
	{
		delete Fiter;
	}


	//传入角度和半径，得到x,y坐标
	cv::Point2f x_y_cal(float angle, float radius)
	{
		Eigen::MatrixXf point2d_(2, 1);
		Eigen::MatrixXf radius_matrix(2, 2);
		Eigen::MatrixXf angel_matrix(2, 1);
		radius_matrix <<
			radius, 0,
			0, radius;
		angel_matrix <<
			cos(angle),
			sin(angle);
		point2d_ = radius_matrix * angel_matrix;
		point_pre = cv::Point2f(point2d_(0, 0) + point_center_back.x, point2d_(1, 0) + point_center_back.y);
		// cout << "calc" << point2d_ << endl;
		// cout << "point:" << point_pre.x << " " << point_pre.y << endl;
		// cout << "pre_angle "  << angle << endl;
		return point_pre;
	}
	

	//建立极坐标系
	//传入圆心和靶心，得到当前极坐标下的角度
	float polar_angle(cv::Point2f circle_center, cv::Point2f armor_center)
	{
		bool x_flag = false, y_flag = false;
		float angle = 0;
		float theta = 0;
		float cartesian_x = armor_center.x - circle_center.x;//笛卡尔坐标系
		float cartesian_y = armor_center.y - circle_center.y;
		float radius = sqrt(cartesian_x * cartesian_x + cartesian_y * cartesian_y);
		this->radius_buff = radius;
		//判断坐标在哪个象限，根据象限加角度
		cartesian_x >= 0 ? (x_flag = true) : (x_flag = false);
		cartesian_y >= 0 ? (y_flag = true) : (y_flag = false);
		//计算出当前直线与x轴的夹角
		angle = acos(abs(cartesian_x) / radius);
		x_flag ? (y_flag ? (theta = angle + 0) : (theta = 1.5 * K_PI + (0.5 * K_PI - angle))) : (y_flag ? (theta = 0.5 * K_PI + (0.5 * K_PI - angle)) : (theta = angle + 1 * K_PI));
		//cout << theta * (180 / K_PI) << endl;
		return theta;
	}

	//判断数据正反转
	void turn(float angle)//放入角度
	{
		if(this->trun_count.size() < 5) this->trun_count.push_back(angle);
		if (this->trun_count.size() == 5 && this->anticlockwise_flag == false)
		{
			int positive_count = 0;
			int negative_count = 0;
			for (int i = 0; i < this->trun_count.size(); i++)
			{
				if (i != 0)
				{
					if (abs(this->trun_count[i] - this->trun_count[i - 1]) >= 300 || abs(this->trun_count[i] - this->trun_count[i - 1]) == 0) continue;
					else if ((this->trun_count[i] - this->trun_count[i - 1]) > 0)  positive_count++;
					else if ((this->trun_count[i] - this->trun_count[i - 1]) < 0)  negative_count++;
				}
			}
			if (positive_count >= 3)
			{
				//正转
				this->anticlockwise = true;
				this->anticlockwise_flag = true;
				std::cout << "正转,buff顺时针转" << endl;
			}
			else if (negative_count >= 3)
			{
				//反转
				this->anticlockwise = false;
				this->anticlockwise_flag = true;
				std::cout << "反转,buff逆时针转" << endl;
			}
			else
			{
				std::cout << "Not enough data to judge anticlockwise (555row)" << endl;
				this->trun_count.clear();
				return;
			}
		}
		return;
	}

	//根据正反转以及圈数完成累加
	float angle2kf(float angle)
	{
		float angle_ = angle;
		this->angle_polar_now = angle;
		if (this->angle_now == 0 && !this->anticlockwise && this->anticlockwise_flag)//反转
		{
			angle_ = angle_ - 6.283185;
		}
		else if (!this->anticlockwise && this->anticlockwise_flag) angle_ = angle_ - 6.283185;
		// cout << "angle " << angle_ << endl;
		if(!this->first_angle)
		{
			this->angle_include = abs(this->angle_polar_now - this->angle_polar_back);//极坐标下的角度差值
		}
		if (this->anticlockwise && this->anticlockwise_flag)//正转
		{
			if (angle_ >= 0  && angle_ <= 0.5235986)//0 <= x <= 30 loop_count
			{
				if(this->first_angle)//是第一个角度，且进入加圈状态
				{
					loop_count--;
					angle_ = angle_ + 6.283185 * (loop_count + 1);
					loop_add_flag = true;
				}
				else
				{
					angle_ = angle_ + 6.283185 * (loop_count + 1);
					loop_add_flag = true;
				}
				// cout << "1" << endl;
			}
			else if (angle_ >= 6.195918 && angle_ <= 6.283185)//355 <= x <= 360
			{
				angle_ = angle_ + 6.283185 * loop_count;
				loop_add_flag = false;
				// cout << "2" << endl;
			}
			else if (angle_ > 0.5235986 && angle_ < 6.195918)//30 < x < 355
			{
				if (loop_add_flag)
				{
					loop_count++;
					loop_add_flag = false;
					// cout << "true3" << endl;
				}
				angle_ = angle_ + 6.283185 * loop_count;
				if(this->angle_include >= 1.047197 && this->angle_include <= 5.232986 && this->angle_polar_back > this->angle_polar_now)//若跳到之前的角后，则相当于再转了一圈
				{
					loop_count++;
					angle_ = angle_ + 6.283185 * loop_count;
				}
				// cout << "3" << endl;
			}
		}
		// cout << angle_<< endl;
		//  cout << "loop_count" << loop_count << endl;
		if (!this->anticlockwise && this->anticlockwise_flag)//反转
		{
			if (angle_ <= 0 && angle_ >= -0.5235986)//-30 <= x <=0
			{
				if(this->first_angle)
				{
					loop_count--;
					angle_ = angle_ - 6.283185 * (loop_count + 1);
					loop_add_flag = true;
				}
				else
				{
					angle_ = angle_ - 6.283185 * (loop_count + 1);
					loop_add_flag = true;
				}
			}
			else if (angle_ <= -6.195918 && angle_ >= -6.283185)//-360 <= x <=-355
			{
				angle_ = angle_ - 6.283185 * loop_count;
				loop_add_flag = false;
			}
			else if (angle_ < -0.5235986 && angle_ > -6.195918)//-355 < x < -30
			{
				if (loop_add_flag == true)	
				{
					loop_count++;
					loop_add_flag = false;
				}
				angle_ = angle_ - 6.283185 * loop_count;
				if(this->angle_include >= 1.047197 && this->angle_include <= 5.232986 && angle_polar_back < this->angle_polar_now)//若跳到之前的角后，则相当于再转了一圈
				{
					loop_count++;
					angle_ = angle_ - 6.283185 * loop_count;
				}
			}
		}
		this->angle_polar_back = angle;
		this->first_angle = false;//运行过一次之后，证明不再第一个进去的角度
		//cout << "angle " << angle_ << endl;
		// cout << angle_ * 180 / K_PI << endl;
		// cout << "---------------" << endl;
		return angle_;
	}

	//卡尔曼,保证预测点在原始点的前方
	void angle_KF(float angle, vector<Eigen::Matrix<double, _1DCA_STATE, 1 >> KFoutMatrix)
	{
		// this->angle_now = angle;
		// this->angle_include_now = abs(abs(this->angle_now) - abs(this->angle_back));
		// if (this->angle_include_now >= 0.785398)
		// {
		// 	this->angle_hop += this->angle_include_now;
		// 	if (this->anticlockwise && this->anticlockwise_flag) this->angle_now = angle - this->angle_hop;
		// 	else if (!this->anticlockwise && this->anticlockwise_flag) this->angle_now = angle + this->angle_hop;

		// }
		// if(this->angle_include >= 1.047197 && this->angle_include <= 5.232986)
		if(this->angle_include >= 1.047197 && this->angle_include <= 5.232986)
		{
			cout << "Initialize" << endl;
			cout << "angle_inclue" << this->angle_include << endl; 
			Fiter->Initialize();
			this->abondon_success = false;
			return;
		}
		// if (this->Fiter->isUseKF) this->angle_pre_temp = this->result_pre[1];//保留上一次的预测角度
		xyz(0) = angle;
		this->Fiter->Update1DCA(xyz, KFoutMatrix);
		//cout << "pre_angle: " << KFoutMatrix[1][0] << endl;
		this->result_pre[0] = KFoutMatrix[1][0];
		this->result_pre[1] = KFoutMatrix[2][0];
		//std::cout << "preangle:" << this->result_pre[1] << std::endl;
		if(abs(this->result_pre[1] - this->angle_pre_temp) >= 1)
		{
			this->abondon_success = false;
			this->angle_pre_temp = this->result_pre[1];
			return;
		}
		// cout << this->result_pre[1] << endl;
		// if (this->anticlockwise && this->anticlockwise_flag)
		// {
		// 	if (this->angle_pre_temp > this->result_pre[1])
		// 		this->angle_pre = this->angle_pre_temp - this->angle_back + this->angle_now + this->angle_hop;

		// 	else this->angle_pre = this->result_pre[1] + this->angle_hop;
		// }
		// else if (!this->anticlockwise && this->anticlockwise_flag)
		// {
		// 	if (this->angle_pre_temp < this->result_pre[1])
		// 		this->angle_pre = this->angle_now - (this->angle_back - this->angle_pre_temp) - this->angle_hop;
		// 	else this->angle_pre = this->result_pre[1] - this->angle_hop;
		// }
		// this->angle_back = this->angle_now;
		this->abondon_success = true;
		this->angle_pre_temp = this->result_pre[1];
		return ;
	}


	cv::Point2f point_KF(cv::Point2f circle_center, cv::Point2f armor_center)
	{
		vector<Eigen::Matrix<double, _1DCA_STATE, 1 >>  KFoutMatrix;
		float angle = 0;
		//判断数据是否丢帧,点的值是否都是在图幅内
		if (
			(circle_center.x > 0 && circle_center.x <= 1280) &&
			(circle_center.y > 0 && circle_center.y <= 1024) &&
			(armor_center.x > 0 && armor_center.x <= 1280) &&
			(armor_center.y > 0 && armor_center.y <= 1024)
			)
		{
			//保留了圆心点
			cout << "-----------------" << endl;
			this->point_center_back.x = circle_center.x;
			this->point_center_back.y = circle_center.y;
			angle = this->polar_angle(circle_center, armor_center);//极坐标系下角度
			this->turn(angle);//判断正反转
			angle = this->angle2kf(angle);//得到可以累加的角度
			this->angle_KF(angle, KFoutMatrix);//得到预测出来的角度
			//cout << "start_point " << armor_center.x << " " << armor_center.y << endl;
			// cout << "radius" << this->radius_buff << endl;
			if(Fiter->isUseKF && this->abondon_success) 
			{
				std::cout << "preangle " << this->result_pre[1] << std::endl;
				return this->x_y_cal(this->result_pre[1], this->radius_buff);
			}
		}
		return cv::Point2f(1, 1);
	}


private:
	//在类里定义有构造函数有参数的类的方法，可以是new一个对象，不过要手动释放
	const int state = _1DCA_STATE, measure = _1DCA_MEASURE;
	KalmanFilter_<double, _1DCA_STATE, _1DCA_MEASURE> * Fiter;
	//剔除半径的尖端误差
};