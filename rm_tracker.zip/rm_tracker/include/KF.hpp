#ifndef KalmanFilter
#define KalmanFilter

template<int states>
class KF{
    //状态预估值
    
}
#endif