#ifndef COMP
#define COMP
#include "ros/ros.h"
#include "geometry_msgs/PoseStamped.h"
#include <Eigen/Dense>
#include <opencv2/opencv.hpp>
#include <math.h>
#include <chrono>
#include <Image.h>
#include "Pid.hpp"
#include "Variable.h"

cv::Point _ThreeToTwo(cv::Mat inp,cv::Mat PointInCam)
{
    if(PointInCam.empty())
        return cv::Point(0,0);
    cv::Mat Temp_PointInCam = inp * PointInCam;
    return cv::Point(Temp_PointInCam.at<double>(0,0) / Temp_PointInCam.at<double>(2,0), Temp_PointInCam.at<double>(1,0) / Temp_PointInCam.at<double>(2,0));
}
cv::Point2f _ThreeToTwo(cv::Mat inp,Eigen::Vector3d posision)
{
    cv::Mat temp = (cv::Mat_<double>(3,1) << posision.x(),posision.y(),posision.z());
    return _ThreeToTwo(inp,temp);
}

//重力加速度
const double g = 9.800;

//摩擦系数
const double fa = 1;

//相机到odom的旋转关系
Eigen::Matrix3d R_cap2odom;
//odom到相机的旋转关系
Eigen::Matrix3d R_odom2cap;
//相机在odom下的三维信息
Eigen::Vector3d T;
Eigen::Vector3d T_Gun;
double rotate_compensation[4];


// IN
//odom的旋转关系
Eigen::Matrix3d R_odom;

void R_T_Init()
{
    //相机到odom的旋转关系
    // R_cap2odom <<  0.10944834 ,-0.91660226,-0.38452745,
    // -0.99096617, -0.07045527, -0.11411446,
    // 0.07750558, 0.39354334, -0.91603304;
    // //odom到相机的旋转关系
    // R_odom2cap << 0.10944834, -0.99096617 ,0.07750558 ,
    // -0.91660226 ,-0.07045527, 0.39354334,
    // -0.38452745, -0.11411446, -0.91603304; 
    //相机到odom的旋转关系
    R_odom2cap <<  0.03322661, -0.99928456, 0.01806541, 
        -0.01641615, -0.01861862, -0.99969188, 
        0.99931302, 0.03291981, -0.01702304;
    //odom到相机的旋转关系
    R_cap2odom << 0.03322661, -0.01641615, 0.99931302,
        -0.99928456, -0.01861862, 0.03291981, 
        0.01806541, -0.99969188, -0.01702304;
    //相机在odom下的三维信息
//     #define CAR2CAM_X 0
// #define CAR2CAM_Y 69.33
// #define CAR2CAM_Z -121
    T << 0.14524,0,0.07084;
    T_Gun << 0, -0.03472, 0.0927924;


    // IN
    //odom的旋转关系
    R_odom << 1, 0, 0,
              0, 1, 0,
              0, 0, 1;
}                          
//目标的旋转矩阵(rvec)
Eigen::Matrix3d R_P;
//目标的三维信息(tvec)
Eigen::Vector3d P;

// OUT
//目标在odom下的三维信息
Eigen::Vector3d P_odom;

// 补偿点数据的初始化
void dotargetpoint(const double x,const double y,const double z,const double w,const double px,const double py,const double pz, double pitch, double yaw,double roll)
{
    double q[4];
    q[0] = w;
    q[1] = x;
    q[2] = y;
    q[3] = z;
    P << px,py,pz;
    yaw = 0;
    roll = 0;
    Eigen::Quaterniond Q(q[0], q[1], q[2], q[3]);
    Eigen::Matrix3d rotation_matrix_pitch;
    Eigen::Matrix3d rotation_matrix_yaw;
    Eigen::Matrix3d rotation_matrix_roll;
    rotation_matrix_pitch << std::cos(pitch), 0 ,std::sin(pitch),
                                        0,1,0,
                                        -std::sin(pitch),0,std::cos(pitch);
    rotation_matrix_yaw << std::cos(yaw), -std::sin(yaw), 0,
                            std::sin(yaw), std::cos(yaw), 0,
                            0, 0, 1;

    rotation_matrix_roll << 1, 0, 0,
                        0, std::cos(roll), -std::sin(roll),
                        0, std::sin(roll), std::cos(roll);
    R_odom = rotation_matrix_yaw * rotation_matrix_pitch * rotation_matrix_roll;
    rotate_compensation[0] = x;
    rotate_compensation[1] = y;
    rotate_compensation[2] = z;
    rotate_compensation[3] = w;         
}

// 将相机系下的装甲板中心点转到odom下 (考虑两轴旋转， 用于算补偿)
void CameraToOdom()
{
    auto pp = P - T_Gun;
    cout << P << endl;
    P_odom = R_odom * (R_cap2odom * pp + T);
}
// 将相机系下的 p 点转到odom下
Eigen::Vector3d CameraToOdom(cv::Mat p)
{
    Eigen::Vector3d PP;
    Eigen::Vector3d Pts;
    PP << p.at<double>(0,0) / 1000 ,p.at<double>(1,0) / 1000,p.at<double>(2,0) / 1000;
    Pts = R_odom * (R_cap2odom * PP + T);
    return Pts;
}

// 将相机系下的装甲板中心点转到odom下 (考虑三轴旋转)
Eigen::Vector3d CameraToOdom_(double roll, double pitch, double yaw)
{
    Eigen::Vector3d PP;
    //roll轴的旋转矩阵
    Eigen::Matrix3d rotation_matrix_roll;
    //pitch轴的旋转矩阵
    Eigen::Matrix3d rotation_matrix_pitch;
    //yaw轴的旋转矩阵
    Eigen::Matrix3d rotation_matrix_yaw;
    rotation_matrix_roll << 1, 0, 0,
                            0, std::cos(roll), -std::sin(roll),
                            0, std::sin(roll), std::cos(roll);

    rotation_matrix_pitch << std::cos(pitch), 0 ,std::sin(pitch),
                             0, 1, 0,
                            -std::sin(pitch), 0, std::cos(pitch);

    rotation_matrix_yaw << std::cos(yaw), -std::sin(yaw), 0,
                           std::sin(yaw), std::cos(yaw), 0,
                           0, 0, 1;
    // PP = (R_cap2odom * P + T);
    // std::cout << "PP:" << PP << std::endl;rotation_matrix_pitch
    PP = rotation_matrix_yaw * rotation_matrix_pitch * rotation_matrix_roll * (R_cap2odom * P + T);
    // std::cout << "P_odom:" << P_odom << std::endl;
    return PP;
}

//补偿点odom系转为相机系
cv::Mat ComPointInOdomToCam(double compesation, cv::Mat tvec)
{
    // 先构造补偿点在陀螺仪系下的点
    Vector3d tvec_;
    tvec_ << tvec.at<double>(0, 0), tvec.at<double>(1, 0), tvec.at<double>(2, 0);
    auto pp = tvec_ - T_Gun;
    auto _P_Odom = R_odom * (R_cap2odom * pp + T);
    Eigen::Vector3d Com_odom, Com_cap;
    Com_odom[0]=_P_Odom[0];
    Com_odom[1]=_P_Odom[1];
    Com_odom[2]=_P_Odom[0] * tan(compesation);
    Com_cap = R_odom2cap * (R_odom.inverse() * Com_odom - T_Gun);
    auto ppp = Com_cap + T_Gun;
    cv::Mat Target = cv::Mat::zeros(3,1,CV_64F);
    Target.at<double>(0,0)=static_cast<double>(ppp[0]) * 1000;
    Target.at<double>(1,0)=static_cast<double>(ppp[1]) * 1000;
    Target.at<double>(2,0)=static_cast<double>(ppp[2]) * 1000;
    // cout << Target.at<double>(0,0) << "/t" << Target.at<double>(1,0) << ""
    return Target;
}

//odom系转为相机系-------这是构造的已经经过旋转
vector<Eigen::Vector3d> fourPointInOdomToCam(double roll, double pitch, double yaw)
{
    // std::cout << "Odom下的中心坐标:" << P_odom << endl;
    //四点陀螺仪系下坐标
    Eigen::Vector3d P1, P2, P3, P4;
    //四点相机系下坐标
    Eigen::Vector3d P11, P22, P33, P44;
    //陀螺仪旋转矩阵的逆
    Eigen::Matrix3d R_odom_inverse;
    //roll轴的旋转矩阵
    Eigen::Matrix3d rotation_matrix_roll;
    //pitch轴的旋转矩阵
    Eigen::Matrix3d rotation_matrix_pitch;
    //yaw轴的旋转矩阵
    Eigen::Matrix3d rotation_matrix_yaw;

    rotation_matrix_roll << 1, 0, 0,
                            0, std::cos(roll), -std::sin(roll),
                            0, std::sin(roll), std::cos(roll);

    rotation_matrix_pitch << std::cos(pitch), 0 ,std::sin(pitch),
                             0, 1, 0,
                            -std::sin(pitch), 0, std::cos(pitch);

    rotation_matrix_yaw << std::cos(yaw), -std::sin(yaw), 0,
                           std::sin(yaw), std::cos(yaw), 0,
                           0, 0, 1;


    R_odom_inverse = R_odom.inverse();

    P1 =  P_odom + rotation_matrix_yaw * rotation_matrix_pitch * rotation_matrix_roll * Eigen::Vector3d(0, -Half_Width / 1000, Half_Height / 1000);
    P2 =  P_odom + rotation_matrix_yaw * rotation_matrix_pitch * rotation_matrix_roll * Eigen::Vector3d(0, Half_Width / 1000, Half_Height / 1000);
    P3 =  P_odom + rotation_matrix_yaw * rotation_matrix_pitch * rotation_matrix_roll * Eigen::Vector3d(0, Half_Width / 1000, -Half_Height / 1000);
    P4 =  P_odom + rotation_matrix_yaw * rotation_matrix_pitch * rotation_matrix_roll * Eigen::Vector3d(0, -Half_Width / 1000, -Half_Height / 1000);

    P11 =  R_odom2cap * (R_odom_inverse * P1 - T);
    P22 =  R_odom2cap * (R_odom_inverse * P2 - T);
    P33 =  R_odom2cap * (R_odom_inverse * P3 - T);
    P44 =  R_odom2cap * (R_odom_inverse * P4 - T);

    vector<Eigen::Vector3d> pionts;
    pionts.push_back(P11);
    pionts.push_back(P22);
    pionts.push_back(P33);
    pionts.push_back(P44);

    return pionts;
}

//      P44 =  R_odom2cap * (R_odom_inverse * (P_odom + rotation_matrix_yaw * rotation_matrix_pitch * armorpoints[i]) - T);
//      p44 = R_odom2cap * R_odom_inverse * P_odom + R_odom2cap * R_odom_inverse * rotation_matrix_yaw * rotation_matrix_pitch * armorpoints[i] - R_odom2cap * T;
//      p44 = PA + R * R_yaw * PB - PC;
//      p44_2 = inp_M * PA + inp_M * R * R_yaw * PB - inp_M - PC;
//      p44_2[0][0] = p44_2[0][0] / p44_2[2][0];
//      p44_2[1][0] = p44_2[1][0] / p44_2[2][0];
//      dis = (p44_2[0][0] - p.x)^2 + (p44_2[1][0] - p.y)^2
//      dis_d = 

// R = 内参 * R_odom2cap * R_odom_inverse，P_rebuild_pitch = rotation_matrix_pitch * armorpoints[i], T_cam = 内参 * R_odom2cap * T
double gradfunch(Eigen::Matrix3d R, double yaw, Eigen::Vector3d P_odom, Eigen::Vector3d P_rebuild_pitch, Eigen::Vector3d T_cam, Eigen::Vector2d imagePoint)
{   
    // 矩阵
    double a, b, c, d, e, f, g, h, i;
    a = R(0, 0); b = R(1, 0); c = R(2, 0); d = R(1, 0); e = R(1, 1); f = R(1, 2); g = R(2, 0); h = R(2, 1); i = R(2, 2);
    // odom下的点
    double x_odom, y_odom, z_odom;
    x_odom = P_odom(0, 0); y_odom = P_odom(1, 0); z_odom = P_odom(2, 0);
    // pitch
    double x, y, z;
    x = P_rebuild_pitch(0, 0); y = P_rebuild_pitch(1, 0); z = P_rebuild_pitch(2, 0);
    // T_cam
    double x_t, y_t, z_t;
    x_t = T_cam(0, 0); y_t = T_cam(1, 0); z_t = T_cam(2, 0);
    // 2d point
    double ox, oy;
    ox = imagePoint(0, 0); ox = imagePoint(1, 0);
    double grad =   
                    - 2*(ox - (a*x_odom - x_t + b*y_odom + c*z + c*z_odom + x*(a*cos(yaw) + b*sin(yaw))
                    + y*(b*cos(yaw) - a*sin(yaw)))/(g*x_odom - z_t + h*y_odom + i*z + i*z_odom +
                    x*(g*cos(yaw) + h*sin(yaw)) + y*(h*cos(yaw) - g*sin(yaw))))*((x*(b*cos(yaw) -
                    a*sin(yaw)) - y*(a*cos(yaw) + b*sin(yaw)))/(g*x_odom - z_t + h*y_odom + i*z +
                    i*z_odom + x*(g*cos(yaw) + h*sin(yaw)) + y*(h*cos(yaw) - g*sin(yaw))) -
                    ((x*(h*cos(yaw) - g*sin(yaw)) - y*(g*cos(yaw) + h*sin(yaw)))*(a*x_odom - x_t +
                    b*y_odom + c*z + c*z_odom + x*(a*cos(yaw) + b*sin(yaw)) + y*(b*cos(yaw) -
                    a*sin(yaw))))/pow((g*x_odom - z_t + h*y_odom + i*z + i*z_odom + x*(g*cos(yaw) +
                    h*sin(yaw)) + y*(h*cos(yaw) - g*sin(yaw))),2)) - 2*(oy - (d*x_odom - y_t + e*y_odom +
                    f*z + f*z_odom + x*(d*cos(yaw) + e*sin(yaw)) + y*(e*cos(yaw) -
                    d*sin(yaw)))/(g*x_odom - z_t + h*y_odom + i*z + i*z_odom + x*(g*cos(yaw) +
                    h*sin(yaw)) + y*(h*cos(yaw) - g*sin(yaw))))*((x*(e*cos(yaw) - d*sin(yaw)) -
                    y*(d*cos(yaw) + e*sin(yaw)))/(g*x_odom - z_t + h*y_odom + i*z + i*z_odom +
                    x*(g*cos(yaw) + h*sin(yaw)) + y*(h*cos(yaw) - g*sin(yaw))) - ((x*(h*cos(yaw) -
                    g*sin(yaw)) - y*(g*cos(yaw) + h*sin(yaw)))*(d*x_odom - y_t + e*y_odom + f*z +
                    f*z_odom + x*(d*cos(yaw) + e*sin(yaw)) + y*(e*cos(yaw) - d*sin(yaw))))/pow((g*x_odom -
                    z_t + h*y_odom + i*z + i*z_odom + x*(g*cos(yaw) + h*sin(yaw)) + y*(h*cos(yaw) -
                    g*sin(yaw))), 2));
    return grad;
}



double YawCalc(cv::Mat inp,std::vector<cv::Point2f> arPos)
{
    constexpr double yawlimit[2] = {120 * D2R,240 * D2R};
    const Eigen::Vector3d armorpoints[4] = {{0, -Half_Width / 1000, Half_Height / 1000},{0, Half_Width / 1000, Half_Height / 1000},{0, Half_Width / 1000, -Half_Height / 1000},{0, -Half_Width / 1000, -Half_Height / 1000}};
    constexpr double learnRate = 0.0001;
    int loops = 1;
    int lll;
    Eigen::Matrix3d inp_M;
    Eigen::Matrix3d R;
    // std::cout << "Odom下的中心坐标:" << P_odom << endl;
    //陀螺仪旋转矩阵的逆
    Eigen::Matrix3d R_odom_inverse;
    //pitch轴的旋转矩阵
    Eigen::Matrix3d rotation_matrix_pitch;
    //yaw轴的旋转矩阵
    Eigen::Matrix3d rotation_matrix_yaw;
    Eigen::Matrix3d d_rotation_matrix_yaw;
    R_odom_inverse = R_odom.inverse();
    double grad = 0;
    double yaw = 120 * D2R;
    rotation_matrix_pitch << std::cos(-15.0f * D2R), 0 ,std::sin(-15.0f * D2R),
                             0, 1, 0,
                            -std::sin(-15.0f * D2R), 0, std::cos(-15.0f * D2R);

    rotation_matrix_yaw << std::cos(yaw), -std::sin(yaw), 0,
                           std::sin(yaw), std::cos(yaw), 0,
                           0, 0, 1;



    inp_M << inp.at<double>(0,0),inp.at<double>(0,1),inp.at<double>(0,2),inp.at<double>(1,0),inp.at<double>(1,1),inp.at<double>(1,2),inp.at<double>(2,0),inp.at<double>(2,1),inp.at<double>(2,2);
    R = inp_M * R_odom2cap * R_odom.inverse();
    do{
        grad = 0;
        //      P44 =  R_odom2cap * (R_odom_inverse * (P_odom + rotation_matrix_yaw * rotation_matrix_pitch * armorpoints[i]) - T);
        //      p44 = R_odom2cap * R_odom_inverse * P_odom + R_odom2cap * R_odom_inverse * rotation_matrix_yaw * rotation_matrix_pitch * armorpoints[i] - R_odom2cap * T;
        //      p44 = PA + R * R_yaw * PB - PC;
        //      p44_2 = inp_M * PA + inp_M * R * R_yaw * PB - inp_M - PC;
        //      p44_2[0][0] = p44_2[0][0] / p44_2[2][0];
        //      p44_2[1][0] = p44_2[1][0] / p44_2[2][0];
        //      dis = (p44_2[0][0] - p.x)^2 + (p44_2[1][0] - p.y)^2
        //      dis_d = 
        
        for(int i = 0;i < 4;i++){
            // a b c
            // d e f
            // g h i
            // grad += cv::norm(_ThreeToTwo(inp,R_odom2cap * (R_odom_inverse * (P_odom + d_rotation_matrix_yaw * rotation_matrix_pitch * armorpoints[i]) - T)) - arPos[i]);
            // auto P = P_odom + d_rotation_matrix_yaw * rotation_matrix_pitch * armorpoints[i];
            // auto P_new = R * rotation_matrix_yaw * P;
            // grad = -2*((P.x()*(R(0,1)*cos(yaw) - R(0,0)*sin(yaw)) - P.y()*(R(0,0)*cos(yaw) + R(0,1)*sin(yaw)))/(R(2,2)*P.z() + P.x()*(R(2,0)*cos(yaw) + R(2,1)*sin(yaw)) + P.y()*(R(2,1)*cos(yaw) - R(2,0)*sin(yaw))) - ((P.x()*(R(2,1)*cos(yaw) - R(2,0)*sin(yaw)) - P.y()*(R(2,0)*cos(yaw) + R(2,1)*sin(yaw)))*(R(0,2)*P.z() + P.x()*(R(0,0)*cos(yaw) + R(0,1)*sin(yaw)) + P.y()*(R(0,1)*cos(yaw) - R(0,0)*sin(yaw))))/(R(2,2)*P.z() + P.x()*(R(2,0)*cos(yaw) + R(2,1)*sin(yaw)) + P.y()*(R(2,1)*cos(yaw) - R(2,0)*sin(yaw))) * (R(2,2)*P.z() + P.x()*(R(2,0)*cos(yaw) + R(2,1)*sin(yaw)) + P.y()*(R(2,1)*cos(yaw) - R(2,0)*sin(yaw))))*(arPos[i].x - (R(0,2)*P.z() + P.x()*(R(0,0)*cos(yaw) + R(0,1)*sin(yaw)) + P.y()*(R(0,1)*cos(yaw) - R(0,0)*sin(yaw)))/(R(2,2)*P.z() + P.x()*(R(2,0)*cos(yaw) + R(2,1)*sin(yaw)) + P.y()*(R(2,1)*cos(yaw) - R(2,0)*sin(yaw)))) - 2*((P.x()*(R(1,1)*cos(yaw) - R(1,0)*sin(yaw)) - P.y()*(R(1,0)*cos(yaw) + R(1,1)*sin(yaw)))/(R(2,2)*P.z() + P.x()*(R(2,0)*cos(yaw) + R(2,1)*sin(yaw)) + P.y()*(R(2,1)*cos(yaw) - R(2,0)*sin(yaw))) - ((P.x()*(R(2,1)*cos(yaw) - R(2,0)*sin(yaw)) - P.y()*(R(2,0)*cos(yaw) + R(2,1)*sin(yaw)))*(R(1,2)*P.z() + P.x()*(R(1,0)*cos(yaw) + R(1,1)*sin(yaw)) + P.y()*(R(1,1)*cos(yaw) - R(1,0)*sin(yaw))))/(R(2,2)*P.z() + P.x()*(R(2,0)*cos(yaw) + R(2,1)*sin(yaw)) + P.y()*(R(2,1)*cos(yaw) - R(2,0)*sin(yaw))) * (R(2,2)*P.z() + P.x()*(R(2,0)*cos(yaw) + R(2,1)*sin(yaw)) + P.y()*(R(2,1)*cos(yaw) - R(2,0)*sin(yaw))))*(arPos[i].y - (R(1,2)*P.z() + P.x()*(R(1,0)*cos(yaw) + R(1,1)*sin(yaw)) + P.y()*(R(1,1)*cos(yaw) - R(1,0)*sin(yaw)))/(R(2,2)*P.z() + P.x()*(R(2,0)*cos(yaw) + R(2,1)*sin(yaw)) + P.y()*(R(2,1)*cos(yaw) - R(2,0)*sin(yaw))));
            grad += gradfunch(R, yaw, P_odom, rotation_matrix_pitch * armorpoints[i], inp_M * R_odom2cap * T, {arPos[i].x, arPos[i].y});
        }
        grad /= 4;
        yaw -= learnRate * grad;
        // cout << loops << "\t|GRAD:" << grad << "\t|YAW:" << yaw << endl;
        loops += 1;
        // cv::waitKey(1);
    }while(abs(grad) > 10e-2);
    // cout << "YAW:" << (yaw - (int)(yaw / (2*PI)) * 2 * PI) <<endl;
    if(yaw < yawlimit[0])
        return yawlimit[0];
    if(yaw > yawlimit[1])
        return yawlimit[1];
    return yaw;
}

//odom系转为相机系-------这是构造的没有经过旋转
vector<Eigen::Vector3d> fourPointInCamearToOdom()
{
    // std::cout << "Odom下的中心坐标:" << P_odom << endl;
    //四点陀螺仪系下坐标
    Eigen::Vector3d P1, P2, P3, P4;

    P1 =  P_odom + Eigen::Vector3d(0, -Half_Width / 1000, Half_Height / 1000);
    P2 =  P_odom + Eigen::Vector3d(0, Half_Width / 1000, Half_Height / 1000);
    P3 =  P_odom + Eigen::Vector3d(0, Half_Width / 1000, -Half_Height / 1000);
    P4 =  P_odom + Eigen::Vector3d(0, -Half_Width / 1000, -Half_Height / 1000);

    vector<Eigen::Vector3d> points;
    points.push_back(P1);
    points.push_back(P2);
    points.push_back(P3);
    points.push_back(P4);

    return points;
}
// 将陀螺仪系下的点转换到相机系下
Eigen::Vector3d OdomToCam(Eigen::Vector3d podom){
    return R_odom2cap * (R_odom.inverse() * podom - T);
}

double CalEuclideanDis(vector<cv::Point2f> rp, vector<cv::Point2f> tp)
{
    double dis;
    for(int i = 0; i < 4; i++)
    {
        dis += sqrt((rp[i].x - tp[i].x) * (rp[i].x - tp[i].x) + (rp[i].y - tp[i].y) * (rp[i].y - tp[i].y));
    }
    // cout << "dis:" << dis << endl;
    return dis / 4;
}

// 计算仰角 
double cal_pitch(double depth, double height, double v)
{
    double _height;
    double xita = -PI / 4;
    std::cout << depth << "/t!!!" << height << std::endl;
    while(xita < PI / 3)
    {
        _height = depth * std::tan(xita) - (g * fa * depth * depth) / (2 * (v * fa * std::cos(xita)) * (v * fa * std::cos(xita)));
        // cout << "fenmu:" << (2 * (v * fa * std::cos(xita)) * (v * fa * std::cos(xita))) << endl;
        // cout << "xita:" << xita << endl;
        // cout << "H-DIS:" << height << " " << _height << endl;
        if(std::fabs(height - _height) < 0.01)
        {
            // std::cout << "height_diff:" << (height - _height) << std::endl;
            return xita;
        }
        xita += 0.001;//目前输出的值为相对于相机现在的姿态所要转的角度，即相机坐标系下的仰角
    }
    return 0;
}
// 计算补偿
double Compensation_Calc(double x,double y,double z,double w,double px,double py,double pz,double picth, double yaw,double roll,double vec = 30)
{
    dotargetpoint(x,y,z,w,px,py,pz,picth,yaw,roll);
    CameraToOdom();
    // std::cout << duration.count() << std::endl;
    // std::cout << "FPS" << 1.0 / time << std::endl;
    
    // std::cout << "R_odom:" << R_odom << std::endl;
    // std::cout << "R_cap2odom:" << R_cap2odom << std::endl;
    // std::cout << "P:" << P << std::endl;c
    // std::cout << "T:" << T << std::endl;
    return cal_pitch(fabs(P_odom[0]), P_odom[2], vec);
}

// 计算两条直线的夹角
double CalculateAngleBetweenLines(double slope1, double slope2) {
    // 根据斜率计算夹角
    //double angle = std::atan(std::abs((slope2 - slope1) / (1 + slope1 * slope2)));

    double angle = std::atan(slope1);

    // 将弧度转换为度
    angle = angle * 180.0 / PI;
    return angle;
}

const double double_max = std::numeric_limits<double>::max();
// 计算斜率
double CalculateSlope(const Eigen::Vector2d* p) {
    if(!p)
        return double_max;
    double k1 = 0, k2 = 0;
    // 避免分母为0的情况
    if (p[1].y() - p[0].y() == 0) {
        // 这里可以选择抛出异常或者返回一个特定值，这里选择返回一个极大值
        k1 = double_max;
    }
    else
        k1 = (p[1].x() - p[0].x()) / (p[1].y() - p[0].y());
    
    if (p[3].y() - p[2].y() == 0) {
        // 这里可以选择抛出异常或者返回一个特定值，这里选择返回一个极大值
        k2 = double_max;
    }
    else
        k2 = (p[3].x() - p[2].x()) / (p[3].y() - p[2].y());
    
    if(k1 == double_max && k2 == double_max){
        
        return double_max;
    }
    if(k1 == double_max){
        
        return k2;
    }
    else if(k2 == double_max){
        
        return k1;
    }
    else{
        return (k1 + k2) / 2;
    }
}
double CalculateSlope(std::vector<Eigen::Vector2d> p) {
    return CalculateSlope(p.data());
}
 
/***********************Hero***************************/
//计算打击装甲板所需要的时间
double H_AirResistance(double Vy, double r) {
	double rho = 1.225;  // 空气密度
	double A = PI * r * r;  // 球体的横截面积
	double Cd = 0.5;     // 物体的阻力系数
	return -0.5 * rho * A * Cd * Vy * Vy;	
}

Eigen::Vector2d CalcalateTotalDistance(double angle,double V,double height_diff, double R)//绝对——仰角 速度 高度差（枪——装）子弹半径
{
    double theta = angle * PI / 180.0;
    double m = 0.1;//子弹质量（要改）
    double g = 9.8;
    double v = V;//初速度
    double t1 = v * sin(theta) / g;
    double height = (v * v * sin(theta) * sin(theta)) / (2 * g);
    double height2 = height + height_diff;
    double t2 = sqrt(2 * abs(height2) / g);
    double Totaltime = t1 + t2;
    double dt = 0.0001;//迭代时间间隔
    double t = 0.0;//当前时间
    double y = 0.6;//当前车枪口高度（要改）
    while(t<Totaltime)
    {
        double F = H_AirResistance(v,R);
        double a = (F / m) - g;
        v += a*dt;
        y += v * sin(theta) * dt;
        t += dt;
        t = Totaltime;
    }
    std::cout << "totaltime" << Totaltime << std::endl;
    double distance = v * cos(theta) * Totaltime;
    std::cout << "Distance" << 100 * distance << std::endl; 
    return Eigen::Vector2d(Totaltime,distance);
}
double TrisectionCalYaw(vector<double> index, vector<double> errs, double eps)
{
    double left = index[0];
    double right = index[index.size() - 1];
    while(right - left > eps){
        double mid = (left + right) / 2;
        double midNext = mid + eps;
        if(errs[int(mid)] < errs[int(midNext)])
        {
            right = midNext;
        }
        else
        {
            left = mid;
        }
    }
    return (left + right) / 2;
}

const double m = 0.445;//英雄弹丸重量kg
const double R = 0.021;//英雄弹丸半径m

////英雄打击飞镖位置

double CalculateMaxHeight(double V, double launchAngle) {
	double vx = V * cos(launchAngle);// 水平方向速度
	double vy = V * sin(launchAngle); // 垂直方向速度
	double t = 2 * vy / g; // 飞行时间

	double airResistance = H_AirResistance(vy, R);
	double a = airResistance / m; // 空气阻力对应的加速度
	double t1 = vy / g; // 垂直方向运动时间
	double maxHeight = vy * vy / (2 * a); // 最大高度
	return abs(maxHeight);
}

double Odom_Hero_FB(double _YAW, double Odom_recognize_angle)//Odom_recognize_angle为识别角(弧度)   
{
	double h1 = 0.21;
	double h2 = 1.2;//识别的高
	double V = 14;
	double h3 = 0.3;//车枪口高（要改）
	double H = h1 + h2 - h3;
	double FB_Angle = atan((h1 * tan(Odom_recognize_angle) / h2) + tan(Odom_recognize_angle));
	if (abs(_YAW) < 5 || (_YAW < 180 && _YAW>175))
	{
		while (FB_Angle < (PI/2))
		{
			double Vx = V * cos(FB_Angle);
			double Vy = V * sin(FB_Angle);
			double airResistance = H_AirResistance(Vy, R);
			double a = airResistance / m; // 空气阻力对应的加速度
			double depth = h2 / tan(Odom_recognize_angle);
			double MaxHeight = CalculateMaxHeight(V, FB_Angle);//按此发射角所得到的最大高度
			double t = (-Vx + sqrt(Vx * Vx + 2 * a * depth)) / a;//depth换过来为负值
			if (t < 0)
				return -1;
			else {
				double hit_h = static_cast<double>(1) / 2 * (-g) * t * t + Vy * t;
				if (hit_h < MaxHeight) 
				{
					while (abs(hit_h - MaxHeight) < 0.001)
					{
						if (hit_h > MaxHeight)
						{
							FB_Angle -= 0.0002;
						}
						else if (hit_h < MaxHeight)
						{
							FB_Angle += 0.0002;
						}
					}
					return FB_Angle;
				}else
					{
					 double diff = 0;
					 diff = abs(MaxHeight - hit_h);
					 double t1 = sqrt(2 * diff / g);
					 double t2 = Vy / g;
				 	 double depth_cal = static_cast<double>(1) / 2 * a * (t1 + t2) * (t1 + t2) + Vx * t;

						while (abs(depth_cal - depth) < 0.001)
						{
							if (depth_cal > depth)
							{
								FB_Angle -= 0.02;
							}
							else if (depth_cal < depth)
							{
								FB_Angle += 0.02;
							}
						}
						return FB_Angle;
				}
				}
			}
		}
	else {
		return -1;
	}
	return -1;
}

#endif