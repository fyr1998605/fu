#include<ros/ros.h>
#include<Eigen/Dense>
#include<geometry_msgs/Point.h>

using namespace std;
using namespace Eigen;

namespace Fiter{
    class EKF
    {
    public:
    

        using VecVecFunc = std::function<Eigen::VectorXd(const Eigen::VectorXd &)>;
        using VecMatFunc = std::function<Eigen::MatrixXd(const Eigen::VectorXd &)>;
        using VoidMatFunc = std::function<Eigen::MatrixXd()>;

        EKF(ros::NodeHandle nh);
        Eigen::MatrixXd predict(double);
        Eigen::MatrixXd update(const Eigen::VectorXd & z,double);
        void setState(const Eigen::VectorXd & x0);
        bool isUseUkF();
        void setPri(const Eigen::VectorXd & p0);
        void setParam();
    private:
        // 节点
        ros::NodeHandle nh;
        // Process nonlinear vector function 状态函数
        VecVecFunc f;
        // Observation nonlinear vector function 观测函数
        VecVecFunc h;
        // Jacobian of f() 状态函数的雅各比矩阵
        VecMatFunc jacobian_f; 
        Eigen::MatrixXd F;
        // Jacobian of h() 观测函数的雅各布矩阵
        VecMatFunc jacobian_h;
        Eigen::MatrixXd H;
        // Process noise covariance matrix 过程噪声协方差矩阵
        VoidMatFunc update_Q;
        Eigen::MatrixXd Q;
        // Measurement noise covariance matrix 测量噪声协方差矩阵
        VecMatFunc update_R;
        Eigen::MatrixXd R;
        // Priori error estimate covariance matrix 先验误差协方差矩阵
        Eigen::MatrixXd P_pri;
        // Posteriori error estimate covariance matrix 后验误差协方差矩阵
        Eigen::MatrixXd P_post;
        // Kalman gain 卡尔曼增益
        Eigen::MatrixXd K;
        // System dimensions 
        int n;
        // N-size identity 单位矩阵
        Eigen::MatrixXd I;

        // Priori state 先验估计
        Eigen::VectorXd x_pri;
        // Posteriori state 后验估计
        Eigen::VectorXd x_post;

        double dt_;
        // x y z的过程噪声的方差
        double s2qxyz_;
        // yaw 的过程噪声方差
        double s2qyaw_;
        // r 的过程噪声方差
        double s2qr_;
        // x y z 的观测噪声的方差
        double r_xyz_factor;
        // r 的观测噪声的方差
        double r_yaw;
        
        double lastTime;

        int isUseEkfFlag;
    };

    EKF::EKF(ros::NodeHandle nh)
    {
        nh.param("s2qxyz_", s2qxyz_, 0.0000001);//0.0000001
        // s2qxyz_ = 0;
        nh.param("s2qyaw_", s2qyaw_, 100.0);//0.43
        nh.param("s2qr_", s2qr_, 800.0);
        // s2qr_ = 0;
        nh.param("r_xyz_factor", r_xyz_factor, 9000.0);//1.7
        nh.param("r_yaw", r_yaw, 0.02);
        
        // // x y z的过程噪声的方差
        // s2qxyz_ = 0.5;
        // // yaw 的过程噪声方差
        // s2qyaw_ = 100.0;
        // // r 的过程噪声方差
        // s2qr_ = 800.0;
        // // x y z 的观测噪声的方差
        // r_xyz_factor = 0.05;
        // // r 的观测噪声的方差
        // r_yaw = 0.02;
        isUseEkfFlag = 0;
        // cout << "s2qxyz_" << s2qxyz_ << endl;
        // cout << "s2qyaw_" << s2qyaw_ << endl;
        // cout << "s2qr_" << s2qr_ << endl;

        // cout << "r_xyz_factor" << r_xyz_factor << endl;
        // cout << "r_yaw" << r_yaw << endl;

        // sleep(5);

        // EKF
        // xa = x_armor, xc = x_robot_center
        // state: xc, v_xc, yc, v_yc, za, v_za, yaw, v_yaw, r
        // measurement: xa, ya, za, yaw 
        // f - Process function
        lastTime = ros::Time::now().nsec;
        // 状态函数
        auto f = [this](const Eigen::VectorXd & x) {
            Eigen::VectorXd x_new = x;
            x_new(0) += x(1) * dt_;
            x_new(2) += x(3) * dt_;
            x_new(4) += x(5) * dt_;
            x_new(6) += x(7) * dt_;
            return x_new;
        };
        // J_f - Jacobian of process function
        // 状态函数的雅各比矩阵
        auto j_f = [this](const Eigen::VectorXd &) {
            Eigen::MatrixXd f(9, 9);
            // clang-format off
            f <<  1,   dt_, 0,   0,   0,   0,   0,   0,   0,
                0,   1,   0,   0,   0,   0,   0,   0,   0,
                0,   0,   1,   dt_, 0,   0,   0,   0,   0, 
                0,   0,   0,   1,   0,   0,   0,   0,   0,
                0,   0,   0,   0,   1,   dt_, 0,   0,   0,
                0,   0,   0,   0,   0,   1,   0,   0,   0,
                0,   0,   0,   0,   0,   0,   1,   dt_, 0,
                0,   0,   0,   0,   0,   0,   0,   1,   0,
                0,   0,   0,   0,   0,   0,   0,   0,   1;
            // clang-format on
            return f;
        };
        // h - Observation function
        // 观测函数 
        auto h = [](const Eigen::VectorXd & x) {
            Eigen::VectorXd z(4);
            double xc = x(0), yc = x(2), yaw = x(6), r = x(8);
            z(0) = xc - r * cos(yaw);  // xa
            z(1) = yc - r * sin(yaw);  // ya
            z(2) = x(4);               // za
            z(3) = x(6);               // yaw
            return z;
        };
        
        // J_h - Jacobian of observation function
        // 观测函数的雅各比矩阵
        auto j_h = [](const Eigen::VectorXd & x) {
            Eigen::MatrixXd h(4, 9);
            double yaw = x(6), r = x(8);
            // clang-format off
            //    xc   v_xc yc   v_yc za   v_za yaw         v_yaw r
            h <<  1,   0,   0,   0,   0,   0,   r*sin(yaw), 0,   -cos(yaw),
                0,   0,   1,   0,   0,   0,   -r*cos(yaw),0,   -sin(yaw),
                0,   0,   0,   0,   1,   0,   0,          0,   0,
                0,   0,   0,   0,   0,   0,   1,          0,   0;
            // clang-format on
            return h;
        };
        // update_Q - process noise covariance matrix
        auto u_q = [this]() {
            Eigen::MatrixXd q(9, 9);
            double t = dt_, x = s2qxyz_, y = s2qyaw_, r = s2qr_;
            // 这段公式是算各个变量的协方差
            double q_x_x = pow(t, 4) / 4 * x, q_x_vx = pow(t, 3) / 2 * x, q_vx_vx = pow(t, 2) * x;
            double q_y_y = pow(t, 4) / 4 * y, q_y_vy = pow(t, 3) / 2 * x, q_vy_vy = pow(t, 2) * y;
            double q_r = pow(t, 4) / 4 * r;
            // clang-format off
            //    xc      v_xc    yc      v_yc    za      v_za    yaw     v_yaw   r
            q <<  q_x_x,  q_x_vx, 0,      0,      0,      0,      0,      0,      0,
                q_x_vx, q_vx_vx,0,      0,      0,      0,      0,      0,      0,
                0,      0,      q_x_x,  q_x_vx, 0,      0,      0,      0,      0,
                0,      0,      q_x_vx, q_vx_vx,0,      0,      0,      0,      0,
                0,      0,      0,      0,      q_x_x,  q_x_vx, 0,      0,      0,
                0,      0,      0,      0,      q_x_vx, q_vx_vx,0,      0,      0,
                0,      0,      0,      0,      0,      0,      q_y_y,  q_y_vy, 0,
                0,      0,      0,      0,      0,      0,      q_y_vy, q_vy_vy,0,
                0,      0,      0,      0,      0,      0,      0,      0,      q_r;
            // clang-format on
            return q;
        };
        // update_R - measurement noise covariance matrix
        auto u_r = [this](const Eigen::VectorXd & z) {
            Eigen::DiagonalMatrix<double, 4> r;
            double x = r_xyz_factor;
            
            if(isnan(x))
                x = 0.05;
            r.diagonal() << abs(x * z[0]), abs(x * z[1]), abs(x * z[2]), r_yaw;
            return r;
        };
        
        // P - error estimate covariance matrix
        Eigen::DiagonalMatrix<double, 9> p0;
        p0.setIdentity();
        
        this->f = f;
        this->jacobian_f = j_f;
        this->h = h;
        this->jacobian_h = j_h;
        this->update_Q = u_q;
        this->update_R = u_r;
        this->P_post = p0;
        this->n = p0.rows();
        this->I = (Eigen::MatrixXd::Identity(n, n));
        this->x_pri = VectorXd::Zero(n);
        this->x_post = VectorXd::Zero(n);
    }

    Eigen::MatrixXd EKF::predict(double in_dt = 0.02)
    {
        this->dt_ = in_dt;
        // double nowTime = ros::Time::now().nsec;
        // this->dt_ = (nowTime - this->lastTime) * 10e-9;
        // lastTime = nowTime;
        // this->dt_ = 0.02;
        // cout << this->dt_ << endl;
        // 求雅各比矩阵
        F = jacobian_f(x_post), Q = update_Q();
        // 先验估计

        x_pri = f(x_post);
        // 先验估计的协方差矩阵
        P_pri = F * P_post * F.transpose() + Q;

        // handle the case when there will be no measurement before the next predict
        // 当没有获取到观测量时，避免EKF不连续，所以采用这一帧的先验用作后验
        x_post = x_pri;
        P_post = P_pri;

        return x_pri;
    }

    Eigen::MatrixXd EKF::update(const Eigen::VectorXd & z,double in_dt = 0.02)
    {
        dt_ = in_dt;
        // 求雅各比矩阵
        H = jacobian_h(x_pri), R = update_R(z);
        // 更新卡尔曼增益
        K = P_pri * H.transpose() * (H * P_pri * H.transpose() + R).inverse();
        // 后验估计
        x_post = x_pri + K * (z - h(x_pri));

        P_post = (I - K * H) * P_pri;


        return x_post;
    }

    void EKF::setPri(const Eigen::VectorXd & p0){
        //    xc      v_xc    yc      v_yc    za      v_za    yaw     v_yaw   r
        P_pri <<p0(0,0),  p0(1,0), 0,      0,      0,      0,      0,      0,      0,
                p0(1,0), 0,0,      0,      0,      0,      0,      0,      0,
                0,      0,      p0(0,0),  p0(1,0), 0,      0,      0,      0,      0,
                0,      0,      p0(1,0), 0,0,      0,      0,      0,      0,
                0,      0,      0,      0,      p0(0,0),  p0(1,0), 0,      0,      0,
                0,      0,      0,      0,      p0(1,0), 0,0,      0,      0,
                0,      0,      0,      0,      0,      0,      p0(2,0),  p0(3,0), 0,
                0,      0,      0,      0,      0,      0,      p0(3,0), 0,0,
                0,      0,      0,      0,      0,      0,      0,      0,      p0(8,0);
    }

    void EKF::setState(const Eigen::VectorXd & x0) { x_post = x0; isUseEkfFlag++;}
    bool EKF::isUseUkF()
    {
        if(this->isUseEkfFlag > 10)
            return true;
        else
            return false;
    }
    void EKF::setParam()
    {
        this->nh.getParam("s2qxyz_", s2qxyz_);
        this->nh.getParam("s2qyaw_", s2qyaw_);
        this->nh.getParam("s2qr_", s2qr_);
        this->nh.getParam("r_xyz_factor", r_xyz_factor);
        this->nh.getParam("r_yaw", r_yaw);
    }
}