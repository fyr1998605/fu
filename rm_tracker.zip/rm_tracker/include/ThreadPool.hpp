#pragma once
#include <thread>
#include <exception>
#include <vector>
#include <mutex>
#include <queue>
#include "UTools.hpp"
//��ƽ̨�������
#ifndef __linux__
#include <windows.h>
SYSTEM_INFO sysInfo;
#else
#include "unistd.h"
#include "sys/sysinfo.h"
#endif
using namespace std;
using namespace Tools;
namespace Tools {
	typedef void (*Func_Ptr)(void*);
#define THREAD_DEFAULT_LIMIT 10
	template<typename...An>
	class Meta {};
	template<typename T>
	class Meta<T> {
	public:
		T value;
		static const int length = sizeof(T);
		static const int count = 1;
		Meta(void* ptr, T v) :value(std::move(v)) {
			// std::cout << "Address:\t" << (long long)ptr << "\t -> \t" << v << std::endl;
			*((T*)ptr) = v;
		};
	};
	template<typename T, typename...An>
	class Meta<T, An...> :public Meta<An...>
	{
	public:
		typedef Meta<An...> base;
		T value;
		static const int length = base::length + sizeof(T);
		static const int count = base::count + 1;
		Meta(void* ptr, T v, An...args) :base(((char*)ptr + sizeof(T)), args...), value(std::move(v)) {
			// std::cout << "Address:\t" << (long long)ptr << "\t -> \t" << v << std::endl;
			*((T*)ptr) = v;
		}
	};
	template<int N, class T, class...An>
	class MetaInfo {

	};
	template<class T, class...An>
	class MetaInfo<0, Meta<T, An...>> {
	public:
		typedef T Type;
		static const int Offset = 0;
		MetaInfo(void* ptr) {

		}
	};
	template<int N, class T, class...An>
	class MetaInfo<N, Meta<T, An...>> {
	public:
		typedef MetaInfo<N - 1, Meta<An...>> base;
		typedef class base::Type Type;
		static const int Offset = base::Offset + sizeof(T);
		MetaInfo(void* ptr) :MetaInfo<N - 1, Meta<An...>>(ptr) {

		}
	};
	enum class TaskState {   //����״̬ö���࣬��ʾ����Ĳ�ͬ״̬��
		free,		//���� - δִ��
		operating,	//���� - ������
		completed,	//��� - �����н���
		error,		//�������쳣
		unknow		//δ֪ - ״̬δ֪�������ǿ�������쳣����
	};
	class ThreadTask {      //�߳������࣬�洢������������Ϣ���������������ص��������쳣�ص��������ȡ�
	public:
		//������߳�ID
		unsigned int tid;
		//������
		std::function<void(void*)> _FUNC_;
		//�ص�����
		void (*_CALL_BACK_)(ThreadTask&);
		//�쳣�ص�
		void (*_ERROR_CALL_BACK_)(std::exception&);
		//���в���
		void* _PARAMETERS_;
		//����״̬
		TaskState _TASK_STATE_;
		//������Ϣ
		std::exception _ERROR_INFO_;
		//13λʱ���
		long _START_TIME_STRAMP_;
		//13λʱ��� ���ʱ�� δ�����Ϊ-1
		long _END_TIME_STRAMP_;

		//���Ը��ݴ���Ĳ�������ʼ������ĸ�����Ա������Empty���������ж������Ƿ�Ϊ�գ�ͨ�����������ָ�롢��ʼʱ���������״̬��ȷ�������Ƿ�Ϊ������

		ThreadTask()
		{
			this->tid = 0;
			this->_FUNC_ = 0;
			this->_CALL_BACK_ = 0;
			this->_ERROR_CALL_BACK_ = 0;
			this->_PARAMETERS_ = 0;
			this->_TASK_STATE_ = TaskState::unknow;
			this->_START_TIME_STRAMP_ = -1;
		}
		ThreadTask(std::function<void(void*)> func, void (*callback)(ThreadTask&), void (*error_callback)(std::exception&), void* parameters, TaskState task_state, long timestramp) {
			this->tid = 0;
			this->_FUNC_ = func;
			this->_CALL_BACK_ = callback;
			this->_ERROR_CALL_BACK_ = error_callback;
			this->_PARAMETERS_ = parameters;
			this->_TASK_STATE_ = task_state;
			this->_START_TIME_STRAMP_ = timestramp;
		}
		ThreadTask(std::function<void(void*)> func, void (*callback)(ThreadTask&), void (*error_callback)(std::exception&), void* parameters, TaskState task_state) {
			this->tid = 0;
			this->_FUNC_ = func;
			this->_CALL_BACK_ = callback;
			this->_ERROR_CALL_BACK_ = error_callback;
			this->_PARAMETERS_ = parameters;
			this->_TASK_STATE_ = task_state;
			this->_START_TIME_STRAMP_ = 0;
		}
		bool Empty() {
			if (!this)
				return true;
			return (this->_FUNC_ == NULL || this->_START_TIME_STRAMP_ < 0 || _TASK_STATE_ == TaskState::unknow);
		}
		//Zero��һ����̬��Ա����������һ����ʼ��ΪĬ��ֵ��ThreadTask����
		static ThreadTask Zero() {
			return ThreadTask(NULL, NULL, NULL, NULL, TaskState::unknow, -1);
		}
		//ChangeState���������޸������״̬��
		void ChangeState(TaskState state) {
			this->_TASK_STATE_ = state;
		}
	};
	enum class PoolType {
		CPUDense = 0,
		CPUOnly = 1,
		IODense = 2
	};
	class ThreadPool;  //�̳߳��࣬�����̺߳�������У���������Ҫ����������䡣
	class Thread {     //�߳��࣬����ִ��������������������ɺ���лص���
	private:
		unsigned int id;
		thread main;
		ThreadTask* task = NULL;
		bool free = true;
		bool function = true;
	public:
		Thread(ThreadPool&);
		Thread();
		bool Init(ThreadPool&);
		bool GiveTask(ThreadTask&);
		bool Handle(ThreadTask&);
		bool Handle(ThreadTask**);
		bool Function();
		bool Free() {
			return free;
		}
		bool Done() {
			task = NULL;
			free = true;
			return free;
		}
		bool Shutdown();
		unsigned int ID();
	};
	class ThreadPool {
	private:
		int limit, count, inuse;
		Thread* list,*list_end;
		queue<Thread*> free;//�Ŷ�������
		vector<ThreadTask*> inUse;
		queue<ThreadTask> tasks;
		thread manager;
		PoolType type;
		mutex lock_parameters, lock_queue, lock_free, lock_inuse;
		bool function = true;
	public:
		//-1������ ��ȡ��Ϊ0
		ThreadPool(PoolType type, int limit = -1) {
			std::cout<<"Thread pool start initialize"<<std::endl;
			if (limit != 0 && limit >= -1)
				this->limit = limit;
			else
				this->limit = THREAD_DEFAULT_LIMIT;
			if (~this->limit)
				this->count = limit;
			else
			{
				this->type = type;
#ifndef __linux__
				//cpu�ܼ��� 2*������һ(һ�������߳�)
				if (type == PoolType::CPUDense)
				{
					GetSystemInfo(&sysInfo);
					this->count = 2 * sysInfo.dwNumberOfProcessors;
				}
				else if (type == PoolType::CPUOnly) {
					GetSystemInfo(&sysInfo);
					this->count = sysInfo.dwNumberOfProcessors;
				}
				//IO�ܼ��� 10*���� - 1
				else if (type == PoolType::IODense) {
					GetSystemInfo(&sysInfo);
					this->count = 10 * sysInfo.dwNumberOfProcessors - 1;
				}
				else
					this->count = 4;
				this->limit = this->count;
#else
#endif
			}
			Thread* list = new Thread[limit];
			list_end = list + limit;
			lock_parameters.lock();
			for (int i = 0; i < this->count; i++) {
				(list + i)->Init(*this);
				// std::cout<<"Thread: " << (list + i)->ID() <<std::endl;
			}
			lock_parameters.unlock();
			manager = thread(&ThreadPool::Manager, this);
			manager.detach();
			switch (type)
			{
			case PoolType::CPUDense:
				std::cout<<"Thread pool was initialized!(type:CPU Dense|limit:" << limit << ')'<<std::endl;
				break;
			case PoolType::CPUOnly:
				std::cout<<"Thread pool was initialized!(type:CPU Only|limit:" << limit << ')'<<std::endl;
				break;
			case PoolType::IODense:
				std::cout<<"Thread pool was initialized!(type:IO Dense|limit:" << limit << ')'<<std::endl;
				break;
			default:
				std::cout<<"Thread pool was initialized!(type:Unknow|limit:Unknow)"<<std::endl;
				break;
			}
		}
		~ThreadPool() {

		}
		bool CheckSignal = false;
		void Tasker(Thread* param) {
			unsigned int id = static_cast<unsigned int>(std::hash<std::thread::id>()(std::this_thread::get_id()));
			lock_free.lock();
			free.push(param);
			// std::cout << "Thread:" << param.ID() << " in queue!" << std::endl;
			lock_free.unlock();
			ThreadTask* task = NULL;
			while (param->Function()) {
				if (CheckSignal) {
					param->Done();
					lock_free.lock();
					//std::cout << std::this_thread::get_id() << " Check!" << std::endl;
					free.push(param);
					lock_free.unlock();
				}
				if (!param->Handle(&task) || !task) {
					// std::this_thread::sleep_for(chrono::milliseconds(5));
					continue;
				}

				task->tid = id;
				task->_TASK_STATE_ = TaskState::operating;
				try {
					task->_FUNC_(task->_PARAMETERS_);
					if (task->_CALL_BACK_)
						task->_CALL_BACK_(*task);
					task->ChangeState(TaskState::completed);
				}
				catch (std::exception e) {
					try {
						if (!task->_ERROR_CALL_BACK_)
							task->_ERROR_CALL_BACK_(e);
					}
					catch (std::exception e) {}
					task->_TASK_STATE_ = TaskState::error;
				}
				param->Done();
				lock_inuse.lock();
				inuse -= 1;
				lock_inuse.unlock();
				lock_free.lock();
				//std::cout << std::this_thread::get_id() << " Free" << std::endl;
				free.push(param);
				lock_free.unlock();

				// std::this_thread::sleep_for(chrono::milliseconds(5));
				Sleep(2);
			}
		}
		int GetTaskCount()
		{
			lock_queue.lock();
			int result = tasks.size();
			// std::cout << " Task:" << tasks.size() << std::endl;
			lock_queue.unlock();
			return result;
		}
		void CheckInUse() {
			// lock_free.lock();
			// // std::cout << "Free thread count:" << free.size();
			// // std::cout << " Inuse:" << inuse;
			// // std::cout << " Task:" << tasks.size() << "    " << '\r';
			// lock_free.unlock();
			// if (inUse.size() == 0)
			// 	return;
			//vector<vector<ThreadTask*>::iterator> removes;
			//for (auto i = inUse.begin(); i != inUse.end(); i++) {
			//	if ((*i)->_TASK_STATE_ == TaskState::error || (*i)->_TASK_STATE_ == TaskState::completed)
			//		removes.push_back(i);
			//		//inUse.erase(i);
			//}
			//for (auto& i : removes) {
			//	try {
			//		if ((*i)->Empty())
			//			continue;
			//		inUse.erase(i);
			//	}
			//	catch (std::runtime_error e) {
			//		std::cout << "Exception to erase task:" << e.what() << std::endl;
			//	}
			//}
			//removes.clear();
		}
		void INFO(){
			lock_free.lock();
			lock_queue.lock();
			std::cout << "FTC:" << free.size();
			std::cout << " Inuse:" << inuse;
			std::cout << " Task:" << tasks.size() << std::endl;
			lock_queue.unlock();
			lock_free.unlock();
		}
		const int ManagerTimespan = 0;
		void Manager() {
			lock_inuse.lock();
			inuse = 0;
			lock_inuse.unlock();
			ThreadTask task;
			Thread* th;
			while (function) {
				std::this_thread::sleep_for(chrono::milliseconds(ManagerTimespan));
				CheckInUse();
				if (inuse >= count || tasks.size() == 0) {
					continue;
				}
				lock_free.lock();
				//if (inuse + free.size() != count) {
				//	CheckSignal = true;
				//	std::cout << "List error start to check!" << std::endl;
				//	while (free.size() != 0)
				//		free.pop();
				//}
				//else {
				//	CheckSignal = false;
				//}
				lock_free.unlock();

				//��ȡ�������
				lock_queue.lock();
				task = tasks.front();
				tasks.pop();
				lock_queue.unlock();
				if (task.Empty()) {
					std::this_thread::sleep_for(chrono::milliseconds(ManagerTimespan));
					continue;
				}

				//��ȡ�̶߳���
				while (free.size() == 0) {
					CheckInUse();
					std::this_thread::sleep_for(chrono::milliseconds(ManagerTimespan));
				}
				lock_free.lock();
				th = free.front();
				free.pop();
				lock_free.unlock();
				if (!th->Function() || !th->Free()) {
					std::this_thread::sleep_for(chrono::milliseconds(ManagerTimespan));
					continue;
				}

				//�������񲢼���"������"�б�
				lock_inuse.lock();
				inuse += 1;
				lock_inuse.unlock();
				th->GiveTask(task);
				inUse.push_back(&task);

				std::this_thread::sleep_for(chrono::milliseconds(ManagerTimespan));
			}
		}
		void AddTask(ThreadTask task) {
				lock_queue.lock();
				tasks.push(task);
				lock_queue.unlock();
		}
		void AddTask(std::function<void(void*)> func, void* parameters = NULL) {
				lock_queue.lock();
				tasks.push(ThreadTask(func, NULL, NULL, parameters, TaskState::free));
				lock_queue.unlock();
		}
		template<class Fc, class...An>
		void AddTask() {

		}
	};

	Thread::Thread(ThreadPool& pool) {
		// main = thread(&ThreadPool::Tasker,this, &pool);
		// id = static_cast<unsigned int>(std::hash<std::thread::id>()(main.get_id()));
		// main.detach();
	}
	Thread::Thread()
	{}
	bool Thread::Init(ThreadPool& pool){
		auto t = &ThreadPool::Tasker;
		main = thread([this,&pool](){pool.Tasker(this);});
		id = static_cast<unsigned int>(std::hash<std::thread::id>()(main.get_id()));
		main.detach();
		return true;
	}
	bool Thread::GiveTask(ThreadTask& task) {
		if (!free || task.Empty())
			return false;
		this->task = &task;
		return true;
	}
	bool Thread::Handle(ThreadTask& task) {
		task = ThreadTask::Zero();
		if (!free || this->task->Empty())
			return false;
		free = false;
		task = *(this->task);
		this->task = NULL;
		return true;
	}
	bool Thread::Handle(ThreadTask** task) {
		*task = NULL;
		if (!free || !this->task || this->task->Empty())
			return false;
		free = false;
		*task = this->task;
		this->task = NULL;
		return true;
	}
	bool Thread::Function() {
		return function;
	}
	bool Thread::Shutdown() {
		function = false;
		return function;
	}
	unsigned int Thread::ID() {
		return id;
	}
}
