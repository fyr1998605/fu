#ifndef CALCULATE
#define CALCULATE
#include <ros/ros.h>
#include <geometry_msgs/PoseArray.h>
#include <geometry_msgs/Pose.h>
#include <Eigen/Dense>
#include <tf2/LinearMath/Quaternion.h>
#include <vector>
#include <tf2_ros/transform_broadcaster.h>
#include <geometry_msgs/TransformStamped.h>
#include <geometry_msgs/Vector3.h>
#include <tf2/LinearMath/Matrix3x3.h>
#include <geometry_msgs/PointStamped.h>
#include <tf2_ros/buffer.h>
#include <tf2_ros/transform_listener.h>
#include <opencv2/opencv.hpp>

using namespace std;

namespace OCAL{
class Calculate
{
private:
    
public:
    Calculate();
    Calculate(cv::Mat cameraMatrix);
    ~Calculate();
    // 欧拉角转四元数
    Eigen::Vector4d MyEuler2QUaternion(double roll, double pitch, double yaw);
    // 欧拉角转旋转矩阵
    Eigen::Matrix3d MyEuler2Rotation(double roll, double pitch, double yaw);
    // 四元数转欧拉角
    Eigen::Vector3d MyQUaternion2Euler(double x,double y,double z,double w);
    Eigen::Vector3d MyQUaternion2Euler(double qtn[4]);
    Eigen::Vector3d MyQUaternion2Euler(geometry_msgs::Quaternion qtn);
    // 通过tagrt的姿态信息算出车的中心
    Eigen::Vector3d CalCenter(geometry_msgs::Pose p1, geometry_msgs::Pose p2);
    // 判断是否可以算中心
    bool IsCalCenter(geometry_msgs::Pose p1, geometry_msgs::Pose p2);
    // 判断是否可以算中心
    bool IsCalCenter(double lastYaw, double nowYaw);
    // 算车的信息
    Eigen::Vector4d CalCarInformation(Eigen::Vector3d lastTarget, double lastYaw, Eigen::Vector3d nowTarget, double nowYaw);
    // 计算其他三个装甲板
    std::vector<geometry_msgs::Pose> CalThreeAmour(Eigen::Vector3d CarCenter, double r, double yaw);
    // 计算装甲板的四个角点odom
    std::vector<Eigen::Vector3d> fourArmorPoint(Eigen::Vector3d armorCenter, double roll, double pitch, double yaw);
    // 计算装甲板的四个角点cam
    std::vector<Eigen::Vector3d> FourArmorPointInCam(Eigen::Vector3d armorCenter, double roll, double pitch, double yaw);
    // 计算其他三个装甲板
    std::vector<geometry_msgs::Pose> CalThreeAmour(Eigen::Vector3d CarCenter, Eigen::Vector3d armorCenter);
    // 计算装甲板的四个角点并返回tf消息
    std::vector<geometry_msgs::TransformStamped> fourArmorPoint(Eigen::Vector3d armorCenter, double roll, double pitch, double yaw, int flag);
    // 获取陀螺仪数据
    void GetimuToOdom();
    void GetimuToOdom(double roll,double pitch,double yaw);
    // odom系下的三维点
    Eigen::Vector3d GetTargetInOdom(cv::Mat tvec);
    Eigen::Vector3d GetTargetInOdom(geometry_msgs::Point point);
    // cam系下的三维点
    Eigen::Vector3d GetTargetInCam(cv::Mat tvec);
    // cam转pixel
    cv::Point2f threeToTwo(Eigen::Vector3d targetInCam);
    cv::Point2f threeToTwo(cv::Mat targetInCam);
    // odom转cam
    Eigen::Vector3d OdomToCam(Eigen::Vector3d target);
    // 算四点距离
    double calPointsDis(std::vector<cv::Point2f> targetPoint, std::vector<cv::Point2f> point);
    // 返回一个pose的消息数据
    geometry_msgs::Pose GetPose(Eigen::Vector3d targetInCam, double roll, double pitch, double yaw);
private:
    cv::Mat camMatrix;
    Eigen::Matrix3d camToImu;
    Eigen::Matrix3d imuToCam;
    Eigen::Matrix3d imuToOdom;
    Eigen::Matrix3d odomToImu;
    tf2_ros::Buffer tfBuffer;
    tf2_ros::TransformListener tfListener;
};

Calculate::Calculate():  tfListener(tfBuffer)
{
    camToImu = MyEuler2Rotation(-M_PI / 2, 0, -M_PI / 2);
    imuToCam = camToImu.inverse();

    odomToImu.setIdentity();
}

Calculate::Calculate(cv::Mat cameraMatrix):  tfListener(tfBuffer)
{
    camMatrix = cameraMatrix;
    camToImu = MyEuler2Rotation(-M_PI / 2, 0, -M_PI / 2);
    imuToCam = camToImu.inverse();
}

Calculate::~Calculate()
{
}

// 欧拉角转四元数
Eigen::Vector4d Calculate::MyEuler2QUaternion(double roll, double pitch, double yaw)
{
    tf2::Quaternion qtn;
    qtn.setRPY(roll, pitch, yaw);

    return Eigen::Vector4d(qtn.w(), qtn.x(), qtn.y(), qtn.z()); 
} 

// 欧拉角转旋转矩阵
Eigen::Matrix3d Calculate::MyEuler2Rotation(double roll, double pitch, double yaw)
{
    Eigen::Matrix3d rollRotation, pitchRotation, yawRotation;
    rollRotation << 1, 0, 0,
                    0, cos(roll), -sin(roll),
                    0, sin(roll),  cos(roll);

    pitchRotation << cos(pitch), 0, sin(pitch),
                     0, 1, 0,
                    -sin(pitch), 0, cos(pitch); 

    yawRotation << cos(yaw), -sin(yaw), 0,
                   sin(yaw),  cos(yaw), 0,
                   0, 0, 1;    

    return  yawRotation * pitchRotation * rollRotation;      

}

// 四元数转欧拉角
Eigen::Vector3d Calculate::MyQUaternion2Euler(double x,double y,double z,double w)
{
    tf2::Quaternion quaternion(x,y,z,w);

    // 将四元数转换为欧拉角
    tf2::Matrix3x3 matrix(quaternion);
    double roll, pitch, yaw;
    matrix.getRPY(roll, pitch, yaw);
    return {roll, pitch, yaw};
}
// 四元数转欧拉角
Eigen::Vector3d Calculate::MyQUaternion2Euler(double qtn[4])
{
    tf2::Quaternion quaternion(qtn[1], qtn[2], qtn[3], qtn[0]);

    // 将四元数转换为欧拉角
    tf2::Matrix3x3 matrix(quaternion);
    double roll, pitch, yaw;
    matrix.getRPY(roll, pitch, yaw);
    return {roll, pitch, yaw};
}
// 四元数转欧拉角
Eigen::Vector3d Calculate::MyQUaternion2Euler(geometry_msgs::Quaternion qtn)
{
    tf2::Quaternion quaternion(qtn.x, qtn.y, qtn.z, qtn.w);

    // 将四元数转换为欧拉角
    tf2::Matrix3x3 matrix(quaternion);
    double roll, pitch, yaw;
    matrix.getRPY(roll, pitch, yaw);
    return {roll, pitch, yaw};
}
// 通过tagrt的姿态信息算出车的中心
double lastR = 0;
Eigen::Vector3d Calculate::CalCenter(geometry_msgs::Pose p1, geometry_msgs::Pose p2)
{
    tf2::Quaternion qtn1(p1.orientation.x, p1.orientation.y, p1.orientation.z, p1.orientation.w);
    tf2::Quaternion qtn2(p2.orientation.x, p2.orientation.y, p2.orientation.z, p2.orientation.w);
    double roll1, pitch1, yaw1;
    double roll2, pitch2, yaw2;
    tf2::Matrix3x3(qtn1).getRPY(roll1, pitch1, yaw1);
    tf2::Matrix3x3(qtn2).getRPY(roll2, pitch2, yaw2);

    double line1_k = tan(yaw1);
    double line2_k = tan(yaw2);

    double b1 = p1.position.y -line1_k * p1.position.x;
    double b2 = p2.position.y -line2_k * p2.position.x;

    double x = (b2 - b1) / (line1_k - line2_k);
    double y = line1_k * x + b1;

    Eigen::Vector3d tp_c(x, y ,(p1.position.z + p2.position.z) / 2);
    Eigen::Vector3d tp_p(p1.position.x, p1.position.y , p1.position.z);
    Eigen::Vector3d r = tp_c - tp_p;
    double rr = sqrt((tp_c[0] - tp_p[0]) * (tp_c[0] - tp_p[0]) + (tp_c[1] - tp_p[1]) * (tp_c[1] - tp_p[1]));
    // std::cout << "半径:" << rr << std::endl;
    // std::cout << "oX:" << x << std::endl;
    // std::cout << "oY:" << y << std::endl;
    
    if(rr > 0.3 || rr < 0.1)
        rr = lastR;

    x = p1.position.x + rr * cos(yaw1 + M_PI);
    y = p1.position.y + rr * sin(yaw1 + M_PI);
    // std::cout << "rX:" << x << std::endl;
    // std::cout << "rY:" << y << std::endl;
    // std::cout << "X1:" << p1.position.x << std::endl;
    // std::cout << "Y1:" << p1.position.y << std::endl;
    // std::cout << "-----------------------" << std::endl;
    lastR = rr;
    return Eigen::Vector3d(x, y, (p1.position.z + p2.position.z) / 2);
}

// 计算其他三个装甲板
std::vector<geometry_msgs::Pose> Calculate::CalThreeAmour(Eigen::Vector3d CarCenter, double r, double yaw)
{
    double yaw1, yaw2, yaw3;
    Eigen::Vector4d qtn1, qtn2, qtn3;

    yaw1 = yaw + M_PI / 2;
    yaw2 = yaw + M_PI;
    yaw3 = yaw + 3 * M_PI / 2 ;

    qtn1 = MyEuler2QUaternion(0, -15.0 / 180.0 * M_PI, yaw1);
    qtn2 = MyEuler2QUaternion(0, -15.0 / 180.0 * M_PI, yaw2);
    qtn3 = MyEuler2QUaternion(0, -15.0 / 180.0 * M_PI, yaw3);

    Eigen::Vector3d rr(r, 0, 0);
    Eigen::Vector3d p1 = MyEuler2Rotation(0, 0, yaw1) * rr + CarCenter;
    Eigen::Vector3d p2 = MyEuler2Rotation(0, 0, yaw2) * rr + CarCenter;
    Eigen::Vector3d p3 = MyEuler2Rotation(0, 0, yaw3) * rr + CarCenter;

    std::vector<geometry_msgs::Pose> points;
    
    geometry_msgs::Pose pp1;
    geometry_msgs::Pose pp2;
    geometry_msgs::Pose pp3;

    pp1.orientation.w = qtn1[0];
    pp1.orientation.x = qtn1[1];
    pp1.orientation.y = qtn1[2];
    pp1.orientation.z = qtn1[3];
    pp1.position.x = p1[0];
    pp1.position.y = p1[1];
    pp1.position.z = p1[2];
    points.push_back(pp1);

    pp2.orientation.w = qtn2[0];
    pp2.orientation.x = qtn2[1];
    pp2.orientation.y = qtn2[2];
    pp2.orientation.z = qtn2[3];
    pp2.position.x = p2[0];
    pp2.position.y = p2[1];
    pp2.position.z = p2[2];
    points.push_back(pp2);

    pp3.orientation.w = qtn3[0];
    pp3.orientation.x = qtn3[1];
    pp3.orientation.y = qtn3[2];
    pp3.orientation.z = qtn3[3];
    pp3.position.x = p3[0];
    pp3.position.y = p3[1];
    pp3.position.z = p3[2];
    points.push_back(pp3);   

    return points;

}

// 计算其他三个装甲板2
std::vector<geometry_msgs::Pose> Calculate::CalThreeAmour(Eigen::Vector3d CarCenter, Eigen::Vector3d armorCenter)
{
    Eigen::Vector3d armorInCar = armorCenter - CarCenter;
    Eigen::Vector4d qtn1, qtn2, qtn3;
    double angle = acos(armorInCar[1] / armorInCar[0]);
    auto tempAngle1 = angle - M_PI / 2 * 1;
    auto tempAngle2 = angle - M_PI / 2 * 2;
    auto tempAngle3 = angle - M_PI / 2 * 3;
    auto r = armorInCar.norm();

    qtn1 = MyEuler2QUaternion(0, -15.0 / 180.0 * M_PI, tempAngle1);
    qtn2 = MyEuler2QUaternion(0, -15.0 / 180.0 * M_PI, tempAngle2);
    qtn3 = MyEuler2QUaternion(0, -15.0 / 180.0 * M_PI, tempAngle3);

    vector<Eigen::Vector3d> armors;
    armors.push_back({r * cos(tempAngle1) + CarCenter[0], r * sin(tempAngle1) + CarCenter[1], armorInCar[2] + CarCenter[2]});
    armors.push_back({r * cos(tempAngle2) + CarCenter[0], r * sin(tempAngle2) + CarCenter[1], armorInCar[2] + CarCenter[2]});
    armors.push_back({r * cos(tempAngle3) + CarCenter[0], r * sin(tempAngle3) + CarCenter[1], armorInCar[2] + CarCenter[2]});

    vector<geometry_msgs::Pose> poses;
    geometry_msgs::Pose pose;
    pose.orientation.w = qtn1[0];
    pose.orientation.x = qtn1[1];
    pose.orientation.y = qtn1[2];
    pose.orientation.z = qtn1[3];
    pose.position.x = armors[0][0];
    pose.position.y = armors[0][1];
    pose.position.z = armors[0][2];
    poses.push_back(pose);

        pose.orientation.w = qtn2[0];
    pose.orientation.x = qtn2[1];
    pose.orientation.y = qtn2[2];
    pose.orientation.z = qtn2[3];
    pose.position.x = armors[1][0];
    pose.position.y = armors[1][1];
    pose.position.z = armors[1][2];
    poses.push_back(pose);

        pose.orientation.w = qtn3[0];
    pose.orientation.x = qtn3[1];
    pose.orientation.y = qtn3[2];
    pose.orientation.z = qtn3[3];
    pose.position.x = armors[2][0];
    pose.position.y = armors[2][1];
    pose.position.z = armors[2][2];
    poses.push_back(pose);
    return poses;
}

// 判断是否可以算中心
bool Calculate::IsCalCenter(geometry_msgs::Pose p1, geometry_msgs::Pose p2)
{
    tf2::Quaternion LastQtn(p2.orientation.w, p2.orientation.x, p2.orientation.y, p2.orientation.z);
    tf2::Quaternion NowQtn(p1.orientation.w, p1.orientation.x, p1.orientation.y, p1.orientation.z);

    tf2::Matrix3x3 LastMat(LastQtn);
    tf2::Matrix3x3 NowMat(NowQtn);

    double LastRoll ,LastPitch, LastYaw, NowRoll, NowPitch , NowYaw;
    LastMat.getRPY(LastRoll, LastPitch, LastYaw);
    NowMat.getRPY(NowRoll, NowPitch, NowYaw);

    if(abs((LastYaw - NowYaw) * 180 / M_PI) <= 2)
        return true;
    else 
        return false;

}

// 判断是否可以算中心
bool Calculate::IsCalCenter(double lastYaw, double nowYaw)
{
    if(abs((lastYaw - nowYaw) * 180 / M_PI) <= 10)
        return true;
    else 
        return false;
}

// 算车的信息
Eigen::Vector4d Calculate::CalCarInformation(Eigen::Vector3d lastTarget, double lastYaw, Eigen::Vector3d nowTarget, double nowYaw)
{
    double k1, k2, b1, b2;
    k1 = tan(lastYaw); k2 = tan(nowYaw);
    b1 =  lastTarget[1] - lastTarget[0] * k1;
    b2 =  nowTarget[1] - nowTarget[0] * k2;
    double carX = (b2 - b1) / (k1 - k2);
    double carY = k2 * carX + b2;
    double rr = pow((carX - nowTarget[0]), 2) + pow((carY - nowTarget[1]), 2);
    rr = sqrt(rr);

    if(rr > 0.3 || rr < 0.1)
        rr = 0.2;

    double trueCarX = nowTarget[0] + rr * cos(nowYaw);
    double trueCarY = nowTarget[1] + rr * sin(nowYaw);

    Eigen::Vector4d information;
    information << trueCarX, trueCarY, nowTarget[2], rr;
    return information;
}

// 计算装甲板的四个角点
std::vector<Eigen::Vector3d> Calculate::fourArmorPoint(Eigen::Vector3d armorCenter, double roll, double pitch, double yaw)
{
    double armorHigh = 0.035;
    double armorWight = 0.063123;

    Eigen::Vector3d armorLeftUp(0, -armorWight, armorHigh);
    Eigen::Vector3d armorLeftDown(0, -armorWight, -armorHigh);
    Eigen::Vector3d armorRightUp(0, armorWight, armorHigh);
    Eigen::Vector3d armorRightDown(0, armorWight, -armorHigh);

    auto rMatrix = MyEuler2Rotation(roll, pitch, yaw);  
    // cout << "1:" << endl;
    // cout << rMatrix << endl;
    vector<Eigen::Vector3d> p(4);
    p[0] = armorCenter + rMatrix * armorLeftUp;
    p[1] = armorCenter + rMatrix * armorRightUp;
    p[2] = armorCenter + rMatrix * armorRightDown;
    p[3] = armorCenter + rMatrix * armorLeftDown;

    std::vector<Eigen::Vector3d> points;
    for(int i = 0; i < 4; i++){
        // cout << i << ":" << endl << p[i] << endl;
        // cout << "------" << endl;
        points.push_back(p[i]);
    }
    // cout << "=====" << endl;
    return points;
}

// 计算装甲板的四个角点
std::vector<Eigen::Vector3d> Calculate::FourArmorPointInCam(Eigen::Vector3d armorCenter, double roll, double pitch, double yaw)
{
    double armorHigh = 0.035 * 1000;
    double armorWight = 0.063 * 1000;
    // 0.015 0.02 0.07

    Eigen::Vector3d armorLeftUp(-armorWight, -armorHigh, 0);
    Eigen::Vector3d armorLeftDown(-armorWight, armorHigh, 0);
    Eigen::Vector3d armorRightUp(armorWight, -armorHigh, 0);
    Eigen::Vector3d armorRightDown(armorWight, armorHigh, 0);

    auto rMatrix = MyEuler2Rotation(roll, pitch, yaw);  
    // cout << "1:" << endl;
    // cout << rMatrix << endl;
    vector<Eigen::Vector3d> p(4);
    p[0] = armorCenter + rMatrix * armorLeftUp;
    p[1] = armorCenter + rMatrix * armorRightUp;
    p[2] = armorCenter + rMatrix * armorRightDown;
    p[3] = armorCenter + rMatrix * armorLeftDown;

    std::vector<Eigen::Vector3d> points;
    for(int i = 0; i < 4; i++){
        points.push_back(p[i]);
    }
    return points;
}

// 计算装甲板的四个角点并返回tf消息
std::vector<geometry_msgs::TransformStamped> Calculate::fourArmorPoint(Eigen::Vector3d armorCenter, double roll, double pitch, double yaw, int flag)
{
    double armorHigh = 0.066 / 2;
    double armorWight = 0.112 / 2;

    Eigen::Vector3d armorLeftUp(0, -armorWight, armorHigh);
    Eigen::Vector3d armorLeftDown(0, -armorWight, -armorHigh);
    Eigen::Vector3d armorRightUp(0, armorWight, armorHigh);
    Eigen::Vector3d armorRightDown(0, armorWight, -armorHigh);

    auto rMatrix = MyEuler2Rotation(roll, pitch, yaw);
    // cout << "2:" << endl;
    // cout << rMatrix << endl;
    vector<Eigen::Vector3d> p(4);
    p[0] = armorCenter + rMatrix * armorLeftUp;
    p[1] = armorCenter + rMatrix * armorRightUp;
    p[2] = armorCenter + rMatrix * armorRightDown;
    p[3] = armorCenter + rMatrix * armorLeftDown;

    // p[0] = rMatrix * armorLeftUp;
    // p[1] = rMatrix * armorRightUp;
    // p[2] = rMatrix * armorRightDown;
    // p[3] = rMatrix * armorLeftDown;
    // for(int i = 0; i < 4; i++){
    //     cout << i << ":" << endl << p[i] << endl;
    //     cout << "------" << endl;
    // }
    // cout << "$$$$$$$$$$$$$$$$$$$$$$$" << endl;
    std::vector<geometry_msgs::TransformStamped> tfs;
    for(int i = 0; i < 4; i++){
        geometry_msgs::TransformStamped tf;
        tf2::Quaternion qtn;
        qtn.setRPY(roll, pitch, yaw);
        tf.child_frame_id = "p" + to_string(i);
        tf.header.frame_id = "map";
        tf.header.stamp = ros::Time::now();
        tf.transform.rotation.w = qtn.w();
        tf.transform.rotation.x = qtn.x();
        tf.transform.rotation.y = qtn.y();
        tf.transform.rotation.z = qtn.z();
        tf.transform.translation.x = p[i][0];
        tf.transform.translation.y = p[i][1];
        tf.transform.translation.z = p[i][2];
        
        tfs.push_back(tf);
    }
    return tfs;
}

// 获取陀螺仪数据
void Calculate::GetimuToOdom()
{
    // 定义源坐标系和目标坐标系的名称
    std::string sourceFrame = "imu";
    std::string targetFrame = "odom";

    geometry_msgs::TransformStamped transformStamped;
    try
    {
        // 获取源坐标系到目标坐标系的变换
        transformStamped = tfBuffer.lookupTransform(targetFrame, sourceFrame, ros::Time(0));
        
        // 打印位姿关系信息

        geometry_msgs::Quaternion qtn = transformStamped.transform.rotation;
        auto rpy = MyQUaternion2Euler(qtn);
        imuToOdom = MyEuler2Rotation(rpy[0], rpy[1], rpy[2]);
        odomToImu = imuToOdom.inverse();
        // std::cout << rpy[0] << "    " << rpy[1] << "    " << rpy[2] << endl;
    }
    catch (tf2::TransformException& ex)
    {
      ROS_WARN("%s", ex.what());
    }
}
void Calculate::GetimuToOdom(double roll,double pitch,double yaw)
{
    // 打印位姿关系信息
    imuToOdom = MyEuler2Rotation(roll, pitch, yaw);
    odomToImu = imuToOdom.inverse();
}

// odom系下的三维点
Eigen::Vector3d Calculate::GetTargetInOdom(cv::Mat tvec)
{
    Eigen::Vector3d target;
    target << tvec.at<double>(0, 0) / 1000, tvec.at<double>(1, 0) / 1000, tvec.at<double>(2, 0) / 1000;
    return imuToOdom * camToImu * target;
}

Eigen::Vector3d Calculate::GetTargetInOdom(geometry_msgs::Point point)
{
    Eigen::Vector3d target;
    target << point.x / 1000, point.y / 1000, point.z / 1000;
    return imuToOdom * camToImu * target;
}

// cam系下的三维点
Eigen::Vector3d Calculate::GetTargetInCam(cv::Mat tvec)
{
    Eigen::Vector3d target;
    target << tvec.at<double>(0, 0), tvec.at<double>(1, 0), tvec.at<double>(2, 0);
    return target;
}

// cam转pixel
cv::Point2f Calculate::threeToTwo(Eigen::Vector3d targetInCam)
{
    Eigen::Matrix3d cameraMatrix;
    for(int i = 0; i < 3; i++)
        for(int j = 0; j < 3; j++)
           cameraMatrix(i, j) = camMatrix.at<double>(i, j);
    auto _pixel = cameraMatrix * targetInCam;
    cv::Point2f targetInPixel;
    targetInPixel.x = _pixel[0] / _pixel[2];
    targetInPixel.y = _pixel[1] / _pixel[2];
    return targetInPixel;
}

cv::Point2f Calculate::threeToTwo(cv::Mat targetInCam)
{
    Eigen::Vector3d target;
    target << targetInCam.at<double>(0, 0), targetInCam.at<double>(1, 0), targetInCam.at<double>(2, 0);
    return threeToTwo(target);
}

// odom转cam
Eigen::Vector3d Calculate::OdomToCam(Eigen::Vector3d target)
{
    return imuToCam * odomToImu * (target * 1000);
}

// 算四点距离
double Calculate::calPointsDis(std::vector<cv::Point2f> targetPoint, std::vector<cv::Point2f> point)
{
    double dis;
    for(int i = 0; i < targetPoint.size(); i++){
        dis += sqrt(pow((targetPoint[i].x - point[i].x), 2) + pow((targetPoint[i].y - point[i].y), 2));
    }
    return dis / 4;
}

// 返回一个pose的消息数据
geometry_msgs::Pose Calculate::GetPose(Eigen::Vector3d targetInCam, double roll, double pitch, double yaw)
{
    geometry_msgs::Pose pose;
    pose.position.x = targetInCam[0];
    pose.position.y = targetInCam[1];
    pose.position.z = targetInCam[2];

    // 将欧拉角转换为四元数
    tf2::Quaternion qtn;
    qtn.setRPY(roll, pitch, yaw);
    
    pose.orientation.w = qtn.w();
    pose.orientation.x = qtn.x();
    pose.orientation.y = qtn.y();
    pose.orientation.z = qtn.z();

    return pose;
}

}
#endif