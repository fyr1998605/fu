#include <ros/ros.h>
#include "Basic.hpp"
#include "RmTracker.hpp"

int main(int argc, char *argv[])
{
    ros::init(argc, argv, "tracker");
    ros::NodeHandle nh;
    Init(nh);
    ros::Subscriber armors = nh.subscribe("/armor_array", 1000, &RmIdentify::doserial, &ri);
    pool.AddTask([](){
        while(ros::ok())
            ros::spanOnce();
    },NULL);
    while(ros::ok()){
        fcr.Count();
        Track();
    }
}